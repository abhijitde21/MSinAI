# SAP S/4HANA Data Migration — Reconciliation App

An enterprise-grade, full-stack Streamlit application that reconciles **transformed (pre-load)** data against **loaded (post-load)** data for any SAP S/4HANA data migration object — Customer Master, Material Master, Vendor Master, Bank Master, Fixed Assets, Open Items, you name it.

The app is **object-agnostic**: you upload two CSV files, pick the key column(s), and the engine does a strict column-by-column comparison. Any row with at least one column mismatch is flagged. You can then explore mismatches, download Excel / CSV / PDF reports, and chat with a Groq-hosted LLM that is grounded on the reconciliation result.

---

## Features

- **Two-file upload** — transformed & loaded CSVs, with multi-encoding/separator auto-detection (utf-8, cp1252, semicolon, tab, …).
- **User-driven key selection** — pick one or more columns to join the two sides on.
- **Column-by-column comparison** — every shared non-key column is normalized and compared; rows are flagged if any column differs.
- **Rich dashboard** — KPIs (total rows, match rate, mismatches per column), pie chart of statuses, bar chart of top mismatched columns.
- **Drill-down view** — side-by-side `[Transformed]` vs `[Loaded]` columns with focus filters.
- **Downloads** — multi-sheet Excel workbook, mismatches-only CSV, and a polished one-page PDF executive summary.
- **Grounded LLM chat (Groq)** — ask things like "why are most mismatches in `MEINS`?" or "give me a triage plan"; the model only sees the reconciliation report.

---

## Architecture

```
reconcillation_testing/
├── app.py                  # Streamlit entrypoint (UI + glue)
├── recon/
│   ├── __init__.py
│   ├── engine.py           # Column-by-column reconciliation logic
│   ├── llm.py              # Groq client + grounded context builder
│   ├── reporting.py        # Excel / CSV / PDF exporters
│   └── utils.py            # CSV ingestion + value normalization
├── sample_data/
│   ├── material_transformed.csv
│   └── material_loaded.csv
├── requirements.txt
├── .env.example
└── README.md
```

---

## Quick start

```bash
# 1. Install Python 3.10+ then create a venv
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Provide your Groq API key (free tier is fine)
cp .env.example .env
echo "GROQ_API_KEY=gsk_xxx..." >> .env
#   …or skip this and paste the key in the sidebar at runtime.

# 4. Run the app
streamlit run app.py
```

The app will open at `http://localhost:8501`.

---

## Using the app

1. **Upload** both CSVs in the sidebar.
2. On the **Upload & configure** tab, pick one or more **key columns** (these uniquely identify a row on both sides), then click **Run reconciliation**.
3. Browse the **Dashboard** for KPIs and charts.
4. Open **Mismatched rows** to drill into the differences side-by-side.
5. Grab the deliverables from the **Downloads** tab (Excel, CSV, PDF).
6. Switch to the **Chat** tab and ask the Groq LLM analytical questions about the report.

---

## Sample data

`sample_data/material_transformed.csv` and `sample_data/material_loaded.csv` represent a small Material Master extract. The loaded file has been intentionally perturbed (truncation, unit-of-measure drift, missing row, duplicate key, decimal-format mismatch) so you can verify every behaviour of the engine end-to-end.

Key column to choose for the sample: **`MATNR`**.

---

## Notes for enterprise users

- **No data leaves your machine** except the small, anonymized context sent to Groq when you use the chat tab. The reconciliation engine itself is local.
- All numeric strings are normalized (e.g. `"1.0"` == `"1"`, `"1,000.5"` == `"1000.5"`); whitespace is stripped; blanks / `NaN` / `None` collapse to a single `<NULL>` sentinel before comparison.
- Duplicate keys on either side are detected and reported separately (only the first occurrence per key is compared).
- If your CSV uses non-comma separators or non-UTF-8 encoding (typical for SAP exports), the loader will detect that automatically.

---

## License

Internal / proprietary — adapt freely to your enterprise context.
