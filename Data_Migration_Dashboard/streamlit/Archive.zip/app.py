"""SAP S/4HANA Data Migration — Reconciliation Streamlit App.

Run with:
    streamlit run app.py
"""
from __future__ import annotations

import os
from datetime import datetime

import pandas as pd
import streamlit as st

try:
    from dotenv import load_dotenv

    load_dotenv()
except Exception:  # noqa: BLE001
    pass

from recon.engine import ReconciliationEngine
from recon.llm import ChatMessage, GroqChat, ReconciliationContext, resolve_api_key, DEFAULT_MODEL
from recon.reporting import build_excel_report, build_mismatch_csv, build_pdf_summary
from recon.utils import read_csv_smart


# ---------------------------------------------------------------------------
# Streamlit page setup
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="SAP S/4HANA Migration Reconciliation",
    page_icon="🔄",
    layout="wide",
    initial_sidebar_state="expanded",
)

# A small splash of custom CSS — tasteful, not flashy.
st.markdown(
    """
    <style>
        .main .block-container {padding-top: 1.2rem;}
        .stMetric {background:#f6f8fc;border:1px solid #e5e9f2;
                   border-radius:10px;padding:14px;}
        h1, h2, h3 {color:#0b3d91;}
        div[data-testid="stSidebar"] {background:#0b3d91;}
        div[data-testid="stSidebar"] * {color:#ffffff !important;}
        div[data-testid="stSidebar"] .stTextInput input,
        div[data-testid="stSidebar"] .stSelectbox div[data-baseweb="select"] > div {
            color:#0b3d91 !important;
        }
        div[data-testid="stSidebar"] input::placeholder {color:#888 !important;}
    </style>
    """,
    unsafe_allow_html=True,
)


# ---------------------------------------------------------------------------
# Session-state init
# ---------------------------------------------------------------------------
def _init_state() -> None:
    defaults = {
        "transformed_df": None,
        "loaded_df": None,
        "transformed_name": None,
        "loaded_name": None,
        "result": None,
        "chat_history": [],
        "sidebar_api_key": "",
        "selected_model": DEFAULT_MODEL,
    }
    for k, v in defaults.items():
        st.session_state.setdefault(k, v)


_init_state()


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.markdown("# ⚙️ Configuration")
    st.markdown("**LLM provider:** Groq")

    env_key_present = bool(os.environ.get("GROQ_API_KEY", "").strip())
    if env_key_present:
        st.success("Groq API key detected from environment.", icon="✅")
    else:
        st.warning("No GROQ_API_KEY env var. Enter a key below to enable chat.", icon="🔑")

    st.session_state["sidebar_api_key"] = st.text_input(
        "Groq API key (optional override)",
        value=st.session_state["sidebar_api_key"],
        type="password",
        help="Used only if the GROQ_API_KEY environment variable is not set.",
    )

    st.session_state["selected_model"] = st.selectbox(
        "Groq model",
        options=[
            "llama-3.3-70b-versatile",
            "llama-3.1-8b-instant",
            "llama-3.1-70b-versatile",
            "mixtral-8x7b-32768",
            "gemma2-9b-it",
        ],
        index=0,
    )

    st.markdown("---")
    st.markdown("### 📂 Inputs")
    transformed_file = st.file_uploader(
        "Transformed data (pre-load)", type=["csv"], key="upl_transformed"
    )
    loaded_file = st.file_uploader(
        "Loaded data (from S/4HANA)", type=["csv"], key="upl_loaded"
    )

    if transformed_file is not None:
        try:
            st.session_state["transformed_df"] = read_csv_smart(transformed_file)
            st.session_state["transformed_name"] = transformed_file.name
        except Exception as exc:  # noqa: BLE001
            st.error(f"Could not read transformed file: {exc}")

    if loaded_file is not None:
        try:
            st.session_state["loaded_df"] = read_csv_smart(loaded_file)
            st.session_state["loaded_name"] = loaded_file.name
        except Exception as exc:  # noqa: BLE001
            st.error(f"Could not read loaded file: {exc}")

    st.markdown("---")
    st.caption(
        "Enterprise reconciliation utility for SAP S/4HANA data migration."
        " Pre-load (transformed) vs. post-load values are compared "
        "column-by-column on a user-supplied key."
    )


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------
st.title("🔄 SAP S/4HANA Data Migration — Reconciliation")
st.markdown(
    "Upload your **transformed** (pre-load) and **loaded** (post-load) CSV files, "
    "pick one or more key columns, and the app will perform a column-by-column "
    "comparison and flag any row where at least one column does not match."
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _df_preview(df: pd.DataFrame | None, caption: str) -> None:
    if df is None:
        st.info(f"{caption} not uploaded yet.")
        return
    st.caption(f"{caption} — {len(df):,} rows × {df.shape[1]} columns")
    st.dataframe(df.head(10), use_container_width=True)


def _kpi_row(summary: dict) -> None:
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Total rows", f"{summary['total_rows']:,}")
    c2.metric("Matched", f"{summary['matched_rows']:,}")
    c3.metric("Mismatched", f"{summary['mismatched_rows']:,}")
    c4.metric("Match rate", f"{summary['match_rate_pct']}%")
    c5.metric("Columns compared", summary["compared_column_count"])

    c6, c7, c8, c9 = st.columns(4)
    c6.metric("Only in Transformed", summary["only_in_transformed"])
    c7.metric("Only in Loaded", summary["only_in_loaded"])
    c8.metric("Dup keys — Transformed", summary["duplicate_keys_transformed"])
    c9.metric("Dup keys — Loaded", summary["duplicate_keys_loaded"])


# ---------------------------------------------------------------------------
# Tabs
# ---------------------------------------------------------------------------
tab_upload, tab_dashboard, tab_mismatches, tab_downloads, tab_chat = st.tabs(
    ["📁 Upload & configure", "📊 Dashboard", "🔎 Mismatched rows", "⬇️ Downloads", "💬 Chat (Groq)"]
)


# ---- Upload tab -----------------------------------------------------------
with tab_upload:
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Transformed data")
        _df_preview(st.session_state["transformed_df"], "Transformed")
    with col2:
        st.subheader("Loaded data")
        _df_preview(st.session_state["loaded_df"], "Loaded")

    t_df = st.session_state["transformed_df"]
    l_df = st.session_state["loaded_df"]

    if t_df is not None and l_df is not None:
        st.markdown("---")
        st.subheader("Reconciliation setup")
        candidate_keys = [c for c in t_df.columns if c in l_df.columns]
        if not candidate_keys:
            st.error(
                "The two files share no column names — they cannot be reconciled. "
                "Please align headers and try again."
            )
        else:
            default_keys: list[str] = []
            for guess in (
                "MATNR", "KUNNR", "LIFNR", "BPARTNER", "BU_PARTNER",
                "ID", "Id", "id", "Key", "KEY", "PrimaryKey"
            ):
                if guess in candidate_keys:
                    default_keys = [guess]
                    break

            key_cols = st.multiselect(
                "Key column(s) — used to join transformed ↔ loaded",
                options=candidate_keys,
                default=default_keys,
                help="Pick the field(s) that uniquely identify a row on both sides.",
            )

            non_key_candidates = [c for c in candidate_keys if c not in key_cols]
            compare_cols = st.multiselect(
                "Columns to compare (defaults to all shared non-key columns)",
                options=non_key_candidates,
                default=non_key_candidates,
            )

            run = st.button("▶️ Run reconciliation", type="primary", use_container_width=False)
            if run:
                if not key_cols:
                    st.error("Please choose at least one key column.")
                elif not compare_cols:
                    st.error("Please choose at least one column to compare.")
                else:
                    with st.spinner("Reconciling…"):
                        engine = ReconciliationEngine(
                            transformed=t_df,
                            loaded=l_df,
                            key_columns=key_cols,
                            compare_columns=compare_cols,
                        )
                        st.session_state["result"] = engine.run()
                    st.success(
                        "Reconciliation complete. Switch to the Dashboard tab to review results."
                    )
    else:
        st.info("Upload both files in the sidebar to continue.", icon="📥")


# ---- Dashboard tab --------------------------------------------------------
with tab_dashboard:
    result = st.session_state["result"]
    if result is None:
        st.info("Run a reconciliation first (Upload & configure tab).")
    else:
        st.subheader("Reconciliation KPIs")
        _kpi_row(result.summary)

        st.markdown("---")

        left, right = st.columns([1, 1])

        with left:
            st.subheader("Match vs. mismatch")
            pie_df = pd.DataFrame(
                {
                    "Status": ["Matched", "Mismatched", "Only in T", "Only in L"],
                    "Rows": [
                        result.summary["matched_rows"],
                        result.summary["mismatched_rows"],
                        result.summary["only_in_transformed"],
                        result.summary["only_in_loaded"],
                    ],
                }
            )
            pie_df = pie_df[pie_df["Rows"] > 0]
            if pie_df.empty:
                st.info("No rows to chart.")
            else:
                try:
                    import altair as alt

                    chart = (
                        alt.Chart(pie_df)
                        .mark_arc(innerRadius=60)
                        .encode(
                            theta="Rows:Q",
                            color=alt.Color("Status:N", legend=alt.Legend(title="")),
                            tooltip=["Status", "Rows"],
                        )
                    )
                    st.altair_chart(chart, use_container_width=True)
                except Exception:  # noqa: BLE001
                    st.bar_chart(pie_df.set_index("Status"))

        with right:
            st.subheader("Top columns by mismatch count")
            cmc = result.column_mismatch_counts
            top = cmc[cmc["mismatch_count"] > 0].head(15)
            if top.empty:
                st.success("No column-level mismatches detected. 🎉")
            else:
                st.bar_chart(top.set_index("column"))

        st.markdown("---")
        st.subheader("Column-level mismatch table")
        st.dataframe(result.column_mismatch_counts, use_container_width=True, height=350)


# ---- Mismatched rows tab --------------------------------------------------
with tab_mismatches:
    result = st.session_state["result"]
    if result is None:
        st.info("Run a reconciliation first (Upload & configure tab).")
    else:
        mismatched = result.mismatched_rows
        st.subheader(f"Mismatched rows — {len(mismatched):,}")
        if mismatched.empty:
            st.success("All rows match across every compared column. 🎉")
        else:
            cmc = result.column_mismatch_counts
            mismatch_cols = cmc[cmc["mismatch_count"] > 0]["column"].tolist()
            focus = st.multiselect(
                "Highlight rows that differ on these columns (leave empty for ALL mismatches)",
                options=mismatch_cols,
            )

            view = mismatched.copy()
            if focus:
                # Keep rows where ANY of the focus columns differ.
                def _row_diff(row: pd.Series) -> bool:
                    for c in focus:
                        tcol = f"{c} [Transformed]"
                        lcol = f"{c} [Loaded]"
                        if tcol in row and lcol in row and str(row[tcol]) != str(row[lcol]):
                            return True
                    return False

                view = view[view.apply(_row_diff, axis=1)]

            st.caption(
                f"Showing {len(view):,} mismatched rows. "
                "Mismatch indicator is in the **Match Status** column; "
                "each compared column is shown side-by-side as `[Transformed]` vs. `[Loaded]`."
            )
            st.dataframe(view, use_container_width=True, height=520)

        if not result.only_in_transformed.empty or not result.only_in_loaded.empty:
            st.markdown("---")
            st.subheader("Rows present on only one side")
            c1, c2 = st.columns(2)
            with c1:
                st.markdown(f"**Only in Transformed — {len(result.only_in_transformed):,}**")
                st.dataframe(result.only_in_transformed, use_container_width=True, height=260)
            with c2:
                st.markdown(f"**Only in Loaded — {len(result.only_in_loaded):,}**")
                st.dataframe(result.only_in_loaded, use_container_width=True, height=260)


# ---- Downloads tab --------------------------------------------------------
with tab_downloads:
    result = st.session_state["result"]
    if result is None:
        st.info("Run a reconciliation first (Upload & configure tab).")
    else:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")

        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown("### Excel report")
            st.caption("Multi-sheet workbook with summary, mismatched rows, field diffs, matched rows.")
            xlsx_bytes = build_excel_report(result)
            st.download_button(
                "⬇️ Download .xlsx",
                data=xlsx_bytes,
                file_name=f"reconciliation_report_{ts}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
            )

        with col2:
            st.markdown("### Mismatches CSV")
            st.caption("Just the rows that did not match — side-by-side columns.")
            csv_bytes = build_mismatch_csv(result)
            st.download_button(
                "⬇️ Download .csv",
                data=csv_bytes,
                file_name=f"mismatched_rows_{ts}.csv",
                mime="text/csv",
                use_container_width=True,
            )

        with col3:
            st.markdown("### PDF executive summary")
            st.caption("One-page summary of KPIs, top mismatch columns and a sample diff table.")
            try:
                pdf_bytes = build_pdf_summary(result)
                st.download_button(
                    "⬇️ Download .pdf",
                    data=pdf_bytes,
                    file_name=f"reconciliation_summary_{ts}.pdf",
                    mime="application/pdf",
                    use_container_width=True,
                )
            except Exception as exc:  # noqa: BLE001
                st.error(f"PDF generation failed: {exc}")


# ---- Chat tab -------------------------------------------------------------
with tab_chat:
    st.subheader("💬 Ask questions about the reconciliation report")
    result = st.session_state["result"]
    if result is None:
        st.info("Run a reconciliation first (Upload & configure tab) — then chat about it here.")
    else:
        api_key = resolve_api_key(st.session_state["sidebar_api_key"])
        if not api_key:
            st.warning(
                "No Groq API key available. Set the `GROQ_API_KEY` env var "
                "or enter a key in the sidebar to enable chat.",
                icon="🔑",
            )
        else:
            # Build context once per chat turn.
            ctx = ReconciliationContext(
                summary=result.summary,
                key_columns=result.key_columns,
                compared_columns=result.compared_columns,
                column_mismatch_counts=result.column_mismatch_counts,
                field_diffs_sample=result.field_diffs.head(60),
                mismatched_rows_sample=result.mismatched_rows.head(25),
            )

            # Suggested prompts as quick-fire buttons.
            st.caption("Suggested questions:")
            suggestions = [
                "Give me an executive summary of the reconciliation health.",
                "Which columns have the most mismatches and what could be causing them?",
                "Are there systemic patterns in the mismatches (truncation, formatting, value-mapping gaps)?",
                "List the top 5 mismatched rows that I should investigate first.",
                "What concrete next steps should the migration team take?",
            ]
            cols = st.columns(len(suggestions))
            pending_prompt: str | None = None
            for i, s in enumerate(suggestions):
                if cols[i].button(s, use_container_width=True, key=f"sugg_{i}"):
                    pending_prompt = s

            # Replay history
            for m in st.session_state["chat_history"]:
                with st.chat_message(m.role):
                    st.markdown(m.content)

            # Live input
            user_input = st.chat_input("Ask anything about your reconciliation report…")
            prompt = pending_prompt or user_input
            if prompt:
                with st.chat_message("user"):
                    st.markdown(prompt)
                st.session_state["chat_history"].append(ChatMessage("user", prompt))

                try:
                    chat = GroqChat(
                        api_key=api_key,
                        model=st.session_state["selected_model"],
                    )
                    with st.chat_message("assistant"):
                        with st.spinner("Thinking…"):
                            answer = chat.ask(
                                user_message=prompt,
                                context=ctx,
                                history=st.session_state["chat_history"][:-1],
                            )
                        st.markdown(answer)
                    st.session_state["chat_history"].append(ChatMessage("assistant", answer))
                except Exception as exc:  # noqa: BLE001
                    st.error(f"Groq call failed: {exc}")

            if st.session_state["chat_history"]:
                if st.button("🧹 Clear conversation"):
                    st.session_state["chat_history"] = []
                    st.rerun()
