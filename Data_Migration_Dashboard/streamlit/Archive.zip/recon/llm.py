"""Groq LLM chat wrapper for grounded Q&A on the reconciliation report."""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Iterable, List, Optional

import pandas as pd

try:
    from groq import Groq
except ImportError:  # pragma: no cover
    Groq = None  # type: ignore[assignment]


# Default model — Groq's Llama 3.1 70B is solid for analytical Q&A and free-tier friendly.
DEFAULT_MODEL = "llama-3.3-70b-versatile"

SYSTEM_PROMPT = """You are an SAP S/4HANA Data Migration Reconciliation Analyst.
You help the user analyze a reconciliation report comparing TRANSFORMED data
(pre-load) against LOADED data (the values that actually ended up in S/4HANA).

You will be given:
  • A structured summary of the reconciliation run (counts, match rate, etc.).
  • Per-column mismatch counts.
  • A representative sample of the field-level diffs.
  • A representative sample of the mismatched rows.

Rules:
  1. Ground every answer in the data the user has loaded. Quote numbers from
     the summary or per-column counts. If the data does not support an answer,
     say so plainly — never fabricate field names or values.
  2. Be precise and concise. Prefer short, tight paragraphs over rambling.
     Use bullet points only for genuine lists.
  3. When the user asks for a root-cause hypothesis on a recurring mismatch,
     consider classic migration causes: incorrect data type conversion,
     truncation, code list / value-mapping gaps, leading-zero handling,
     decimal/locale differences, encoding issues, missing mandatory fields,
     wrong unit-of-measure, date format drift, language key mismatches.
  4. When asked to summarize, organize by (a) overall health, (b) the worst
     columns, (c) systemic patterns, (d) concrete next steps.
  5. Never invent rows that aren't in the provided samples.
"""


@dataclass
class ChatMessage:
    role: str
    content: str


@dataclass
class ReconciliationContext:
    """The slice of the reconciliation result we hand to the LLM."""

    summary: dict
    key_columns: List[str]
    compared_columns: List[str]
    column_mismatch_counts: pd.DataFrame
    field_diffs_sample: pd.DataFrame
    mismatched_rows_sample: pd.DataFrame
    sample_row_limit: int = 25
    sample_diff_limit: int = 60

    def to_prompt_block(self) -> str:
        parts: list[str] = []
        parts.append("## Reconciliation summary")
        parts.append("```json")
        parts.append(json.dumps(self.summary, indent=2, default=str))
        parts.append("```")

        parts.append("\n## Key columns")
        parts.append(", ".join(self.key_columns) or "(none)")

        parts.append("\n## Compared columns")
        parts.append(", ".join(self.compared_columns) or "(none)")

        parts.append("\n## Mismatch counts per column")
        if self.column_mismatch_counts is None or self.column_mismatch_counts.empty:
            parts.append("(no mismatches)")
        else:
            parts.append(
                self.column_mismatch_counts.head(40).to_csv(index=False).strip()
            )

        parts.append("\n## Field-level diff sample")
        if self.field_diffs_sample is None or self.field_diffs_sample.empty:
            parts.append("(no field diffs)")
        else:
            parts.append(
                self.field_diffs_sample.head(self.sample_diff_limit)
                .to_csv(index=False)
                .strip()
            )

        parts.append("\n## Mismatched-rows sample (side-by-side)")
        if self.mismatched_rows_sample is None or self.mismatched_rows_sample.empty:
            parts.append("(no mismatched rows)")
        else:
            parts.append(
                self.mismatched_rows_sample.head(self.sample_row_limit)
                .to_csv(index=False)
                .strip()
            )

        return "\n".join(parts)


class GroqChat:
    """Thin wrapper around Groq's chat-completions endpoint."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = DEFAULT_MODEL,
        temperature: float = 0.2,
    ):
        if Groq is None:
            raise RuntimeError(
                "The 'groq' Python package is not installed. "
                "Run: pip install groq"
            )
        key = api_key or os.environ.get("GROQ_API_KEY")
        if not key:
            raise RuntimeError(
                "No Groq API key supplied. Provide one via the sidebar "
                "or set the GROQ_API_KEY environment variable."
            )
        self._client = Groq(api_key=key)
        self.model = model
        self.temperature = temperature

    # ------------------------------------------------------------------
    def ask(
        self,
        user_message: str,
        context: ReconciliationContext,
        history: Iterable[ChatMessage] = (),
    ) -> str:
        """Single-shot Q&A grounded on the reconciliation context."""
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "system",
                "content": (
                    "Below is the current reconciliation report. Use it as the "
                    "single source of truth for your answers.\n\n"
                    + context.to_prompt_block()
                ),
            },
        ]
        for m in history:
            if m.role in {"user", "assistant"}:
                messages.append({"role": m.role, "content": m.content})

        messages.append({"role": "user", "content": user_message})

        resp = self._client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=self.temperature,
            max_tokens=1024,
        )
        return resp.choices[0].message.content or ""


def resolve_api_key(sidebar_key: str | None) -> str | None:
    """Env-first, sidebar-fallback resolution."""
    env_key = os.environ.get("GROQ_API_KEY", "").strip()
    if env_key:
        return env_key
    if sidebar_key and sidebar_key.strip():
        return sidebar_key.strip()
    return None
