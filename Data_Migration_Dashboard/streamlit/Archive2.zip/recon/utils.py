"""Utility helpers for CSV ingestion and value normalization."""
from __future__ import annotations

import io
import math
from typing import Any, Iterable, List

import pandas as pd


def read_csv_smart(file_like: Any) -> pd.DataFrame:
    """Read a CSV from an upload buffer, trying multiple encodings/separators.

    The function is defensive: SAP export files frequently come in cp1252 with
    semicolon separators. Falls back gracefully.
    """
    raw: bytes
    if hasattr(file_like, "read"):
        raw = file_like.read()
        if isinstance(raw, str):
            raw = raw.encode("utf-8", errors="replace")
    else:
        with open(file_like, "rb") as fh:
            raw = fh.read()

    encodings = ["utf-8-sig", "utf-8", "cp1252", "latin-1"]
    separators = [",", ";", "\t", "|"]

    last_err: Exception | None = None
    for enc in encodings:
        try:
            text = raw.decode(enc)
        except UnicodeDecodeError as exc:
            last_err = exc
            continue
        for sep in separators:
            try:
                df = pd.read_csv(
                    io.StringIO(text),
                    sep=sep,
                    dtype=str,
                    keep_default_na=False,
                    na_values=["", "NA", "NaN", "null", "None"],
                    engine="python",
                )
                if df.shape[1] >= 2:
                    df.columns = [str(c).strip() for c in df.columns]
                    return df
            except Exception as exc:  # noqa: BLE001
                last_err = exc
                continue

    raise ValueError(f"Could not parse CSV file: {last_err}")


def normalize_value(value: Any) -> str:
    """Return a canonical string representation for comparison.

    - Trims whitespace.
    - Treats None / NaN / empty-string as the sentinel ``"<NULL>"``.
    - Normalizes numeric strings so ``"1.0"`` and ``"1"`` compare equal.
    - Lowercases booleans-as-strings.
    """
    if value is None:
        return "<NULL>"
    if isinstance(value, float) and math.isnan(value):
        return "<NULL>"

    s = str(value).strip()
    if s == "" or s.lower() in {"nan", "none", "null"}:
        return "<NULL>"

    # numeric normalization
    try:
        f = float(s.replace(",", ""))
        if math.isfinite(f):
            if f == int(f):
                return str(int(f))
            return f"{f:.10g}"
    except (ValueError, TypeError):
        pass

    low = s.lower()
    if low in {"true", "false"}:
        return low
    return s


def coerce_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy where every cell has been run through ``normalize_value``."""
    out = df.copy()
    for col in out.columns:
        out[col] = out[col].map(normalize_value)
    return out


def common_columns(a: Iterable[str], b: Iterable[str]) -> List[str]:
    """Order-preserving intersection on the LHS."""
    bs = set(b)
    seen: set[str] = set()
    out: list[str] = []
    for c in a:
        if c in bs and c not in seen:
            seen.add(c)
            out.append(c)
    return out
