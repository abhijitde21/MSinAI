"""SAP Generative AI Hub LLM chat wrapper for grounded Q&A on the reconciliation report."""
from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass
from typing import Iterable, List, Optional

import pandas as pd
import requests


logger = logging.getLogger(__name__)


# Logical model identifiers exposed to the UI.  These are user-facing labels
# only — the actual model is selected on SAP AI Core by the deployment URL.
MODEL_OPENAI = "sap-genai-hub/openai"
MODEL_ANTHROPIC = "sap-genai-hub/anthropic"
DEFAULT_MODEL = MODEL_OPENAI

SYSTEM_PROMPT = """You are an SAP S/4HANA Data Migration Reconciliation Analyst.
You help the user analyze a reconciliation report comparing TRANSFORMED data
(pre-load) against LOADED data (the values that actually ended up in S/4HANA).

You will be given:
  • A structured summary of the reconciliation run (counts, match rate, etc.).
  • Per-column mismatch counts.
  • A representative sample of the field-level diffs.
  • A representative sample of the mismatched rows.

Rules:
  1. Ground every answer in the data the user has loaded. Quote numbers from
     the summary or per-column counts. If the data does not support an answer,
     say so plainly — never fabricate field names or values.
  2. Be precise and concise. Prefer short, tight paragraphs over rambling.
     Use bullet points only for genuine lists.
  3. When the user asks for a root-cause hypothesis on a recurring mismatch,
     consider classic migration causes: incorrect data type conversion,
     truncation, code list / value-mapping gaps, leading-zero handling,
     decimal/locale differences, encoding issues, missing mandatory fields,
     wrong unit-of-measure, date format drift, language key mismatches.
  4. When asked to summarize, organize by (a) overall health, (b) the worst
     columns, (c) systemic patterns, (d) concrete next steps.
  5. Never invent rows that aren't in the provided samples.
"""


@dataclass
class ChatMessage:
    role: str
    content: str


@dataclass
class ReconciliationContext:
    """The slice of the reconciliation result we hand to the LLM."""

    summary: dict
    key_columns: List[str]
    compared_columns: List[str]
    column_mismatch_counts: pd.DataFrame
    field_diffs_sample: pd.DataFrame
    mismatched_rows_sample: pd.DataFrame
    sample_row_limit: int = 25
    sample_diff_limit: int = 60

    def to_prompt_block(self) -> str:
        parts: list[str] = []
        parts.append("## Reconciliation summary")
        parts.append("```json")
        parts.append(json.dumps(self.summary, indent=2, default=str))
        parts.append("```")

        parts.append("\n## Key columns")
        parts.append(", ".join(self.key_columns) or "(none)")

        parts.append("\n## Compared columns")
        parts.append(", ".join(self.compared_columns) or "(none)")

        parts.append("\n## Mismatch counts per column")
        if self.column_mismatch_counts is None or self.column_mismatch_counts.empty:
            parts.append("(no mismatches)")
        else:
            parts.append(
                self.column_mismatch_counts.head(40).to_csv(index=False).strip()
            )

        parts.append("\n## Field-level diff sample")
        if self.field_diffs_sample is None or self.field_diffs_sample.empty:
            parts.append("(no field diffs)")
        else:
            parts.append(
                self.field_diffs_sample.head(self.sample_diff_limit)
                .to_csv(index=False)
                .strip()
            )

        parts.append("\n## Mismatched-rows sample (side-by-side)")
        if self.mismatched_rows_sample is None or self.mismatched_rows_sample.empty:
            parts.append("(no mismatched rows)")
        else:
            parts.append(
                self.mismatched_rows_sample.head(self.sample_row_limit)
                .to_csv(index=False)
                .strip()
            )

        return "\n".join(parts)


# ---------------------------------------------------------------------------
# SAP Generative AI Hub config
# ---------------------------------------------------------------------------
@dataclass
class SAPGenAIHubConfig:
    """OAuth + deployment configuration for SAP Generative AI Hub."""

    grant_type: str
    client_id: str
    client_secret: str
    access_auth_token: str        # OAuth token endpoint URL
    llm_call_url: str             # /v2/inference/deployments/<id>/chat/completions or /converse
    resource_group: str = "default"

    @classmethod
    def from_env(cls, overrides: Optional[dict] = None) -> "SAPGenAIHubConfig":
        overrides = overrides or {}

        def pick(name: str, default: str = "") -> str:
            val = overrides.get(name)
            if val:
                return str(val).strip()
            return os.environ.get(name, default).strip()

        return cls(
            grant_type=pick("grant_type", "client_credentials"),
            client_id=pick("client_id"),
            client_secret=pick("client_secret"),
            access_auth_token=pick("access_auth_token"),
            llm_call_url=pick("llm_call_url"),
            resource_group=pick("AICORE_RESOURCE_GROUP", "default"),
        )

    def missing_fields(self) -> List[str]:
        required = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "access_auth_token": self.access_auth_token,
            "llm_call_url": self.llm_call_url,
        }
        return [k for k, v in required.items() if not v]


class SAPGenAIHubChat:
    """Thin wrapper around the SAP Generative AI Hub inference endpoint.

    Supports two payload styles based on the deployed model family:
      * ``openai``    — OpenAI-compatible chat-completions schema (default).
      * ``anthropic`` — Bedrock-style ``converse`` schema used by Claude
                        deployments on AI Core.
    """

    def __init__(
        self,
        config: Optional[SAPGenAIHubConfig] = None,
        model: str = DEFAULT_MODEL,
        temperature: float = 0.2,
        max_tokens: int = 1024,
    ):
        self.config = config or SAPGenAIHubConfig.from_env()
        missing = self.config.missing_fields()
        if missing:
            raise RuntimeError(
                "SAP Generative AI Hub is not fully configured. Missing: "
                + ", ".join(missing)
                + ". Provide values via environment variables or the sidebar."
            )
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens

        self._access_token: Optional[str] = None
        self._token_expiry: float = 0.0

    # ------------------------------------------------------------------
    def _get_access_token(self) -> str:
        """Fetch (and cache) an OAuth bearer token from SAP XSUAA."""
        if self._access_token and time.time() < self._token_expiry:
            return self._access_token

        data = {
            "grant_type": self.config.grant_type,
            "client_id": self.config.client_id,
            "client_secret": self.config.client_secret,
        }
        resp = requests.post(self.config.access_auth_token, data=data, timeout=30)
        if resp.status_code != 200:
            raise RuntimeError(
                f"Failed to retrieve SAP GenAI Hub token "
                f"(HTTP {resp.status_code}): {resp.text[:300]}"
            )
        body = resp.json()
        token = body.get("access_token")
        if not token:
            raise RuntimeError(
                "SAP GenAI Hub token response did not include an access_token."
            )
        expires_in = int(body.get("expires_in", 3600))
        self._access_token = token
        self._token_expiry = time.time() + expires_in - 60
        return token

    # ------------------------------------------------------------------
    def _headers(self, bearer: str) -> dict:
        return {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "AI-Resource-Group": self.config.resource_group,
            "Authorization": f"Bearer {bearer}",
        }

    # ------------------------------------------------------------------
    def _call_openai_style(self, messages: list[dict]) -> str:
        bearer = self._get_access_token()
        payload = {
            "messages": messages,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "frequency_penalty": 0.4,
            "presence_penalty": 0.4,
        }
        resp = requests.post(
            self.config.llm_call_url,
            headers=self._headers(bearer),
            data=json.dumps(payload),
            timeout=120,
        )
        if resp.status_code != 200:
            raise RuntimeError(
                f"SAP GenAI Hub call failed (HTTP {resp.status_code}): "
                f"{resp.text[:500]}"
            )
        body = json.loads(resp.text)
        try:
            return body["choices"][0]["message"]["content"] or ""
        except (KeyError, IndexError, TypeError) as exc:
            raise RuntimeError(
                f"Unexpected SAP GenAI Hub response shape: {body}"
            ) from exc

    # ------------------------------------------------------------------
    def _call_anthropic_style(
        self, system_text: str, messages: list[dict]
    ) -> str:
        """Bedrock-style ``converse`` payload for Claude deployments."""
        bearer = self._get_access_token()
        converse_messages = [
            {"role": m["role"], "content": [{"text": m["content"]}]}
            for m in messages
            if m["role"] in {"user", "assistant"}
        ]
        payload: dict = {
            "inferenceConfig": {
                "maxTokens": self.max_tokens,
                "temperature": self.temperature,
            },
            "messages": converse_messages,
        }
        if system_text:
            payload["system"] = [{"text": system_text}]

        resp = requests.post(
            self.config.llm_call_url,
            headers=self._headers(bearer),
            data=json.dumps(payload),
            timeout=120,
        )
        if resp.status_code != 200:
            raise RuntimeError(
                f"SAP GenAI Hub call failed (HTTP {resp.status_code}): "
                f"{resp.text[:500]}"
            )
        body = json.loads(resp.text)
        try:
            text = body["output"]["message"]["content"][0]["text"] or ""
            return text.replace(" ", "")
        except (KeyError, IndexError, TypeError) as exc:
            raise RuntimeError(
                f"Unexpected SAP GenAI Hub response shape: {body}"
            ) from exc

    # ------------------------------------------------------------------
    def ask(
        self,
        user_message: str,
        context: ReconciliationContext,
        history: Iterable[ChatMessage] = (),
    ) -> str:
        """Single-shot Q&A grounded on the reconciliation context."""
        grounding = (
            "Below is the current reconciliation report. Use it as the "
            "single source of truth for your answers.\n\n"
            + context.to_prompt_block()
        )

        if self.model == MODEL_ANTHROPIC:
            # Claude on Bedrock-style converse — system goes outside `messages`.
            chat_msgs: list[dict] = []
            for m in history:
                if m.role in {"user", "assistant"}:
                    chat_msgs.append({"role": m.role, "content": m.content})
            chat_msgs.append({"role": "user", "content": user_message})
            system_text = SYSTEM_PROMPT + "\n\n" + grounding
            return self._call_anthropic_style(system_text, chat_msgs)

        # Default: OpenAI-compatible chat-completions
        messages: list[dict] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "system", "content": grounding},
        ]
        for m in history:
            if m.role in {"user", "assistant"}:
                messages.append({"role": m.role, "content": m.content})
        messages.append({"role": "user", "content": user_message})
        return self._call_openai_style(messages)


def resolve_sap_genai_config(sidebar_overrides: Optional[dict] = None) -> SAPGenAIHubConfig:
    """Build an SAPGenAIHubConfig from env vars, with optional sidebar overrides."""
    return SAPGenAIHubConfig.from_env(overrides=sidebar_overrides)


def sap_genai_config_ready(sidebar_overrides: Optional[dict] = None) -> bool:
    """True iff every required SAP GenAI Hub field is present."""
    try:
        cfg = resolve_sap_genai_config(sidebar_overrides)
    except Exception:  # noqa: BLE001
        return False
    return not cfg.missing_fields()
