"""Report exporters: Excel, CSV, PDF."""
from __future__ import annotations

import io
from datetime import datetime
from typing import TYPE_CHECKING

import pandas as pd

if TYPE_CHECKING:
    from .engine import ReconciliationResult


# ---------------------------------------------------------------------------
# Excel
# ---------------------------------------------------------------------------
def build_excel_report(result: "ReconciliationResult") -> bytes:
    """Return a multi-sheet xlsx as bytes."""
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        # Summary
        summary_df = pd.DataFrame(
            [{"metric": k, "value": _stringify(v)} for k, v in result.summary.items()]
        )
        summary_df.to_excel(writer, sheet_name="Summary", index=False)

        # Column-level counts
        if result.column_mismatch_counts is not None:
            result.column_mismatch_counts.to_excel(
                writer, sheet_name="Mismatches by Column", index=False
            )

        # Mismatched rows (side-by-side)
        if result.mismatched_rows is not None and not result.mismatched_rows.empty:
            result.mismatched_rows.to_excel(
                writer, sheet_name="Mismatched Rows", index=False
            )
        else:
            pd.DataFrame({"info": ["No mismatched rows found"]}).to_excel(
                writer, sheet_name="Mismatched Rows", index=False
            )

        # Field-level diffs
        if result.field_diffs is not None and not result.field_diffs.empty:
            result.field_diffs.to_excel(
                writer, sheet_name="Field-level Diffs", index=False
            )
        else:
            pd.DataFrame({"info": ["No field-level diffs"]}).to_excel(
                writer, sheet_name="Field-level Diffs", index=False
            )

        # Matched rows (capped to keep file size sane)
        cap = 20000
        matched = result.matched_rows.head(cap) if result.matched_rows is not None else pd.DataFrame()
        matched.to_excel(writer, sheet_name="Matched Rows", index=False)

        # Missing rows on each side
        if result.only_in_transformed is not None and not result.only_in_transformed.empty:
            result.only_in_transformed.to_excel(
                writer, sheet_name="Only in Transformed", index=False
            )
        if result.only_in_loaded is not None and not result.only_in_loaded.empty:
            result.only_in_loaded.to_excel(
                writer, sheet_name="Only in Loaded", index=False
            )

    return buffer.getvalue()


# ---------------------------------------------------------------------------
# CSV (mismatches only)
# ---------------------------------------------------------------------------
def build_mismatch_csv(result: "ReconciliationResult") -> bytes:
    if result.mismatched_rows is None or result.mismatched_rows.empty:
        return b"info\nNo mismatched rows found\n"
    return result.mismatched_rows.to_csv(index=False).encode("utf-8")


# ---------------------------------------------------------------------------
# PDF — one-page executive summary
# ---------------------------------------------------------------------------
def build_pdf_summary(result: "ReconciliationResult", title: str = "SAP S/4HANA Data Migration — Reconciliation Report") -> bytes:
    """Generate a one-page executive PDF summary using ReportLab."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import (
        SimpleDocTemplate,
        Paragraph,
        Spacer,
        Table,
        TableStyle,
        PageBreak,
    )
    from reportlab.graphics.shapes import Drawing
    from reportlab.graphics.charts.barcharts import HorizontalBarChart

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=1.5 * cm,
        rightMargin=1.5 * cm,
        topMargin=1.5 * cm,
        bottomMargin=1.5 * cm,
        title="Reconciliation Report",
    )

    styles = getSampleStyleSheet()
    h1 = ParagraphStyle(
        "h1",
        parent=styles["Heading1"],
        textColor=colors.HexColor("#0b3d91"),
        spaceAfter=6,
    )
    h2 = ParagraphStyle(
        "h2",
        parent=styles["Heading2"],
        textColor=colors.HexColor("#0b3d91"),
        spaceBefore=10,
        spaceAfter=4,
    )
    body = styles["BodyText"]

    story: list = []
    story.append(Paragraph(title, h1))
    story.append(
        Paragraph(
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            body,
        )
    )
    story.append(Spacer(1, 0.3 * cm))

    # KPI block
    s = result.summary
    kpi_rows = [
        ["Total rows analysed", s.get("total_rows", 0)],
        ["Rows in both files", s.get("rows_in_both", 0)],
        ["Matched rows", s.get("matched_rows", 0)],
        ["Mismatched rows", s.get("mismatched_rows", 0)],
        ["Only in Transformed", s.get("only_in_transformed", 0)],
        ["Only in Loaded", s.get("only_in_loaded", 0)],
        ["Match rate (%)", s.get("match_rate_pct", 0.0)],
        ["Mismatch rate (%)", s.get("mismatch_rate_pct", 0.0)],
        ["Duplicate keys (Transformed)", s.get("duplicate_keys_transformed", 0)],
        ["Duplicate keys (Loaded)", s.get("duplicate_keys_loaded", 0)],
        ["Columns compared", s.get("compared_column_count", 0)],
        ["Key columns", ", ".join(s.get("key_columns", []))],
    ]

    story.append(Paragraph("Executive summary", h2))
    table = Table(
        [["Metric", "Value"]] + [[k, _stringify(v)] for k, v in kpi_rows],
        colWidths=[7 * cm, 9 * cm],
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0b3d91")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#bbbbbb")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
            ]
        )
    )
    story.append(table)

    # Top-mismatch column chart
    cmc = result.column_mismatch_counts
    if cmc is not None and not cmc.empty:
        top = cmc[cmc["mismatch_count"] > 0].head(10)
        if not top.empty:
            story.append(Spacer(1, 0.5 * cm))
            story.append(Paragraph("Top columns with mismatches", h2))

            drawing = Drawing(420, 22 * len(top) + 60)
            chart = HorizontalBarChart()
            chart.x = 110
            chart.y = 20
            chart.height = 22 * len(top)
            chart.width = 270
            chart.data = [list(top["mismatch_count"].astype(int))]
            chart.categoryAxis.categoryNames = list(top["column"])
            chart.categoryAxis.labels.fontSize = 8
            chart.valueAxis.valueMin = 0
            chart.valueAxis.labels.fontSize = 8
            chart.bars[0].fillColor = colors.HexColor("#0b3d91")
            drawing.add(chart)
            story.append(drawing)

    # Field-level sample
    if result.field_diffs is not None and not result.field_diffs.empty:
        story.append(PageBreak())
        story.append(Paragraph("Sample field-level differences (first 25)", h2))
        sample = result.field_diffs.head(25).copy()
        for col in ("transformed_value", "loaded_value"):
            if col in sample.columns:
                sample[col] = sample[col].astype(str).str.slice(0, 60)
        data = [list(sample.columns)] + sample.astype(str).values.tolist()
        diff_table = Table(data, repeatRows=1)
        diff_table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0b3d91")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, -1), 7),
                    ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#cccccc")),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
                ]
            )
        )
        story.append(diff_table)

    doc.build(story)
    return buffer.getvalue()


# ---------------------------------------------------------------------------
def _stringify(value) -> str:
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value)
    return str(value)
