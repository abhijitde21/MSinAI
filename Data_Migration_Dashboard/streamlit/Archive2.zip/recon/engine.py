"""Core reconciliation engine.

Performs column-by-column comparison of two CSV-derived dataframes
representing the transformed (pre-load) and loaded (post-load) view of
the same SAP S/4HANA migration object.

The engine is object-agnostic — the user picks one or more key columns
at upload time to join the two sides.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import pandas as pd

from .utils import coerce_dataframe, common_columns


# Sentinel rendered when one side does not have a row for a given key.
MISSING_TOKEN = "<MISSING>"


@dataclass
class ReconciliationResult:
    """Container for the full reconciliation output."""

    summary: dict = field(default_factory=dict)
    matched_rows: pd.DataFrame = field(default_factory=pd.DataFrame)
    mismatched_rows: pd.DataFrame = field(default_factory=pd.DataFrame)
    field_diffs: pd.DataFrame = field(default_factory=pd.DataFrame)
    column_mismatch_counts: pd.DataFrame = field(default_factory=pd.DataFrame)
    only_in_transformed: pd.DataFrame = field(default_factory=pd.DataFrame)
    only_in_loaded: pd.DataFrame = field(default_factory=pd.DataFrame)
    key_columns: List[str] = field(default_factory=list)
    compared_columns: List[str] = field(default_factory=list)

    # ---------- convenience ----------
    @property
    def total_rows(self) -> int:
        return int(self.summary.get("total_rows", 0))

    @property
    def match_rate(self) -> float:
        total = self.total_rows
        if total == 0:
            return 0.0
        matched = int(self.summary.get("matched_rows", 0))
        return round(matched / total * 100, 2)


class ReconciliationEngine:
    """Reconcile transformed vs. loaded datasets.

    Parameters
    ----------
    transformed:
        DataFrame of the transformed (pre-load) records.
    loaded:
        DataFrame of the loaded (post-load, from S/4HANA) records.
    key_columns:
        One or more columns that uniquely identify a row on both sides.
    compare_columns:
        Optional explicit list of columns to compare. If omitted, the
        intersection of non-key columns from both sides is used.
    """

    def __init__(
        self,
        transformed: pd.DataFrame,
        loaded: pd.DataFrame,
        key_columns: List[str],
        compare_columns: Optional[List[str]] = None,
    ):
        if not key_columns:
            raise ValueError("At least one key column must be supplied.")

        missing_t = [c for c in key_columns if c not in transformed.columns]
        missing_l = [c for c in key_columns if c not in loaded.columns]
        if missing_t or missing_l:
            raise ValueError(
                f"Key columns missing — transformed: {missing_t}, loaded: {missing_l}"
            )

        self.key_columns = list(key_columns)
        self._t_raw = transformed
        self._l_raw = loaded

        # Decide which non-key columns to compare.
        if compare_columns is None:
            non_key_t = [c for c in transformed.columns if c not in self.key_columns]
            non_key_l = [c for c in loaded.columns if c not in self.key_columns]
            self.compare_columns = common_columns(non_key_t, non_key_l)
        else:
            self.compare_columns = list(compare_columns)

    # ------------------------------------------------------------------
    # public API
    # ------------------------------------------------------------------
    def run(self) -> ReconciliationResult:
        # Normalize both sides for fair comparison.
        t = coerce_dataframe(self._t_raw)
        l = coerce_dataframe(self._l_raw)

        # Build a composite key column for join semantics.
        t["__key__"] = t[self.key_columns].astype(str).agg(" | ".join, axis=1)
        l["__key__"] = l[self.key_columns].astype(str).agg(" | ".join, axis=1)

        # De-duplicate keys, keeping first occurrence — and report dupes.
        t_dupes = int(t["__key__"].duplicated().sum())
        l_dupes = int(l["__key__"].duplicated().sum())
        t = t.drop_duplicates(subset="__key__", keep="first")
        l = l.drop_duplicates(subset="__key__", keep="first")

        # Outer join so we capture missing rows on either side.
        merged = t.merge(
            l,
            on="__key__",
            how="outer",
            suffixes=("__T", "__L"),
            indicator=True,
        )

        only_in_t = merged[merged["_merge"] == "left_only"].copy()
        only_in_l = merged[merged["_merge"] == "right_only"].copy()
        both = merged[merged["_merge"] == "both"].copy()

        # Build per-row mismatch flags + collect field-level diffs.
        diffs_records: list[dict] = []
        mismatch_flags = pd.Series(False, index=both.index)
        per_column_counts: dict[str, int] = {c: 0 for c in self.compare_columns}

        for col in self.compare_columns:
            t_col = f"{col}__T"
            l_col = f"{col}__L"

            if t_col not in both.columns or l_col not in both.columns:
                # Column is not really present on both sides; skip.
                continue

            differ = both[t_col].fillna("<NULL>") != both[l_col].fillna("<NULL>")
            mismatch_flags = mismatch_flags | differ
            per_column_counts[col] = int(differ.sum())

            if differ.any():
                sub = both.loc[differ, ["__key__", t_col, l_col]].copy()
                sub.columns = ["key", "transformed_value", "loaded_value"]
                sub.insert(0, "column", col)
                diffs_records.append(sub)

        field_diffs = (
            pd.concat(diffs_records, ignore_index=True)
            if diffs_records
            else pd.DataFrame(columns=["column", "key", "transformed_value", "loaded_value"])
        )

        # Build presentation frames.
        both["__match_status__"] = ["MATCH" if not m else "MISMATCH" for m in mismatch_flags]

        matched_rows = self._reshape_rows(both[~mismatch_flags], status="MATCH")
        mismatched_rows = self._reshape_rows(both[mismatch_flags], status="MISMATCH")

        only_in_t_out = self._reshape_one_sided(only_in_t, side="T")
        only_in_l_out = self._reshape_one_sided(only_in_l, side="L")

        column_mismatch_counts = (
            pd.DataFrame(
                [{"column": c, "mismatch_count": n} for c, n in per_column_counts.items()]
            )
            .sort_values("mismatch_count", ascending=False)
            .reset_index(drop=True)
        )

        total_rows = len(both) + len(only_in_t) + len(only_in_l)
        matched_n = int((~mismatch_flags).sum())
        mismatched_n = int(mismatch_flags.sum())

        summary = {
            "total_rows": total_rows,
            "rows_in_both": int(len(both)),
            "matched_rows": matched_n,
            "mismatched_rows": mismatched_n,
            "only_in_transformed": int(len(only_in_t)),
            "only_in_loaded": int(len(only_in_l)),
            "duplicate_keys_transformed": t_dupes,
            "duplicate_keys_loaded": l_dupes,
            "compared_column_count": len(self.compare_columns),
            "key_columns": self.key_columns,
            "match_rate_pct": round((matched_n / total_rows * 100) if total_rows else 0.0, 2),
            "mismatch_rate_pct": round((mismatched_n / total_rows * 100) if total_rows else 0.0, 2),
        }

        return ReconciliationResult(
            summary=summary,
            matched_rows=matched_rows,
            mismatched_rows=mismatched_rows,
            field_diffs=field_diffs,
            column_mismatch_counts=column_mismatch_counts,
            only_in_transformed=only_in_t_out,
            only_in_loaded=only_in_l_out,
            key_columns=self.key_columns,
            compared_columns=self.compare_columns,
        )

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------
    def _reshape_rows(self, df: pd.DataFrame, status: str) -> pd.DataFrame:
        """Side-by-side view: key cols, then for each compared col a T / L pair."""
        if df.empty:
            cols = ["__match_status__", *self.key_columns]
            for c in self.compare_columns:
                cols.extend([f"{c} [Transformed]", f"{c} [Loaded]"])
            return pd.DataFrame(columns=cols)

        out_cols: dict[str, pd.Series] = {"__match_status__": df["__match_status__"]}

        # Key columns — they are duplicated as __T/__L; prefer T then fall back to L.
        for k in self.key_columns:
            t_col = f"{k}__T"
            l_col = f"{k}__L"
            if t_col in df.columns and l_col in df.columns:
                out_cols[k] = df[t_col].where(df[t_col].notna(), df[l_col])
            elif k in df.columns:
                out_cols[k] = df[k]

        for c in self.compare_columns:
            t_col = f"{c}__T"
            l_col = f"{c}__L"
            if t_col in df.columns:
                out_cols[f"{c} [Transformed]"] = df[t_col]
            if l_col in df.columns:
                out_cols[f"{c} [Loaded]"] = df[l_col]

        out = pd.DataFrame(out_cols)
        out = out.rename(columns={"__match_status__": "Match Status"})
        return out.reset_index(drop=True)

    def _reshape_one_sided(self, df: pd.DataFrame, side: str) -> pd.DataFrame:
        if df.empty:
            return pd.DataFrame(columns=["side", *self.key_columns])
        suffix = "__T" if side == "T" else "__L"
        cols = {}
        for k in self.key_columns:
            col_name = f"{k}{suffix}"
            cols[k] = df[col_name] if col_name in df.columns else df.get(k, MISSING_TOKEN)
        for c in self.compare_columns:
            col_name = f"{c}{suffix}"
            if col_name in df.columns:
                cols[c] = df[col_name]
        out = pd.DataFrame(cols)
        out.insert(0, "side", "Only in Transformed" if side == "T" else "Only in Loaded")
        return out.reset_index(drop=True)
