// Generates branded Excel file from mapping session data
// BACKEND INTEGRATION: For production, move to a server action to handle large datasets and logo embedding

import * as XLSX from 'xlsx';
import type { MappingSession } from './mappingStore';

export async function exportMappingToExcel(session: MappingSession): Promise<void> {
  const wb = XLSX.utils.book_new();

  // ── Sheet 1: Cover / Project Details ──────────────────────────────────────
  const coverData = [
    ['MigrationMapper — Field-to-Field Mapping Sheet'],
    [],
    ['Project Name', session.projectDetails.projectName],
    ['Client Name', session.projectDetails.clientName],
    ['Source System', session.projectDetails.sourceSystem || '—'],
    ['Process Area', session.projectDetails.processArea],
    ['Phase', session.projectDetails.phase],
    ['Object Name', session.projectDetails.objectName],
    ['DM Consultant', session.projectDetails.dmConsultant],
    ['Functional Owner', session.projectDetails.functionalOwner],
    ['Business Owner', session.projectDetails.businessOwner],
    ['Created Date', session.projectDetails.createdDate],
    ['Generated At', session.generatedAt],
    ['Source XML', session.xmlFileName],
    [],
    ['Total Fields', session.mappings.length],
    ['Mandatory Fields', session.mappings.filter((m) => m.target.mandatory === 'Yes').length],
    ['Migration Required', session.mappings.filter((m) => m.target.migrationRequired === 'Yes').length],
    ['Rules Populated', session.mappings.filter((m) => m.target.transformationRule).length],
  ];

  const coverSheet = XLSX.utils.aoa_to_sheet(coverData);
  coverSheet['!cols'] = [{ wch: 22 }, { wch: 40 }];

  // Style title row
  if (coverSheet['A1']) {
    coverSheet['A1'].s = {
      font: { bold: true, sz: 16, color: { rgb: '1E40AF' } },
    };
  }

  XLSX.utils.book_append_sheet(wb, coverSheet, 'Project Details');

  // ── Sheet 2: Field Mapping ─────────────────────────────────────────────────
  const headers = [
    'Seq#',
    'Source Table Name',
    'Source Table Description',
    'Source Field Name',
    'Source Field Description',
    'Source Type/Len/Dec',
    'Target View Name',
    'Target Field Name',
    'Target Field Description',
    'Target Type/Len/Dec',
    'Target HANA Table',
    'Check Table',
    'Mandatory',
    'Migration Required',
    'Transformation Type',
    'Transformation Rule',
    'Validation Rule',
  ];

  const rows = session.mappings.map((m) => [
    m.seq,
    m.source.tableName,
    m.source.tableDescription,
    m.source.fieldName,
    m.source.fieldDescription,
    `${m.source.dataType} / ${m.source.length} / ${m.source.decimal}`,
    m.target.targetViewName,
    m.target.targetFieldName,
    m.target.targetFieldDescription,
    `${m.target.targetFieldDataType} / ${m.target.targetFieldLength} / ${m.target.targetFieldDecimal}`,
    m.target.targetHanaTable,
    m.target.checkTable,
    m.target.mandatory,
    m.target.migrationRequired,
    m.target.transformationType,
    m.target.transformationRule,
    m.target.validationRule,
  ]);

  const mappingSheet = XLSX.utils.aoa_to_sheet([headers, ...rows]);

  // Column widths
  mappingSheet['!cols'] = [
    { wch: 6 },   // Seq
    { wch: 20 },  // Src Table
    { wch: 28 },  // Src Table Desc
    { wch: 20 },  // Src Field
    { wch: 30 },  // Src Field Desc
    { wch: 20 },  // Src Type/Len/Dec
    { wch: 22 },  // Tgt View
    { wch: 22 },  // Tgt Field
    { wch: 32 },  // Tgt Field Desc
    { wch: 20 },  // Tgt Type/Len/Dec
    { wch: 20 },  // HANA Table
    { wch: 16 },  // Check Table
    { wch: 12 },  // Mandatory
    { wch: 18 },  // Mig Required
    { wch: 18 },  // Trans Type
    { wch: 40 },  // Trans Rule
    { wch: 40 },  // Val Rule
  ];

  // Freeze header row
  mappingSheet['!freeze'] = { xSplit: 0, ySplit: 1 };

  XLSX.utils.book_append_sheet(wb, mappingSheet, 'Field Mapping');

  // ── Download ───────────────────────────────────────────────────────────────
  const safeProject = (session.projectDetails.projectName || 'Mapping')
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .slice(0, 40);
  const safeObject = (session.projectDetails.objectName || 'Object')
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .slice(0, 20);
  const dateStr = new Date().toISOString().slice(0, 10);

  const fileName = `MigrationMapper_${safeProject}_${safeObject}_${dateStr}.xlsx`;

  XLSX.writeFile(wb, fileName);
}
function generateMappingExcel(...args: any[]): any {
  // eslint-disable-next-line no-console
  console.warn('Placeholder: generateMappingExcel is not implemented yet.', args);
  return null;
}

export { generateMappingExcel };