// In-memory + localStorage store for MigrationMapper
// Supports project catalogue with multiple mapping iterations

export interface SourceField {
  id: string;
  tableName: string;
  tableDescription: string;
  fieldName: string;
  fieldDescription: string;
  dataType: string;
  length: string;
  decimal: string;
}

export interface TargetField {
  targetViewName: string;
  targetFieldName: string;
  targetFieldDescription: string;
  targetFieldDataType: string;
  targetFieldLength: string;
  targetFieldDecimal: string;
  targetHanaTable: string;
  checkTable: string;
  mandatory: 'Yes' | 'No';
  migrationRequired: 'Yes' | 'No';
  transformationType: 'Direct' | 'Lookup' | 'Concatenation' | 'Default' | 'Conditional' | 'Derivation' | 'None';
  transformationRule: string;
  validationRule: string;
}

export interface FieldMapping {
  id: string;
  seq: number;
  source: SourceField;
  target: TargetField;
}

export interface ProjectDetails {
  projectName: string;
  processArea: string;
  phase: string;
  objectName: string;
  clientName: string;
  sourceSystem: string; // kept for backward compat — primary source system
  sourceSystems?: string[]; // multiple source systems
  targetSystem?: string; // always S4 HANA
  dmConsultant: string;
  functionalOwner: string;
  businessOwner: string;
  createdDate: string;
  clientLogoDataUrl?: string;
  partnerLogoDataUrl?: string;
}

export interface MappingSession {
  projectDetails: ProjectDetails;
  mappings: FieldMapping[];
  xmlFileName: string;
  generatedAt: string;
}

// ── Catalogue types ────────────────────────────────────────────────────────────

export interface MappingIteration {
  iterationId: string;
  objectName: string;
  xmlFileName: string;
  generatedAt: string;
  mappings: FieldMapping[];
}

export interface ProjectCatalogueEntry {
  projectId: string;
  projectDetails: ProjectDetails;
  iterations: MappingIteration[];
  createdAt: string;
  updatedAt: string;
}

// ── Standalone Project (created upfront before mapping) ────────────────────────

export interface StandaloneProject {
  projectId: string;
  projectName: string;
  clientName: string;
  sourceSystems: string[]; // multiple source systems
  targetSystem: string;    // always 'S4 HANA'
  dmConsultant: string;
  functionalOwner: string;
  businessOwner: string;
  phase: string;
  createdDate: string;
  clientLogoDataUrl?: string;
  partnerLogoDataUrl?: string;
  createdAt: string;
  updatedAt: string;
}

// ── Cross Reference types ──────────────────────────────────────────────────────

export interface CrossReferenceRow {
  id: string;
  sourceSystem: string;
  fieldName: string;
  fieldDescription: string;
  parameter1: string;
  parameter1Desc: string;
  parameter2: string;
  parameter2Desc: string;
  parameter3: string;
  parameter3Desc: string;
  sourceValue: string;
  sourceValueDescription: string;
  targetValue: string;
  targetValueDesc: string;
}

// ── Storage keys ───────────────────────────────────────────────────────────────
const CATALOGUE_KEY = 'mm_project_catalogue';
const XREF_KEY = 'mm_cross_reference';
const STATUS_KEY = 'mm_project_statuses';
const PROJECTS_KEY = 'mm_standalone_projects';

// ── Singleton session store ────────────────────────────────────────────────────
let _session: MappingSession | null = null;

export function setMappingSession(session: MappingSession) {
  _session = session;
  // Also persist to catalogue
  saveSessionToCatalogue(session);
}

export function getMappingSession(): MappingSession | null {
  return _session;
}

export function updateMappingRow(id: string, updated: Partial<FieldMapping>) {
  if (!_session) return;
  _session.mappings = _session.mappings.map((m) =>
    m.id === id ? { ...m, ...updated } : m
  );
}

export function clearSession() {
  _session = null;
}

// ── Standalone Projects ────────────────────────────────────────────────────────

function loadStandaloneProjects(): StandaloneProject[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(PROJECTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveStandaloneProjects(projects: StandaloneProject[]) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
  } catch {
    // ignore
  }
}

export function getStandaloneProjects(): StandaloneProject[] {
  return loadStandaloneProjects();
}

export function createStandaloneProject(data: Omit<StandaloneProject, 'projectId' | 'createdAt' | 'updatedAt'>): StandaloneProject {
  const projects = loadStandaloneProjects();
  const now = new Date().toISOString();
  const project: StandaloneProject = {
    ...data,
    projectId: `proj-${Date.now()}`,
    targetSystem: 'S4 HANA',
    createdAt: now,
    updatedAt: now,
  };
  projects.push(project);
  saveStandaloneProjects(projects);
  return project;
}

export function updateStandaloneProject(projectId: string, data: Partial<StandaloneProject>) {
  const projects = loadStandaloneProjects().map((p) =>
    p.projectId === projectId ? { ...p, ...data, updatedAt: new Date().toISOString() } : p
  );
  saveStandaloneProjects(projects);
}

export function deleteStandaloneProject(projectId: string) {
  const projects = loadStandaloneProjects().filter((p) => p.projectId !== projectId);
  saveStandaloneProjects(projects);
}

// ── Project Catalogue ──────────────────────────────────────────────────────────

function loadCatalogue(): ProjectCatalogueEntry[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(CATALOGUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveCatalogue(catalogue: ProjectCatalogueEntry[]) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(CATALOGUE_KEY, JSON.stringify(catalogue));
  } catch {
    // Storage quota exceeded — silently ignore
  }
}

export function saveSessionToCatalogue(session: MappingSession) {
  const catalogue = loadCatalogue();
  const projectName = session.projectDetails.projectName;
  const now = new Date().toISOString();

  const iteration: MappingIteration = {
    iterationId: `iter-${Date.now()}`,
    objectName: session.projectDetails.objectName,
    xmlFileName: session.xmlFileName,
    generatedAt: session.generatedAt,
    mappings: session.mappings,
  };

  const existingIdx = catalogue.findIndex(
    (p) => p.projectDetails.projectName === projectName
  );

  if (existingIdx >= 0) {
    catalogue[existingIdx].iterations.push(iteration);
    catalogue[existingIdx].updatedAt = now;
    // Update project details (logos etc may have changed)
    catalogue[existingIdx].projectDetails = {
      ...session.projectDetails,
      targetSystem: 'S4 HANA',
    };
  } else {
    catalogue.push({
      projectId: `proj-${Date.now()}`,
      projectDetails: {
        ...session.projectDetails,
        targetSystem: 'S4 HANA',
      },
      iterations: [iteration],
      createdAt: now,
      updatedAt: now,
    });
  }

  saveCatalogue(catalogue);
}

export function getProjectCatalogue(): ProjectCatalogueEntry[] {
  return loadCatalogue();
}

export function deleteProjectFromCatalogue(projectId: string) {
  const catalogue = loadCatalogue().filter((p) => p.projectId !== projectId);
  saveCatalogue(catalogue);
}

export function deleteIterationFromCatalogue(projectId: string, iterationId: string) {
  const catalogue = loadCatalogue().map((p) => {
    if (p.projectId !== projectId) return p;
    return { ...p, iterations: p.iterations.filter((i) => i.iterationId !== iterationId) };
  });
  saveCatalogue(catalogue);
}

export function loadIterationAsSession(entry: ProjectCatalogueEntry, iteration: MappingIteration) {
  _session = {
    projectDetails: entry.projectDetails,
    mappings: iteration.mappings,
    xmlFileName: iteration.xmlFileName,
    generatedAt: iteration.generatedAt,
  };
  return _session;
}

// ── Project Statuses ───────────────────────────────────────────────────────────

export function getProjectStatuses(): Record<string, string> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = localStorage.getItem(STATUS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function saveProjectStatus(projectId: string, status: string) {
  if (typeof window === 'undefined') return;
  try {
    const statuses = getProjectStatuses();
    statuses[projectId] = status;
    localStorage.setItem(STATUS_KEY, JSON.stringify(statuses));
  } catch {
    // ignore
  }
}

// ── Cross Reference ────────────────────────────────────────────────────────────

export function getCrossReferenceRows(): CrossReferenceRow[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(XREF_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveCrossReferenceRows(rows: CrossReferenceRow[]) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(XREF_KEY, JSON.stringify(rows));
  } catch {
    // ignore
  }
}