'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { FileCode2, TableProperties, ChevronLeft, ChevronRight, Settings, HelpCircle, History, GitCompare, FolderOpen, PlusSquare, BarChart3, Database } from 'lucide-react';

interface NavItem {
  id: string;
  label: string;
  href: string;
  icon: React.ReactNode;
  badge?: number;
  description: string;
}

const navItems: NavItem[] = [
  {
    id: 'nav-create-project',
    label: 'Create Project',
    href: '/create-project',
    icon: <PlusSquare size={18} />,
    description: 'Create and manage migration projects',
  },
  {
    id: 'nav-projects',
    label: 'Projects',
    href: '/projects',
    icon: <FolderOpen size={18} />,
    description: 'View latest mappings per project',
  },
  {
    id: 'nav-generator',
    label: 'Mapping Generator',
    href: '/',
    icon: <FileCode2 size={18} />,
    description: 'Upload XML & generate mapping',
  },
  {
    id: 'nav-preview',
    label: 'Preview & Export',
    href: '/mapping-preview-export',
    icon: <TableProperties size={18} />,
    description: 'Review and download mapping sheet',
  },
  {
    id: 'nav-history',
    label: 'Mapping History',
    href: '/mapping-history',
    icon: <History size={18} />,
    description: 'Browse saved project mappings',
  },
  {
    id: 'nav-xref',
    label: 'Cross Reference',
    href: '/cross-reference',
    icon: <GitCompare size={18} />,
    description: 'Manage source-to-target value mappings',
  },
  {
    id: 'nav-quality',
    label: 'Mapping Quality',
    href: '/mapping-quality',
    icon: <BarChart3 size={18} />,
    description: 'Completeness, validation & gap analysis',
  },
  {
    id: 'nav-data-load',
    label: 'Data Load',
    href: '/data-load',
    icon: <Database size={18} />,
    description: 'Transform, validate & generate load file',
  },
];

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

export default function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const pathname = usePathname();

  return (
    <aside
      className={`fixed left-0 top-0 h-screen flex flex-col z-40 sidebar-transition ${
        collapsed ? 'w-16' : 'w-60'
      }`}
      style={{ backgroundColor: 'var(--sidebar-bg)' }}
    >
      {/* Logo */}
      <div
        className={`flex items-center h-16 border-b px-3 ${
          collapsed ? 'justify-center' : 'gap-3'
        }`}
        style={{ borderColor: 'rgba(255,255,255,0.08)' }}
      >
        {!collapsed && (
          <div className="flex items-center gap-2 min-w-0">
            <span className="inline-flex items-center justify-center bg-yellow-400 text-gray-900 font-bold text-xs px-1.5 py-0.5 rounded shrink-0" style={{ fontFamily: 'sans-serif', letterSpacing: '0.05em' }}>
              EY
            </span>
            <span className="text-white font-semibold text-base tracking-tight truncate">
              MigrationMapper
            </span>
          </div>
        )}
      </div>

      {/* Nav section label */}
      {!collapsed && (
        <div className="px-4 pt-5 pb-1">
          <span
            className="text-xs font-semibold uppercase tracking-widest"
            style={{ color: 'rgba(148,163,184,0.6)' }}
          >
            Workspace
          </span>
        </div>
      )}

      {/* Nav Items */}
      <nav className="flex-1 px-2 pt-2 space-y-0.5 overflow-y-auto scrollbar-thin">
        {navItems.map((item) => {
          const isActive =
            item.href === '/'
              ? pathname === '/'
              : pathname.startsWith(item.href);

          return (
            <div key={item.id} className="relative group">
              <Link
                href={item.href}
                className={`flex items-center gap-3 px-2.5 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${
                  isActive
                    ? 'bg-primary text-white' :'text-sidebar-text hover:bg-sidebar-hover hover:text-white'
                } ${collapsed ? 'justify-center' : ''}`}
              >
                <span className="flex-shrink-0">{item.icon}</span>
                {!collapsed && (
                  <span className="truncate">{item.label}</span>
                )}
                {!collapsed && item.badge !== undefined && item.badge > 0 && (
                  <span className="ml-auto text-xs font-bold bg-accent text-white rounded-full px-1.5 py-0.5 min-w-[20px] text-center">
                    {item.badge}
                  </span>
                )}
              </Link>

              {/* Tooltip when collapsed */}
              {collapsed && (
                <div
                  className="absolute left-full ml-3 top-1/2 -translate-y-1/2 bg-foreground text-white text-xs font-medium px-2.5 py-1.5 rounded-md whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-150 shadow-dropdown z-50"
                  role="tooltip"
                >
                  {item.label}
                  <div className="absolute right-full top-1/2 -translate-y-1/2 border-4 border-transparent border-r-foreground" />
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Divider */}
      <div
        className="mx-3 my-2 border-t"
        style={{ borderColor: 'rgba(255,255,255,0.08)' }}
      />

      {/* Bottom utilities */}
      <div className="px-2 pb-2 space-y-0.5">
        {[
          { id: 'nav-settings', icon: <Settings size={16} />, label: 'Settings' },
          { id: 'nav-help', icon: <HelpCircle size={16} />, label: 'Help & Docs' },
        ].map((item) => (
          <div key={item.id} className="relative group">
            <button
              className={`w-full flex items-center gap-3 px-2.5 py-2 rounded-lg text-sm font-medium text-sidebar-text hover:bg-sidebar-hover hover:text-white transition-all duration-150 ${
                collapsed ? 'justify-center' : ''
              }`}
            >
              {item.icon}
              {!collapsed && <span>{item.label}</span>}
            </button>
            {collapsed && (
              <div
                className="absolute left-full ml-3 top-1/2 -translate-y-1/2 bg-foreground text-white text-xs font-medium px-2.5 py-1.5 rounded-md whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-150 shadow-dropdown z-50"
                role="tooltip"
              >
                {item.label}
                <div className="absolute right-full top-1/2 -translate-y-1/2 border-4 border-transparent border-r-foreground" />
              </div>
            )}
          </div>
        ))}

        {/* Collapse toggle */}
        <button
          onClick={onToggle}
          className={`w-full flex items-center gap-3 px-2.5 py-2 rounded-lg text-sm font-medium text-sidebar-text hover:bg-sidebar-hover hover:text-white transition-all duration-150 mt-1 ${
            collapsed ? 'justify-center' : ''
          }`}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          {!collapsed && <span className="text-xs">Collapse</span>}
        </button>
      </div>

      {/* User pill */}
      {!collapsed && (
        <div
          className="mx-3 mb-3 p-2.5 rounded-lg flex items-center gap-2.5"
          style={{ backgroundColor: 'rgba(255,255,255,0.06)' }}
        >
          <div className="w-7 h-7 rounded-full gradient-primary flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
            DM
          </div>
          <div className="min-w-0">
            <p className="text-white text-xs font-semibold truncate">DM Consultant</p>
            <p className="text-xs truncate" style={{ color: 'rgba(148,163,184,0.7)' }}>
              SAP S/4HANA Migration
            </p>
          </div>
        </div>
      )}
    </aside>
  );
}