'use client';

import React, { useState } from 'react';
import Sidebar from './Sidebar';
import SAPChatBot from './SAPChatBot';

interface AppLayoutProps {
  children: React.ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="min-h-screen flex" style={{ backgroundColor: 'var(--background)' }}>
      <Sidebar collapsed={collapsed} onToggle={() => setCollapsed((p) => !p)} />
      <main
        className={`flex-1 min-h-screen content-transition ${
          collapsed ? 'ml-16' : 'ml-60'
        }`}
      >
        {children}
      </main>
      <SAPChatBot />
    </div>
  );
}