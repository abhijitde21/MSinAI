'use client';

import { useState, useEffect, useRef } from 'react';
import { useChat } from '@/lib/hooks/useChat';
import toast from 'react-hot-toast';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  attachmentName?: string;
}

const SYSTEM_MESSAGE = {
  role: 'system',
  content: `You are an expert SAP S/4HANA Data Migration AI assistant specializing in the SAP Migration Cockpit (LTMC/LTMOM). You have deep knowledge of:

- SAP Migration Cockpit (LTMC) and Migration Object Modeler (LTMOM)
- SAP S/4HANA data migration best practices and methodology
- Load file formats: CSV structure, field delimiters, encoding requirements
- Migration objects: Business Partners (BP), Materials (MM), GL Accounts, Customers, Vendors, Assets, Open Items
- Field mapping rules, transformation logic, and value mapping
- Validation rules: mandatory fields, field length constraints, data type checks, value range validations
- Mapping statistics interpretation: success rates, error analysis, field coverage
- Cutover planning, go-live preparation, and post-migration validation
- Common migration errors and their resolutions
- BAPI/IDoc structures used in migration
- Data cleansing and enrichment strategies
- Legacy system data extraction and transformation

When analyzing uploaded files (CSV, Excel, PDF, images):
- Identify field mappings and suggest improvements
- Highlight missing mandatory fields
- Flag data quality issues
- Provide actionable recommendations
- Explain validation errors with specific fixes

Always provide precise, technical answers with SAP transaction codes, field names, and table references where relevant.`
};

const QUICK_SUGGESTIONS = [
  'What are mandatory fields for Business Partner migration?',
  'How to fix "Mandatory field is empty" errors?',
  'Explain load file CSV format requirements',
  'What is the cutover checklist for S/4HANA migration?',
  'How to handle duplicate key errors in migration?',
  'Explain mapping statistics and success rate calculation',
];

async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
  });
}

export default function SAPChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [currentStreamingMsg, setCurrentStreamingMsg] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const { response, isLoading, error, sendMessage } = useChat('OPEN_AI', 'gpt-4o', true);

  useEffect(() => {
    if (error) toast.error(error.message);
  }, [error]);

  useEffect(() => {
    if (isLoading) {
      setCurrentStreamingMsg(response);
    } else if (response && !isLoading) {
      setCurrentStreamingMsg('');
      setMessages((prev) => {
        const last = prev[prev.length - 1];
        if (last?.role === 'assistant' && last.content === '') {
          return [...prev.slice(0, -1), { role: 'assistant', content: response }];
        }
        return [...prev, { role: 'assistant', content: response }];
      });
    }
  }, [response, isLoading]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, currentStreamingMsg]);

  const handleSend = async (text?: string) => {
    const messageText = text ?? input;
    if (!messageText.trim() || isLoading) return;

    const contentParts: any[] = [{ type: 'text', text: messageText }];

    if (attachedFile) {
      const base64DataUri = await fileToBase64(attachedFile);
      const isImage = attachedFile.type.startsWith('image/');
      if (isImage) {
        contentParts.push({ type: 'image_url', image_url: { url: base64DataUri, detail: 'auto' } });
      } else {
        contentParts.push({ type: 'file', file: { file_data: base64DataUri, filename: attachedFile.name } });
      }
    }

    const userMsg: Message = {
      role: 'user',
      content: messageText,
      attachmentName: attachedFile?.name,
    };

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInput('');
    setAttachedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';

    const apiMessages = [
      SYSTEM_MESSAGE,
      ...updatedMessages.map((m) => ({
        role: m.role,
        content: m.content,
      })),
    ];

    // Replace last user message content with multimodal content if file attached
    if (contentParts.length > 1) {
      apiMessages[apiMessages.length - 1] = { role: 'user', content: contentParts };
    }

    sendMessage(apiMessages, { max_completion_tokens: 2048 });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const validTypes = [
      'image/jpeg', 'image/png', 'image/gif', 'image/webp',
      'application/pdf',
      'text/csv',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ];
    if (!validTypes.includes(file.type)) {
      toast.error('Supported: JPEG, PNG, GIF, WebP, PDF, CSV, Excel');
      return;
    }
    setAttachedFile(file);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearChat = () => {
    setMessages([]);
    setCurrentStreamingMsg('');
    setInput('');
    setAttachedFile(null);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-3 rounded-full shadow-lg text-sm font-semibold transition-all hover:scale-105 active:scale-95"
        style={{ backgroundColor: '#FFE600', color: '#1A1A1A' }}
        aria-label="Open Migration AI Chat"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
        </svg>
        Migration AI
      </button>
    );
  }

  return (
    <div
      className="fixed bottom-6 right-6 z-50 flex flex-col rounded-2xl shadow-2xl overflow-hidden transition-all"
      style={{
        width: '380px',
        height: isMinimized ? '56px' : '600px',
        backgroundColor: '#1A1A1A',
        border: '1px solid #2A2A2A',
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-4 py-3 flex-shrink-0"
        style={{ backgroundColor: '#FFE600' }}
      >
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full flex items-center justify-center" style={{ backgroundColor: '#1A1A1A' }}>
            <svg className="w-4 h-4" fill="none" stroke="#FFE600" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
          </div>
          <div>
            <p className="text-xs font-bold" style={{ color: '#1A1A1A', lineHeight: 1.2 }}>Migration AI</p>
            <p className="text-xs" style={{ color: '#333', lineHeight: 1.2 }}>SAP S/4HANA Expert</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {!isMinimized && messages.length > 0 && (
            <button
              onClick={clearChat}
              className="p-1.5 rounded-lg hover:bg-yellow-300 transition-colors"
              title="Clear chat"
              style={{ color: '#1A1A1A' }}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </button>
          )}
          <button
            onClick={() => setIsMinimized((p) => !p)}
            className="p-1.5 rounded-lg hover:bg-yellow-300 transition-colors"
            title={isMinimized ? 'Expand' : 'Minimize'}
            style={{ color: '#1A1A1A' }}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isMinimized ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              )}
            </svg>
          </button>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1.5 rounded-lg hover:bg-yellow-300 transition-colors"
            title="Close"
            style={{ color: '#1A1A1A' }}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3" style={{ backgroundColor: '#111' }}>
            {messages.length === 0 && !isLoading && (
              <div className="space-y-3">
                <div className="text-center py-4">
                  <div className="w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center" style={{ backgroundColor: '#FFE600' }}>
                    <svg className="w-6 h-6" fill="none" stroke="#1A1A1A" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                  </div>
                  <p className="text-sm font-semibold" style={{ color: '#FFE600' }}>SAP Migration Expert</p>
                  <p className="text-xs mt-1" style={{ color: '#888' }}>Ask me anything about SAP S/4HANA data migration, load files, mapping, or upload files for analysis.</p>
                </div>
                <div className="space-y-2">
                  <p className="text-xs font-medium" style={{ color: '#666' }}>Quick questions:</p>
                  {QUICK_SUGGESTIONS.map((s, i) => (
                    <button
                      key={i}
                      onClick={() => handleSend(s)}
                      className="w-full text-left text-xs px-3 py-2 rounded-lg transition-colors hover:opacity-80"
                      style={{ backgroundColor: '#1E1E1E', color: '#CCC', border: '1px solid #2A2A2A' }}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div
                  className="max-w-[85%] rounded-2xl px-3 py-2 text-xs leading-relaxed"
                  style={
                    msg.role === 'user'
                      ? { backgroundColor: '#FFE600', color: '#1A1A1A', borderBottomRightRadius: '4px' }
                      : { backgroundColor: '#1E1E1E', color: '#E0E0E0', border: '1px solid #2A2A2A', borderBottomLeftRadius: '4px' }
                  }
                >
                  {msg.attachmentName && (
                    <div className="flex items-center gap-1 mb-1 text-xs opacity-70">
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                      </svg>
                      {msg.attachmentName}
                    </div>
                  )}
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                </div>
              </div>
            ))}

            {isLoading && currentStreamingMsg && (
              <div className="flex justify-start">
                <div
                  className="max-w-[85%] rounded-2xl px-3 py-2 text-xs leading-relaxed"
                  style={{ backgroundColor: '#1E1E1E', color: '#E0E0E0', border: '1px solid #2A2A2A', borderBottomLeftRadius: '4px' }}
                >
                  <p className="whitespace-pre-wrap">{currentStreamingMsg}</p>
                  <span className="inline-block w-1.5 h-3 ml-0.5 animate-pulse" style={{ backgroundColor: '#FFE600' }} />
                </div>
              </div>
            )}

            {isLoading && !currentStreamingMsg && (
              <div className="flex justify-start">
                <div
                  className="rounded-2xl px-4 py-3"
                  style={{ backgroundColor: '#1E1E1E', border: '1px solid #2A2A2A' }}
                >
                  <div className="flex gap-1 items-center">
                    <span className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ backgroundColor: '#FFE600', animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ backgroundColor: '#FFE600', animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ backgroundColor: '#FFE600', animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Attachment preview */}
          {attachedFile && (
            <div
              className="flex items-center gap-2 px-4 py-2 text-xs"
              style={{ backgroundColor: '#1A1A1A', borderTop: '1px solid #2A2A2A', color: '#CCC' }}
            >
              <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" stroke="#FFE600" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
              </svg>
              <span className="truncate flex-1">{attachedFile.name}</span>
              <button
                onClick={() => {
                  setAttachedFile(null);
                  if (fileInputRef.current) fileInputRef.current.value = '';
                }}
                className="flex-shrink-0 hover:text-white transition-colors"
              >
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          )}

          {/* Input area */}
          <div className="px-3 py-3 flex-shrink-0" style={{ backgroundColor: '#1A1A1A', borderTop: '1px solid #2A2A2A' }}>
            <div
              className="flex items-end gap-2 rounded-xl px-3 py-2"
              style={{ backgroundColor: '#222', border: '1px solid #333' }}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".jpg,.jpeg,.png,.gif,.webp,.pdf,.csv,.xls,.xlsx"
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isLoading}
                className="flex-shrink-0 p-1 rounded-lg transition-colors hover:opacity-70 disabled:opacity-40"
                title="Attach file (CSV, Excel, PDF, Image)"
                style={{ color: '#888' }}
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                </svg>
              </button>
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about SAP migration..."
                disabled={isLoading}
                rows={1}
                className="flex-1 bg-transparent text-xs resize-none outline-none leading-relaxed disabled:opacity-50"
                style={{ color: '#E0E0E0', maxHeight: '80px', minHeight: '20px' }}
              />
              <button
                type="button"
                onClick={() => handleSend()}
                disabled={isLoading || !input.trim()}
                className="flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center transition-all disabled:opacity-40 hover:opacity-80 active:scale-95"
                style={{ backgroundColor: '#FFE600' }}
              >
                <svg className="w-3.5 h-3.5" fill="none" stroke="#1A1A1A" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 19V5m0 0l-7 7m7-7l7 7" />
                </svg>
              </button>
            </div>
            <p className="text-center mt-1.5 text-xs" style={{ color: '#444' }}>Enter to send · Shift+Enter for new line</p>
          </div>
        </>
      )}
    </div>
  );
}
