'use client';

import React, { useState, useEffect, useRef } from 'react';
import AppLayout from '@/components/AppLayout';
import { getProjectCatalogue, type ProjectCatalogueEntry, type FieldMapping,  } from '@/lib/mappingStore';
import {
  Upload,
  FileCode2,
  Play,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Download,
  ChevronDown,
  FileText,
  Layers,
  RefreshCw,
  Info,
  Database,
  Edit2,
  Save,
  RotateCcw,
} from 'lucide-react';

// ── Types ──────────────────────────────────────────────────────────────────────

interface ObjectOption {
  projectName: string;
  objectName: string;
  processArea: string;
  mappings: FieldMapping[];
  iterationId: string;
  generatedAt: string;
}

interface ParsedRecord {
  [key: string]: string;
}

interface TransformedRecord {
  seq: number;
  sourceData: ParsedRecord;
  targetData: ParsedRecord;
  transformStatus: 'success' | 'warning' | 'error';
  validationStatus: 'pass' | 'fail' | 'warning';
  issues: string[];
  warnings: string[];
  fieldErrors: Record<string, string>; // field -> error message
}

interface LoadReport {
  totalRecords: number;
  transformedOk: number;
  transformedWarning: number;
  transformedError: number;
  validatedPass: number;
  validatedFail: number;
  validatedWarning: number;
  records: TransformedRecord[];
  generatedAt: string;
  objectName: string;
  projectName: string;
  xmlFileName: string;
}

// ── XML Parser ─────────────────────────────────────────────────────────────────

function parseXmlRecords(xmlText: string): ParsedRecord[] {
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(xmlText, 'application/xml');
    const parseError = doc.querySelector('parsererror');
    if (parseError) throw new Error('Invalid XML');

    const root = doc.documentElement;
    const children = Array.from(root.children);
    if (children.length === 0) return [];

    const firstChild = children[0];
    if (firstChild.children.length > 0) {
      return children.map((child) => {
        const record: ParsedRecord = {};
        Array.from(child.children).forEach((el) => {
          record[el.tagName] = el.textContent?.trim() || '';
        });
        return record;
      });
    }

    const record: ParsedRecord = {};
    Array.from(root.children).forEach((el) => {
      record[el.tagName] = el.textContent?.trim() || '';
    });
    return [record];
  } catch {
    return [];
  }
}

// ── Transformation & Validation Engine ────────────────────────────────────────

function applyTransformationRule(
  rule: string,
  sourceValue: string,
  sourceData: ParsedRecord
): { value: string; warning?: string } {
  if (!rule || rule.trim() === '' || rule.toLowerCase() === 'none') {
    return { value: sourceValue };
  }

  const r = rule.toLowerCase().trim();

  if (r === 'direct' || r.startsWith('direct map')) {
    return { value: sourceValue };
  }

  const defaultMatch = rule.match(/default[:\s]+(.+)/i);
  if (defaultMatch) {
    return { value: defaultMatch[1].trim() };
  }

  const concatMatch = rule.match(/concat\(([^)]+)\)/i);
  if (concatMatch) {
    const fields = concatMatch[1].split(',').map((f) => f.trim());
    const value = fields.map((f) => sourceData[f] || '').join(' ');
    return { value };
  }

  if (r === 'uppercase' || r === 'upper') return { value: sourceValue.toUpperCase() };
  if (r === 'lowercase' || r === 'lower') return { value: sourceValue.toLowerCase() };
  if (r === 'trim') return { value: sourceValue.trim() };

  if (r.startsWith('lookup')) {
    return { value: sourceValue, warning: `Lookup required: ${rule}` };
  }

  const condMatch = rule.match(/if\s+(.+?)\s+then\s+(.+)/i);
  if (condMatch) {
    return { value: sourceValue, warning: `Conditional rule applied: ${rule}` };
  }

  if (r.startsWith('deriv')) {
    return { value: sourceValue, warning: `Derivation rule: ${rule}` };
  }

  return { value: sourceValue };
}

function applyValidationRule(
  rule: string,
  value: string,
  mandatory: boolean
): { pass: boolean; message?: string } {
  if (mandatory && (!value || value.trim() === '')) {
    return { pass: false, message: 'Mandatory field is empty' };
  }

  if (!rule || rule.trim() === '') return { pass: true };

  const r = rule.toLowerCase().trim();

  if (r === 'not null' || r === 'required' || r === 'mandatory') {
    if (!value || value.trim() === '') return { pass: false, message: rule };
    return { pass: true };
  }

  const maxLenMatch = rule.match(/maxlen\((\d+)\)/i);
  if (maxLenMatch) {
    const max = parseInt(maxLenMatch[1]);
    if (value.length > max) return { pass: false, message: `Exceeds max length ${max}` };
    return { pass: true };
  }

  if (r === 'numeric' || r === 'number') {
    if (value && isNaN(Number(value))) return { pass: false, message: 'Must be numeric' };
    return { pass: true };
  }

  if (r.includes('date') || r.includes('yyyy')) {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (value && !dateRegex.test(value)) return { pass: false, message: 'Invalid date format (YYYY-MM-DD expected)' };
    return { pass: true };
  }

  const regexMatch = rule.match(/regex\((.+)\)/i);
  if (regexMatch) {
    try {
      const re = new RegExp(regexMatch[1]);
      if (!re.test(value)) return { pass: false, message: `Regex validation failed: ${rule}` };
    } catch {
      return { pass: true };
    }
  }

  return { pass: true };
}

function processRecords(
  records: ParsedRecord[],
  mappings: FieldMapping[]
): TransformedRecord[] {
  return records.map((sourceData, idx) => {
    const targetData: ParsedRecord = {};
    const issues: string[] = [];
    const warnings: string[] = [];
    const fieldErrors: Record<string, string> = {};
    let hasError = false;
    let hasWarning = false;
    let hasValidationFail = false;
    let hasValidationWarning = false;

    for (const mapping of mappings) {
      const { source, target } = mapping;
      const sourceFieldKey = source.fieldName;
      const targetFieldKey = target.targetFieldName;
      const sourceValue = sourceData[sourceFieldKey] || sourceData[source.tableName + '_' + sourceFieldKey] || '';

      const { value: transformedValue, warning: transformWarning } = applyTransformationRule(
        target.transformationRule,
        sourceValue,
        sourceData
      );

      if (transformWarning) {
        warnings.push(`[${targetFieldKey}] ${transformWarning}`);
        hasWarning = true;
      }

      targetData[targetFieldKey] = transformedValue;

      const isMandatory = target.mandatory === 'Yes';
      const { pass, message } = applyValidationRule(target.validationRule, transformedValue, isMandatory);

      if (!pass) {
        issues.push(`[${targetFieldKey}] ${message}`);
        fieldErrors[targetFieldKey] = message || 'Validation failed';
        hasError = true;
        hasValidationFail = true;
      }
    }

    return {
      seq: idx + 1,
      sourceData,
      targetData,
      transformStatus: hasError ? 'error' : hasWarning ? 'warning' : 'success',
      validationStatus: hasValidationFail ? 'fail' : hasValidationWarning ? 'warning' : 'pass',
      issues,
      warnings,
      fieldErrors,
    };
  });
}

// ── Load File Generator ────────────────────────────────────────────────────────

function generateLoadFileContent(records: TransformedRecord[], mappings: FieldMapping[]): string {
  const targetFields = mappings.map((m) => m.target.targetFieldName);
  const header = targetFields.join(',');
  const rows = records
    .filter((r) => r.validationStatus !== 'fail')
    .map((r) =>
      targetFields
        .map((f) => {
          const val = r.targetData[f] || '';
          return val.includes(',') ? `"${val}"` : val;
        })
        .join(',')
    );
  return [header, ...rows].join('\n');
}

function generateLoadFileContentWithRemapped(
  records: TransformedRecord[],
  remappedData: Record<number, ParsedRecord>,
  mappings: FieldMapping[]
): string {
  const targetFields = mappings.map((m) => m.target.targetFieldName);
  const header = targetFields.join(',');
  const rows = records.map((r) => {
    const data = remappedData[r.seq] ? { ...r.targetData, ...remappedData[r.seq] } : r.targetData;
    return targetFields
      .map((f) => {
        const val = data[f] || '';
        return val.includes(',') ? `"${val}"` : val;
      })
      .join(',');
  });
  return [header, ...rows].join('\n');
}

function generateReportContent(report: LoadReport): string {
  const lines = [
    `DATA LOAD REPORT`,
    `================`,
    `Generated At : ${report.generatedAt}`,
    `Project      : ${report.projectName}`,
    `Object       : ${report.objectName}`,
    `Source File  : ${report.xmlFileName}`,
    ``,
    `SUMMARY`,
    `-------`,
    `Total Records        : ${report.totalRecords}`,
    `Transformed OK       : ${report.transformedOk}`,
    `Transformed Warning  : ${report.transformedWarning}`,
    `Transformed Error    : ${report.transformedError}`,
    `Validated Pass       : ${report.validatedPass}`,
    `Validated Fail       : ${report.validatedFail}`,
    `Validated Warning    : ${report.validatedWarning}`,
    `Records in Load File : ${report.validatedPass + report.validatedWarning}`,
    ``,
    `RECORD DETAILS`,
    `--------------`,
  ];

  report.records.forEach((r) => {
    lines.push(`Record #${r.seq} | Transform: ${r.transformStatus} | Validation: ${r.validationStatus}`);
    if (r.issues.length > 0) {
      r.issues.forEach((i) => lines.push(`  ERROR: ${i}`));
    }
    if (r.warnings.length > 0) {
      r.warnings.forEach((w) => lines.push(`  WARN : ${w}`));
    }
  });

  return lines.join('\n');
}

// ── Main Page ──────────────────────────────────────────────────────────────────

export default function DataLoadPage() {
  return (
    <AppLayout>
      <DataLoadContent />
    </AppLayout>
  );
}

function DataLoadContent() {
  const [objectOptions, setObjectOptions] = useState<ObjectOption[]>([]);
  const [selectedObject, setSelectedObject] = useState<ObjectOption | null>(null);
  const [xmlFile, setXmlFile] = useState<File | null>(null);
  const [xmlText, setXmlText] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [report, setReport] = useState<LoadReport | null>(null);
  const [expandedRecord, setExpandedRecord] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'report' | 'records' | 'failed'>('report');
  // remappedData: seq -> { fieldName -> overrideValue }
  const [remappedData, setRemappedData] = useState<Record<number, ParsedRecord>>({});
  const [editingRow, setEditingRow] = useState<number | null>(null);
  const [editBuffer, setEditBuffer] = useState<ParsedRecord>({});
  const [regeneratedFile, setRegeneratedFile] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const catalogue = getProjectCatalogue();
    const options: ObjectOption[] = [];

    catalogue.forEach((entry) => {
      const objectMap = new Map<string, { mappings: FieldMapping[]; iterationId: string; generatedAt: string }>();
      entry.iterations.forEach((iter) => {
        const key = iter.objectName || 'Unknown';
        objectMap.set(key, {
          mappings: iter.mappings,
          iterationId: iter.iterationId,
          generatedAt: iter.generatedAt,
        });
      });

      objectMap.forEach((val, objectName) => {
        options.push({
          projectName: entry.projectDetails.projectName,
          objectName,
          processArea: entry.projectDetails.processArea || 'General',
          mappings: val.mappings,
          iterationId: val.iterationId,
          generatedAt: val.generatedAt,
        });
      });
    });

    setObjectOptions(options);
  }, []);

  const handleFileChange = (file: File) => {
    setXmlFile(file);
    const reader = new FileReader();
    reader.onload = (e) => setXmlText(e.target?.result as string || '');
    reader.readAsText(file);
    setReport(null);
    setRemappedData({});
    setRegeneratedFile(null);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file && (file.name.endsWith('.xml') || file.type === 'text/xml' || file.type === 'application/xml')) {
      handleFileChange(file);
    }
  };

  const handleProcess = () => {
    if (!selectedObject || !xmlText) return;
    setIsProcessing(true);
    setRemappedData({});
    setRegeneratedFile(null);

    setTimeout(() => {
      const records = parseXmlRecords(xmlText);
      if (records.length === 0) {
        setIsProcessing(false);
        return;
      }

      const transformed = processRecords(records, selectedObject.mappings);
      const now = new Date().toISOString().replace('T', ' ').slice(0, 19);

      const loadReport: LoadReport = {
        totalRecords: transformed.length,
        transformedOk: transformed.filter((r) => r.transformStatus === 'success').length,
        transformedWarning: transformed.filter((r) => r.transformStatus === 'warning').length,
        transformedError: transformed.filter((r) => r.transformStatus === 'error').length,
        validatedPass: transformed.filter((r) => r.validationStatus === 'pass').length,
        validatedFail: transformed.filter((r) => r.validationStatus === 'fail').length,
        validatedWarning: transformed.filter((r) => r.validationStatus === 'warning').length,
        records: transformed,
        generatedAt: now,
        objectName: selectedObject.objectName,
        projectName: selectedObject.projectName,
        xmlFileName: xmlFile?.name || 'input.xml',
      };

      setReport(loadReport);
      setIsProcessing(false);
      setActiveTab('report');
    }, 800);
  };

  const handleDownloadLoadFile = () => {
    if (!report || !selectedObject) return;
    const content = generateLoadFileContent(report.records, selectedObject.mappings);
    const blob = new Blob([content], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedObject.objectName}_LoadFile.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadReport = () => {
    if (!report) return;
    const content = generateReportContent(report);
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.objectName}_LoadReport.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // ── Failed Records: inline edit helpers ──
  const startEditing = (rec: TransformedRecord) => {
    const base = remappedData[rec.seq] ? { ...rec.targetData, ...remappedData[rec.seq] } : { ...rec.targetData };
    setEditBuffer(base);
    setEditingRow(rec.seq);
  };

  const cancelEditing = () => {
    setEditingRow(null);
    setEditBuffer({});
  };

  const saveEditing = (seq: number) => {
    setRemappedData((prev) => ({ ...prev, [seq]: { ...editBuffer } }));
    setEditingRow(null);
    setEditBuffer({});
    setRegeneratedFile(null);
  };

  const resetRemap = (seq: number) => {
    setRemappedData((prev) => {
      const next = { ...prev };
      delete next[seq];
      return next;
    });
    setRegeneratedFile(null);
  };

  const handleRegenerateLoadFile = () => {
    if (!report || !selectedObject) return;
    // Merge remapped data into records for all records (pass + remapped failed)
    const allRecords = report.records.map((r) => {
      if (remappedData[r.seq]) {
        const mergedTarget = { ...r.targetData, ...remappedData[r.seq] };
        // Re-validate with merged data
        const fieldErrors: Record<string, string> = {};
        let hasValidationFail = false;
        for (const mapping of selectedObject.mappings) {
          const targetFieldKey = mapping.target.targetFieldName;
          const val = mergedTarget[targetFieldKey] || '';
          const isMandatory = mapping.target.mandatory === 'Yes';
          const { pass, message } = applyValidationRule(mapping.target.validationRule, val, isMandatory);
          if (!pass) {
            fieldErrors[targetFieldKey] = message || 'Validation failed';
            hasValidationFail = true;
          }
        }
        return {
          ...r,
          targetData: mergedTarget,
          validationStatus: (hasValidationFail ? 'fail' : 'pass') as 'pass' | 'fail' | 'warning',
          fieldErrors,
          issues: Object.entries(fieldErrors).map(([k, v]) => `[${k}] ${v}`),
        };
      }
      return r;
    });

    const content = generateLoadFileContentWithRemapped(allRecords, {}, selectedObject.mappings);
    setRegeneratedFile(content);
  };

  const handleDownloadRegeneratedFile = () => {
    if (!regeneratedFile || !selectedObject) return;
    const blob = new Blob([regeneratedFile], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedObject.objectName}_LoadFile_Remapped.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const canProcess = selectedObject && xmlFile && xmlText;

  const projectGroups = objectOptions.reduce<Record<string, ObjectOption[]>>((acc, opt) => {
    if (!acc[opt.projectName]) acc[opt.projectName] = [];
    acc[opt.projectName].push(opt);
    return acc;
  }, {});

  const failedRecords = report?.records.filter((r) => r.validationStatus === 'fail') || [];
  const remappedCount = Object.keys(remappedData).length;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Database size={20} className="text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">Data Load</h1>
            <p className="text-sm text-muted-foreground">
              Upload input XML, apply mapping rules, generate load file &amp; validation report
            </p>
          </div>
        </div>
        {report && (
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadLoadFile}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              <Download size={15} />
              Download Load File
            </button>
            <button
              onClick={handleDownloadReport}
              className="flex items-center gap-2 px-4 py-2 border border-border text-foreground rounded-lg text-sm font-medium hover:bg-muted transition-colors"
            >
              <FileText size={15} />
              Download Report
            </button>
          </div>
        )}
      </div>

      {/* Step 1 & 2 side by side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Step 1: Select Object */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <span className="w-6 h-6 rounded-full bg-primary text-white text-xs font-bold flex items-center justify-center">1</span>
            <h2 className="text-sm font-semibold text-foreground">Select Object &amp; Mapping Sheet</h2>
          </div>

          {objectOptions.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Layers size={32} className="text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">No mapping sheets found.</p>
              <p className="text-xs text-muted-foreground mt-1">Generate mappings first in the Mapping Generator.</p>
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Project / Object</label>
                <div className="relative">
                  <select
                    className="w-full appearance-none bg-background border border-border rounded-lg px-3 py-2.5 text-sm text-foreground pr-8 focus:outline-none focus:ring-2 focus:ring-primary/30"
                    value={selectedObject ? `${selectedObject.projectName}||${selectedObject.objectName}` : ''}
                    onChange={(e) => {
                      const [proj, obj] = e.target.value.split('||');
                      const found = objectOptions.find((o) => o.projectName === proj && o.objectName === obj);
                      setSelectedObject(found || null);
                      setReport(null);
                      setRemappedData({});
                      setRegeneratedFile(null);
                    }}
                  >
                    <option value="">— Select an object —</option>
                    {Object.entries(projectGroups).map(([projName, opts]) => (
                      <optgroup key={projName} label={projName}>
                        {opts.map((opt) => (
                          <option key={`${opt.projectName}||${opt.objectName}`} value={`${opt.projectName}||${opt.objectName}`}>
                            {opt.objectName} ({opt.processArea})
                          </option>
                        ))}
                      </optgroup>
                    ))}
                  </select>
                  <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                </div>
              </div>

              {selectedObject && (
                <div className="bg-muted/40 rounded-lg p-3 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Project</span>
                    <span className="text-xs font-medium text-foreground">{selectedObject.projectName}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Object</span>
                    <span className="text-xs font-medium text-foreground">{selectedObject.objectName}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Process Area</span>
                    <span className="text-xs font-medium text-foreground">{selectedObject.processArea}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Mapping Fields</span>
                    <span className="text-xs font-semibold text-primary">{selectedObject.mappings.length} fields</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Generated</span>
                    <span className="text-xs text-muted-foreground">{selectedObject.generatedAt.slice(0, 10)}</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Step 2: Upload XML */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <span className="w-6 h-6 rounded-full bg-primary text-white text-xs font-bold flex items-center justify-center">2</span>
            <h2 className="text-sm font-semibold text-foreground">Upload Input XML File</h2>
          </div>

          <div
            className={`border-2 border-dashed rounded-xl p-6 text-center transition-colors cursor-pointer ${
              isDragging
                ? 'border-primary bg-primary/5'
                : xmlFile
                ? 'border-emerald-400 bg-emerald-50/30' :'border-border hover:border-primary/50 hover:bg-muted/30'
            }`}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".xml,text/xml,application/xml"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleFileChange(file);
              }}
            />
            {xmlFile ? (
              <div className="flex flex-col items-center gap-2">
                <CheckCircle2 size={28} className="text-emerald-500" />
                <p className="text-sm font-medium text-foreground">{xmlFile.name}</p>
                <p className="text-xs text-muted-foreground">{(xmlFile.size / 1024).toFixed(1)} KB</p>
                <button
                  className="text-xs text-primary hover:underline mt-1"
                  onClick={(e) => { e.stopPropagation(); setXmlFile(null); setXmlText(''); setReport(null); setRemappedData({}); setRegeneratedFile(null); }}
                >
                  Remove &amp; choose another
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2">
                <Upload size={28} className="text-muted-foreground" />
                <p className="text-sm font-medium text-foreground">Drop XML file here or click to browse</p>
                <p className="text-xs text-muted-foreground">Accepts .xml files with data records</p>
              </div>
            )}
          </div>

          {xmlText && (
            <div className="mt-3">
              <p className="text-xs text-muted-foreground mb-1">Preview (first 300 chars)</p>
              <pre className="bg-muted/40 rounded-lg p-2.5 text-xs text-foreground overflow-x-auto whitespace-pre-wrap break-all max-h-24">
                {xmlText.slice(0, 300)}{xmlText.length > 300 ? '…' : ''}
              </pre>
            </div>
          )}
        </div>
      </div>

      {/* Step 3: Process */}
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-primary text-white text-xs font-bold flex items-center justify-center">3</span>
            <h2 className="text-sm font-semibold text-foreground">Transform &amp; Validate</h2>
            <span className="text-xs text-muted-foreground ml-1">
              Apply mapping rules from the selected object to generate the load file
            </span>
          </div>
          <button
            onClick={handleProcess}
            disabled={!canProcess || isProcessing}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all ${
              canProcess && !isProcessing
                ? 'bg-primary text-white hover:bg-primary/90 shadow-sm'
                : 'bg-muted text-muted-foreground cursor-not-allowed'
            }`}
          >
            {isProcessing ? (
              <>
                <RefreshCw size={15} className="animate-spin" />
                Processing…
              </>
            ) : (
              <>
                <Play size={15} />
                Run Transformation &amp; Validation
              </>
            )}
          </button>
        </div>

        {!canProcess && (
          <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground bg-muted/30 rounded-lg px-3 py-2">
            <Info size={13} />
            {!selectedObject && !xmlFile
              ? 'Select an object and upload an XML file to proceed.'
              : !selectedObject
              ? 'Select an object with a mapping sheet to proceed.' :'Upload an input XML file to proceed.'}
          </div>
        )}
      </div>

      {/* Step 4: Results */}
      {report && (
        <div className="space-y-4">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <StatCard
              label="Total Records"
              value={report.totalRecords}
              icon={<FileCode2 size={16} />}
              color="blue"
            />
            <StatCard
              label="Transformed OK"
              value={report.transformedOk}
              sub={`${report.transformedWarning} warnings, ${report.transformedError} errors`}
              icon={<CheckCircle2 size={16} />}
              color="emerald"
            />
            <StatCard
              label="Validated Pass"
              value={report.validatedPass}
              sub={`${report.validatedFail} failed, ${report.validatedWarning} warnings`}
              icon={<CheckCircle2 size={16} />}
              color="green"
            />
            <StatCard
              label="In Load File"
              value={report.validatedPass + report.validatedWarning}
              sub={`${report.validatedFail} excluded (validation fail)`}
              icon={<Download size={16} />}
              color="primary"
            />
          </div>

          {/* Tabs */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="flex border-b border-border">
              <button
                className={`px-5 py-3 text-sm font-medium transition-colors ${
                  activeTab === 'report' ?'text-primary border-b-2 border-primary bg-primary/5' :'text-muted-foreground hover:text-foreground'
                }`}
                onClick={() => setActiveTab('report')}
              >
                Summary Report
              </button>
              <button
                className={`px-5 py-3 text-sm font-medium transition-colors ${
                  activeTab === 'records' ?'text-primary border-b-2 border-primary bg-primary/5' :'text-muted-foreground hover:text-foreground'
                }`}
                onClick={() => setActiveTab('records')}
              >
                Record Details ({report.totalRecords})
              </button>
              <button
                className={`px-5 py-3 text-sm font-medium transition-colors flex items-center gap-2 ${
                  activeTab === 'failed' ?'text-red-600 border-b-2 border-red-500 bg-red-50/40' :'text-muted-foreground hover:text-foreground'
                }`}
                onClick={() => setActiveTab('failed')}
              >
                <XCircle size={14} className={activeTab === 'failed' ? 'text-red-500' : 'text-muted-foreground'} />
                Failed Records
                {failedRecords.length > 0 && (
                  <span className={`inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full text-xs font-bold ${
                    activeTab === 'failed' ? 'bg-red-500 text-white' : 'bg-red-100 text-red-600'
                  }`}>
                    {failedRecords.length}
                  </span>
                )}
              </button>
            </div>

            {activeTab === 'report' && (
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Run Info</h3>
                    <InfoRow label="Generated At" value={report.generatedAt} />
                    <InfoRow label="Project" value={report.projectName} />
                    <InfoRow label="Object" value={report.objectName} />
                    <InfoRow label="Source File" value={report.xmlFileName} />
                    <InfoRow label="Mapping Fields" value={String(selectedObject?.mappings.length || 0)} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Transformation Stats</h3>
                    <ProgressRow label="Transformed OK" value={report.transformedOk} total={report.totalRecords} color="emerald" />
                    <ProgressRow label="Transformed Warning" value={report.transformedWarning} total={report.totalRecords} color="amber" />
                    <ProgressRow label="Transformed Error" value={report.transformedError} total={report.totalRecords} color="red" />
                    <div className="pt-1 border-t border-border mt-2">
                      <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Validation Stats</h3>
                    </div>
                    <ProgressRow label="Validated Pass" value={report.validatedPass} total={report.totalRecords} color="emerald" />
                    <ProgressRow label="Validated Warning" value={report.validatedWarning} total={report.totalRecords} color="amber" />
                    <ProgressRow label="Validated Fail" value={report.validatedFail} total={report.totalRecords} color="red" />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'records' && (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-muted/40 border-b border-border">
                      <th className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground w-12">#</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">Transform</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">Validation</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">Issues / Warnings</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground w-16">Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {report.records.map((rec) => (
                      <React.Fragment key={rec.seq}>
                        <tr className="hover:bg-muted/20 transition-colors">
                          <td className="px-4 py-2.5 text-xs text-muted-foreground font-mono">{rec.seq}</td>
                          <td className="px-4 py-2.5">
                            <StatusBadge status={rec.transformStatus} type="transform" />
                          </td>
                          <td className="px-4 py-2.5">
                            <StatusBadge status={rec.validationStatus} type="validation" />
                          </td>
                          <td className="px-4 py-2.5">
                            {rec.issues.length === 0 && rec.warnings.length === 0 ? (
                              <span className="text-xs text-muted-foreground">—</span>
                            ) : (
                              <div className="space-y-0.5">
                                {rec.issues.slice(0, 2).map((i, idx) => (
                                  <p key={idx} className="text-xs text-red-500">{i}</p>
                                ))}
                                {rec.warnings.slice(0, 1).map((w, idx) => (
                                  <p key={idx} className="text-xs text-amber-500">{w}</p>
                                ))}
                                {rec.issues.length + rec.warnings.length > 3 && (
                                  <p className="text-xs text-muted-foreground">+{rec.issues.length + rec.warnings.length - 3} more</p>
                                )}
                              </div>
                            )}
                          </td>
                          <td className="px-4 py-2.5">
                            <button
                              onClick={() => setExpandedRecord(expandedRecord === rec.seq ? null : rec.seq)}
                              className="text-xs text-primary hover:underline flex items-center gap-1"
                            >
                              {expandedRecord === rec.seq ? <ChevronDown size={12} /> : <ChevronDown size={12} className="-rotate-90" />}
                              View
                            </button>
                          </td>
                        </tr>
                        {expandedRecord === rec.seq && (
                          <tr>
                            <td colSpan={5} className="px-4 py-3 bg-muted/20">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                <div>
                                  <p className="text-xs font-semibold text-muted-foreground mb-1.5">Source Data</p>
                                  <div className="bg-background rounded-lg p-2.5 space-y-1 max-h-40 overflow-y-auto">
                                    {Object.entries(rec.sourceData).map(([k, v]) => (
                                      <div key={k} className="flex gap-2 text-xs">
                                        <span className="text-muted-foreground font-mono min-w-[100px]">{k}:</span>
                                        <span className="text-foreground">{v || '—'}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                                <div>
                                  <p className="text-xs font-semibold text-muted-foreground mb-1.5">Target Data (Transformed)</p>
                                  <div className="bg-background rounded-lg p-2.5 space-y-1 max-h-40 overflow-y-auto">
                                    {Object.entries(rec.targetData).map(([k, v]) => (
                                      <div key={k} className="flex gap-2 text-xs">
                                        <span className="text-muted-foreground font-mono min-w-[100px]">{k}:</span>
                                        <span className="text-foreground">{v || '—'}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              </div>
                              {(rec.issues.length > 0 || rec.warnings.length > 0) && (
                                <div className="mt-2 space-y-1">
                                  {rec.issues.map((i, idx) => (
                                    <div key={idx} className="flex items-start gap-1.5 text-xs text-red-500">
                                      <XCircle size={12} className="mt-0.5 flex-shrink-0" />
                                      {i}
                                    </div>
                                  ))}
                                  {rec.warnings.map((w, idx) => (
                                    <div key={idx} className="flex items-start gap-1.5 text-xs text-amber-500">
                                      <AlertTriangle size={12} className="mt-0.5 flex-shrink-0" />
                                      {w}
                                    </div>
                                  ))}
                                </div>
                              )}
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === 'failed' && (
              <div className="p-5 space-y-4">
                {/* Failed tab header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <XCircle size={16} className="text-red-500" />
                      <span className="text-sm font-semibold text-foreground">
                        {failedRecords.length} Failed Record{failedRecords.length !== 1 ? 's' : ''}
                      </span>
                    </div>
                    {remappedCount > 0 && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700">
                        <Edit2 size={10} />
                        {remappedCount} remapped
                      </span>
                    )}
                  </div>
                  {failedRecords.length > 0 && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleRegenerateLoadFile}
                        className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors"
                      >
                        <RefreshCw size={14} />
                        Regenerate Load File
                      </button>
                      {regeneratedFile && (
                        <button
                          onClick={handleDownloadRegeneratedFile}
                          className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition-colors"
                        >
                          <Download size={14} />
                          Download Remapped File
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {regeneratedFile && (
                  <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-lg px-4 py-2.5">
                    <CheckCircle2 size={15} className="text-emerald-600 flex-shrink-0" />
                    <p className="text-xs text-emerald-700 font-medium">
                      Load file regenerated successfully with remapped values. Click "Download Remapped File" to save.
                    </p>
                  </div>
                )}

                {failedRecords.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <CheckCircle2 size={36} className="text-emerald-500 mb-3" />
                    <p className="text-sm font-semibold text-foreground">No failed records!</p>
                    <p className="text-xs text-muted-foreground mt-1">All records passed validation.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <p className="text-xs text-muted-foreground">
                      Edit field values inline to fix validation errors, then click <strong>Regenerate Load File</strong> to include remapped records.
                    </p>
                    {failedRecords.map((rec) => {
                      const isEditing = editingRow === rec.seq;
                      const hasRemap = !!remappedData[rec.seq];
                      const currentData = hasRemap ? { ...rec.targetData, ...remappedData[rec.seq] } : rec.targetData;

                      // Re-validate current data to show live error state
                      const liveFieldErrors: Record<string, string> = {};
                      if (selectedObject) {
                        for (const mapping of selectedObject.mappings) {
                          const fieldKey = mapping.target.targetFieldName;
                          const val = (isEditing ? editBuffer[fieldKey] : currentData[fieldKey]) || '';
                          const isMandatory = mapping.target.mandatory === 'Yes';
                          const { pass, message } = applyValidationRule(mapping.target.validationRule, val, isMandatory);
                          if (!pass) liveFieldErrors[fieldKey] = message || 'Validation failed';
                        }
                      }

                      const stillFailing = Object.keys(liveFieldErrors).length > 0;

                      return (
                        <div
                          key={rec.seq}
                          className={`border rounded-xl overflow-hidden transition-all ${
                            hasRemap && !stillFailing
                              ? 'border-emerald-300 bg-emerald-50/30' :'border-red-200 bg-red-50/20'
                          }`}
                        >
                          {/* Record header */}
                          <div className="flex items-center justify-between px-4 py-2.5 border-b border-inherit bg-white/60">
                            <div className="flex items-center gap-3">
                              <span className="text-xs font-mono font-semibold text-muted-foreground">Record #{rec.seq}</span>
                              {hasRemap && !stillFailing ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-700">
                                  <CheckCircle2 size={10} />
                                  Remapped — ready for load
                                </span>
                              ) : hasRemap ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700">
                                  <AlertTriangle size={10} />
                                  Partially fixed — {Object.keys(liveFieldErrors).length} error{Object.keys(liveFieldErrors).length !== 1 ? 's' : ''} remain
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-700">
                                  <XCircle size={10} />
                                  {Object.keys(rec.fieldErrors).length} validation error{Object.keys(rec.fieldErrors).length !== 1 ? 's' : ''}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              {hasRemap && (
                                <button
                                  onClick={() => resetRemap(rec.seq)}
                                  className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
                                  title="Reset to original values"
                                >
                                  <RotateCcw size={12} />
                                  Reset
                                </button>
                              )}
                              {isEditing ? (
                                <>
                                  <button
                                    onClick={() => saveEditing(rec.seq)}
                                    className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-medium hover:bg-primary/90 transition-colors"
                                  >
                                    <Save size={12} />
                                    Save
                                  </button>
                                  <button
                                    onClick={cancelEditing}
                                    className="flex items-center gap-1.5 px-3 py-1.5 border border-border text-foreground rounded-lg text-xs font-medium hover:bg-muted transition-colors"
                                  >
                                    Cancel
                                  </button>
                                </>
                              ) : (
                                <button
                                  onClick={() => startEditing(rec)}
                                  className="flex items-center gap-1.5 px-3 py-1.5 border border-border text-foreground rounded-lg text-xs font-medium hover:bg-muted transition-colors"
                                >
                                  <Edit2 size={12} />
                                  Edit Fields
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Field table */}
                          <div className="overflow-x-auto">
                            <table className="w-full text-xs">
                              <thead>
                                <tr className="bg-muted/30 border-b border-inherit">
                                  <th className="px-4 py-2 text-left font-semibold text-muted-foreground">Target Field</th>
                                  <th className="px-4 py-2 text-left font-semibold text-muted-foreground">Current Value</th>
                                  <th className="px-4 py-2 text-left font-semibold text-muted-foreground">Validation Rule</th>
                                  <th className="px-4 py-2 text-left font-semibold text-muted-foreground">Status</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-border/50">
                                {selectedObject?.mappings.map((mapping) => {
                                  const fieldKey = mapping.target.targetFieldName;
                                  const isMandatory = mapping.target.mandatory === 'Yes';
                                  const currentVal = isEditing ? (editBuffer[fieldKey] ?? currentData[fieldKey] ?? '') : (currentData[fieldKey] ?? '');
                                  const errorMsg = isEditing
                                    ? (() => {
                                        const { pass, message } = applyValidationRule(mapping.target.validationRule, editBuffer[fieldKey] ?? currentData[fieldKey] ?? '', isMandatory);
                                        return pass ? null : message;
                                      })()
                                    : liveFieldErrors[fieldKey] || null;
                                  let hasError = !!errorMsg;
                                  const wasRemapped = hasRemap && remappedData[rec.seq]?.[fieldKey] !== undefined;

                                  return (
                                    <tr
                                      key={fieldKey}
                                      className={`transition-colors ${
                                        hasError ? 'bg-red-50/40' : wasRemapped ? 'bg-emerald-50/40' : ''
                                      }`}
                                    >
                                      <td className="px-4 py-2">
                                        <div className="flex items-center gap-1.5">
                                          <span className="font-mono text-foreground">{fieldKey}</span>
                                          {isMandatory && (
                                            <span className="text-red-500 text-xs" title="Mandatory">*</span>
                                          )}
                                        </div>
                                      </td>
                                      <td className="px-4 py-2">
                                        {isEditing ? (
                                          <input
                                            type="text"
                                            value={editBuffer[fieldKey] ?? currentData[fieldKey] ?? ''}
                                            onChange={(e) =>
                                              setEditBuffer((prev) => ({ ...prev, [fieldKey]: e.target.value }))
                                            }
                                            className={`w-full px-2 py-1 rounded border text-xs bg-white focus:outline-none focus:ring-1 ${
                                              hasError
                                                ? 'border-red-400 focus:ring-red-300' :'border-border focus:ring-primary/30'
                                            }`}
                                            placeholder={`Enter ${fieldKey}`}
                                          />
                                        ) : (
                                          <span className={`font-mono ${wasRemapped ? 'text-emerald-700 font-semibold' : 'text-foreground'}`}>
                                            {currentVal || <span className="text-muted-foreground italic">empty</span>}
                                          </span>
                                        )}
                                      </td>
                                      <td className="px-4 py-2 text-muted-foreground font-mono">
                                        {mapping.target.validationRule || (isMandatory ? 'Mandatory' : '—')}
                                      </td>
                                      <td className="px-4 py-2">
                                        {hasError ? (
                                          <div className="flex items-start gap-1.5">
                                            <XCircle size={12} className="text-red-500 mt-0.5 flex-shrink-0" />
                                            <span className="text-red-600">{errorMsg}</span>
                                          </div>
                                        ) : wasRemapped ? (
                                          <div className="flex items-center gap-1.5">
                                            <CheckCircle2 size={12} className="text-emerald-500" />
                                            <span className="text-emerald-600">Fixed</span>
                                          </div>
                                        ) : (
                                          <div className="flex items-center gap-1.5">
                                            <CheckCircle2 size={12} className="text-emerald-500" />
                                            <span className="text-emerald-600">OK</span>
                                          </div>
                                        )}
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function StatCard({
  label,
  value,
  sub,
  icon,
  color,
}: {
  label: string;
  value: number;
  sub?: string;
  icon: React.ReactNode;
  color: 'blue' | 'emerald' | 'green' | 'primary';
}) {
  const colorMap = {
    blue: 'bg-blue-500/10 text-blue-500',
    emerald: 'bg-emerald-500/10 text-emerald-500',
    green: 'bg-green-500/10 text-green-500',
    primary: 'bg-primary/10 text-primary',
  };

  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-muted-foreground font-medium">{label}</span>
        <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${colorMap[color]}`}>
          {icon}
        </div>
      </div>
      <p className="text-2xl font-bold text-foreground">{value}</p>
      {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-1 border-b border-border/50">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-xs font-medium text-foreground">{value}</span>
    </div>
  );
}

function ProgressRow({
  label,
  value,
  total,
  color,
}: {
  label: string;
  value: number;
  total: number;
  color: 'emerald' | 'amber' | 'red';
}) {
  const pct = total > 0 ? Math.round((value / total) * 100) : 0;
  const barColor = { emerald: 'bg-emerald-500', amber: 'bg-amber-400', red: 'bg-red-500' }[color];

  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className="text-xs font-semibold text-foreground">{value} <span className="text-muted-foreground font-normal">({pct}%)</span></span>
      </div>
      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${barColor}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function StatusBadge({
  status,
  type,
}: {
  status: string;
  type: 'transform' | 'validation';
}) {
  if (type === 'transform') {
    if (status === 'success') return <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-600"><CheckCircle2 size={10} />OK</span>;
    if (status === 'warning') return <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-500/10 text-amber-600"><AlertTriangle size={10} />Warning</span>;
    return <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-red-500/10 text-red-600"><XCircle size={10} />Error</span>;
  }
  if (status === 'pass') return <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-600"><CheckCircle2 size={10} />Pass</span>;
  if (status === 'warning') return <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-500/10 text-amber-600"><AlertTriangle size={10} />Warning</span>;
  return <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-red-500/10 text-red-600"><XCircle size={10} />Fail</span>;
}
