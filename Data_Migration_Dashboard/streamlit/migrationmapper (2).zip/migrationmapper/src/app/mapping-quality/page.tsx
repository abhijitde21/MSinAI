'use client';

import React, { useState, useEffect } from 'react';
import AppLayout from '@/components/AppLayout';
import { getProjectCatalogue, type ProjectCatalogueEntry, type FieldMapping } from '@/lib/mappingStore';
import {
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  ChevronDown,
  ChevronRight,
  BarChart3,
  Target,
  Layers,
  FileWarning,
  TrendingUp,
  Info,
} from 'lucide-react';

// ── Types ──────────────────────────────────────────────────────────────────────

interface ObjectQuality {
  objectName: string;
  projectName: string;
  processArea: string;
  totalFields: number;
  mappedFields: number;
  completeness: number;
  validationCoverage: number;
  transformationCoverage: number;
  missingTransformations: string[];
  missingValidations: string[];
  mandatoryUnmapped: number;
  qualityScore: number;
}

interface ProjectQuality {
  projectName: string;
  clientName: string;
  objects: ObjectQuality[];
  avgCompleteness: number;
  avgValidation: number;
  avgTransformation: number;
  avgQualityScore: number;
  totalObjects: number;
  readyObjects: number;
}

// ── Quality Computation ────────────────────────────────────────────────────────

function computeObjectQuality(
  objectName: string,
  projectName: string,
  processArea: string,
  mappings: FieldMapping[]
): ObjectQuality {
  const total = mappings.length;
  if (total === 0) {
    return {
      objectName,
      projectName,
      processArea,
      totalFields: 0,
      mappedFields: 0,
      completeness: 0,
      validationCoverage: 0,
      transformationCoverage: 0,
      missingTransformations: [],
      missingValidations: [],
      mandatoryUnmapped: 0,
      qualityScore: 0,
    };
  }

  const mappedFields = mappings.filter(
    (m) => m.target.targetFieldName && m.target.targetFieldName.trim() !== ''
  ).length;

  const withValidation = mappings.filter(
    (m) => m.target.validationRule && m.target.validationRule.trim() !== ''
  ).length;

  const withTransformation = mappings.filter(
    (m) =>
      m.target.transformationType &&
      m.target.transformationType !== 'None' &&
      m.target.transformationRule &&
      m.target.transformationRule.trim() !== ''
  ).length;

  const missingTransformations = mappings
    .filter(
      (m) =>
        m.target.transformationType &&
        m.target.transformationType !== 'None' &&
        m.target.transformationType !== 'Direct' &&
        (!m.target.transformationRule || m.target.transformationRule.trim() === '')
    )
    .map((m) => m.target.targetFieldName || m.source.fieldName)
    .filter(Boolean);

  const missingValidations = mappings
    .filter(
      (m) =>
        m.target.mandatory === 'Yes' &&
        (!m.target.validationRule || m.target.validationRule.trim() === '')
    )
    .map((m) => m.target.targetFieldName || m.source.fieldName)
    .filter(Boolean);

  const mandatoryUnmapped = mappings.filter(
    (m) =>
      m.target.mandatory === 'Yes' &&
      (!m.target.targetFieldName || m.target.targetFieldName.trim() === '')
  ).length;

  const completeness = Math.round((mappedFields / total) * 100);
  const validationCoverage = Math.round((withValidation / total) * 100);
  const transformationCoverage = Math.round((withTransformation / total) * 100);

  const qualityScore = Math.round(
    completeness * 0.4 +
      validationCoverage * 0.3 +
      transformationCoverage * 0.2 +
      (mandatoryUnmapped === 0 ? 10 : 0)
  );

  return {
    objectName,
    projectName,
    processArea,
    totalFields: total,
    mappedFields,
    completeness,
    validationCoverage,
    transformationCoverage,
    missingTransformations,
    missingValidations,
    mandatoryUnmapped,
    qualityScore,
  };
}

function buildProjectQuality(catalogue: ProjectCatalogueEntry[]): ProjectQuality[] {
  return catalogue
    .map((entry) => {
      const objectMap = new Map<string, FieldMapping[]>();
      for (const iter of entry.iterations) {
        const key = iter.objectName || 'Unknown Object';
        if (!objectMap.has(key)) objectMap.set(key, []);
        objectMap.set(key, iter.mappings);
      }

      const objects: ObjectQuality[] = Array.from(objectMap.entries()).map(([objName, mappings]) =>
        computeObjectQuality(
          objName,
          entry.projectDetails.projectName,
          entry.projectDetails.processArea || 'General',
          mappings
        )
      );

      const avg = (arr: number[]) =>
        arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length) : 0;

      return {
        projectName: entry.projectDetails.projectName,
        clientName: entry.projectDetails.clientName || '—',
        objects,
        avgCompleteness: avg(objects.map((o) => o.completeness)),
        avgValidation: avg(objects.map((o) => o.validationCoverage)),
        avgTransformation: avg(objects.map((o) => o.transformationCoverage)),
        avgQualityScore: avg(objects.map((o) => o.qualityScore)),
        totalObjects: objects.length,
        readyObjects: objects.filter((o) => o.qualityScore >= 80).length,
      };
    })
    .filter((p) => p.objects.length > 0);
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function ScoreRing({ value, size = 64 }: { value: number; size?: number }) {
  const radius = (size - 8) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;
  const color =
    value >= 80 ? '#10b981' : value >= 60 ? '#f59e0b' : '#ef4444';

  return (
    <svg width={size} height={size} className="rotate-[-90deg]">
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke="rgba(15,23,42,0.08)"
        strokeWidth={6}
      />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke={color}
        strokeWidth={6}
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        strokeLinecap="round"
        style={{ transition: 'stroke-dashoffset 0.6s ease' }}
      />
    </svg>
  );
}

function MetricBar({
  label,
  value,
  color,
}: {
  label: string;
  value: number;
  color: string;
}) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between items-center">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className="text-xs font-semibold text-foreground">{value}%</span>
      </div>
      <div className="h-1.5 rounded-full bg-secondary">
        <div
          className="h-1.5 rounded-full transition-all duration-700"
          style={{ width: `${value}%`, backgroundColor: color }}
        />
      </div>
    </div>
  );
}

function QualityBadge({ score }: { score: number }) {
  if (score >= 80)
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
        <CheckCircle2 size={10} /> Ready
      </span>
    );
  if (score >= 60)
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200">
        <AlertTriangle size={10} /> Needs Review
      </span>
    );
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-red-50 text-red-700 border border-red-200">
      <XCircle size={10} /> Incomplete
    </span>
  );
}

function ObjectQualityRow({ obj }: { obj: ObjectQuality }) {
  const [expanded, setExpanded] = useState(false);
  const hasIssues = obj.missingTransformations.length > 0 || obj.missingValidations.length > 0 || obj.mandatoryUnmapped > 0;

  return (
    <>
      <tr
        className="border-b cursor-pointer hover:bg-secondary/40 transition-colors"
        style={{ borderColor: 'var(--border)' }}
        onClick={() => hasIssues && setExpanded((p) => !p)}
      >
        <td className="px-4 py-3">
          <div className="flex items-center gap-2">
            {hasIssues ? (
              expanded ? (
                <ChevronDown size={14} className="text-muted-foreground flex-shrink-0" />
              ) : (
                <ChevronRight size={14} className="text-muted-foreground flex-shrink-0" />
              )
            ) : (
              <span className="w-3.5" />
            )}
            <span className="text-sm font-medium text-foreground">{obj.objectName}</span>
          </div>
        </td>
        <td className="px-4 py-3 text-xs text-muted-foreground">{obj.processArea}</td>
        <td className="px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="flex-1 h-1.5 rounded-full bg-secondary" style={{ minWidth: 60 }}>
              <div
                className="h-1.5 rounded-full"
                style={{
                  width: `${obj.completeness}%`,
                  backgroundColor: obj.completeness >= 80 ? '#10b981' : obj.completeness >= 60 ? '#f59e0b' : '#ef4444',
                }}
              />
            </div>
            <span className="text-xs font-semibold text-foreground w-9 text-right">{obj.completeness}%</span>
          </div>
        </td>
        <td className="px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="flex-1 h-1.5 rounded-full bg-secondary" style={{ minWidth: 60 }}>
              <div
                className="h-1.5 rounded-full"
                style={{
                  width: `${obj.validationCoverage}%`,
                  backgroundColor: obj.validationCoverage >= 70 ? '#10b981' : obj.validationCoverage >= 40 ? '#f59e0b' : '#ef4444',
                }}
              />
            </div>
            <span className="text-xs font-semibold text-foreground w-9 text-right">{obj.validationCoverage}%</span>
          </div>
        </td>
        <td className="px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="flex-1 h-1.5 rounded-full bg-secondary" style={{ minWidth: 60 }}>
              <div
                className="h-1.5 rounded-full"
                style={{
                  width: `${obj.transformationCoverage}%`,
                  backgroundColor: obj.transformationCoverage >= 70 ? '#10b981' : obj.transformationCoverage >= 40 ? '#f59e0b' : '#ef4444',
                }}
              />
            </div>
            <span className="text-xs font-semibold text-foreground w-9 text-right">{obj.transformationCoverage}%</span>
          </div>
        </td>
        <td className="px-4 py-3 text-center">
          {obj.mandatoryUnmapped > 0 ? (
            <span className="text-xs font-semibold text-red-600">{obj.mandatoryUnmapped}</span>
          ) : (
            <CheckCircle2 size={14} className="text-emerald-600 mx-auto" />
          )}
        </td>
        <td className="px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-foreground">{obj.qualityScore}</span>
            <span className="text-xs text-muted-foreground">/100</span>
          </div>
        </td>
        <td className="px-4 py-3">
          <QualityBadge score={obj.qualityScore} />
        </td>
      </tr>
      {expanded && hasIssues && (
        <tr className="bg-secondary/20">
          <td colSpan={8} className="px-6 py-3">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {obj.mandatoryUnmapped > 0 && (
                <div className="rounded-lg p-3 bg-red-50 border border-red-200">
                  <p className="text-xs font-semibold text-red-700 mb-1.5 flex items-center gap-1.5">
                    <XCircle size={12} /> Mandatory Fields Unmapped ({obj.mandatoryUnmapped})
                  </p>
                  <p className="text-xs text-red-600">
                    {obj.mandatoryUnmapped} mandatory target field(s) have no source mapping. These must be resolved before export.
                  </p>
                </div>
              )}
              {obj.missingTransformations.length > 0 && (
                <div className="rounded-lg p-3 bg-amber-50 border border-amber-200">
                  <p className="text-xs font-semibold text-amber-700 mb-1.5 flex items-center gap-1.5">
                    <FileWarning size={12} /> Missing Transformation Rules ({obj.missingTransformations.length})
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {obj.missingTransformations.slice(0, 6).map((f, i) => (
                      <span key={i} className="text-xs px-1.5 py-0.5 rounded bg-amber-100 text-amber-800">
                        {f}
                      </span>
                    ))}
                    {obj.missingTransformations.length > 6 && (
                      <span className="text-xs text-muted-foreground">+{obj.missingTransformations.length - 6} more</span>
                    )}
                  </div>
                </div>
              )}
              {obj.missingValidations.length > 0 && (
                <div className="rounded-lg p-3 bg-purple-50 border border-purple-200">
                  <p className="text-xs font-semibold text-purple-700 mb-1.5 flex items-center gap-1.5">
                    <ShieldCheck size={12} /> Mandatory Fields Without Validation ({obj.missingValidations.length})
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {obj.missingValidations.slice(0, 6).map((f, i) => (
                      <span key={i} className="text-xs px-1.5 py-0.5 rounded bg-purple-100 text-purple-800">
                        {f}
                      </span>
                    ))}
                    {obj.missingValidations.length > 6 && (
                      <span className="text-xs text-muted-foreground">+{obj.missingValidations.length - 6} more</span>
                    )}
                  </div>
                </div>
              )}
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────

export default function MappingQualityPage() {
  return (
    <AppLayout>
      <MappingQualityContent />
    </AppLayout>
  );
}

function MappingQualityContent() {
  const [projects, setProjects] = useState<ProjectQuality[]>([]);
  const [expandedProjects, setExpandedProjects] = useState<Set<string>>(new Set());
  const [filterStatus, setFilterStatus] = useState<'all' | 'ready' | 'review' | 'incomplete'>('all');

  useEffect(() => {
    const catalogue = getProjectCatalogue();
    const quality = buildProjectQuality(catalogue);
    setProjects(quality);
    if (quality.length > 0) {
      setExpandedProjects(new Set([quality[0].projectName]));
    }
  }, []);

  const toggleProject = (name: string) => {
    setExpandedProjects((prev) => {
      const next = new Set(prev);
      next.has(name) ? next.delete(name) : next.add(name);
      return next;
    });
  };

  const allObjects = projects.flatMap((p) => p.objects);
  const globalCompleteness =
    allObjects.length
      ? Math.round(allObjects.reduce((a, o) => a + o.completeness, 0) / allObjects.length)
      : 0;
  const globalValidation =
    allObjects.length
      ? Math.round(allObjects.reduce((a, o) => a + o.validationCoverage, 0) / allObjects.length)
      : 0;
  const globalTransformation =
    allObjects.length
      ? Math.round(allObjects.reduce((a, o) => a + o.transformationCoverage, 0) / allObjects.length)
      : 0;
  const readyCount = allObjects.filter((o) => o.qualityScore >= 80).length;
  const reviewCount = allObjects.filter((o) => o.qualityScore >= 60 && o.qualityScore < 80).length;
  const incompleteCount = allObjects.filter((o) => o.qualityScore < 60).length;

  const filterObject = (obj: ObjectQuality) => {
    if (filterStatus === 'ready') return obj.qualityScore >= 80;
    if (filterStatus === 'review') return obj.qualityScore >= 60 && obj.qualityScore < 80;
    if (filterStatus === 'incomplete') return obj.qualityScore < 60;
    return true;
  };

  return (
    <div className="p-6 space-y-6 max-w-screen-xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg gradient-primary flex items-center justify-center flex-shrink-0">
            <BarChart3 size={18} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">Mapping Quality</h1>
            <p className="text-sm text-muted-foreground">
              Completeness, validation coverage, and gap analysis before Excel export
            </p>
          </div>
        </div>
        {/* Filter pills */}
        <div className="flex items-center gap-2 flex-wrap">
          {(['all', 'ready', 'review', 'incomplete'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilterStatus(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all border ${
                filterStatus === f
                  ? 'bg-primary text-white border-primary' :'text-muted-foreground hover:text-foreground bg-card border-border hover:border-primary/40'
              }`}
            >
              {f === 'all' ? 'All Objects' : f === 'ready' ? '✓ Ready' : f === 'review' ? '⚠ Needs Review' : '✗ Incomplete'}
            </button>
          ))}
        </div>
      </div>

      {/* Global Summary Cards */}
      {allObjects.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {/* Completeness */}
          <div className="rounded-xl p-4 flex items-center gap-4 bg-card border border-border shadow-sm">
            <div className="relative flex-shrink-0">
              <ScoreRing value={globalCompleteness} size={56} />
              <span
                className="absolute inset-0 flex items-center justify-center text-xs font-bold text-foreground"
                style={{ transform: 'rotate(90deg)' }}
              >
                {globalCompleteness}%
              </span>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Mapping Completeness</p>
              <p className="text-lg font-bold text-foreground">{globalCompleteness}%</p>
              <p className="text-xs text-muted-foreground">{allObjects.length} objects</p>
            </div>
          </div>

          {/* Validation */}
          <div className="rounded-xl p-4 flex items-center gap-4 bg-card border border-border shadow-sm">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 bg-purple-50">
              <ShieldCheck size={20} className="text-purple-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-muted-foreground">Validation Coverage</p>
              <p className="text-lg font-bold text-foreground">{globalValidation}%</p>
              <MetricBar label="" value={globalValidation} color="#8b5cf6" />
            </div>
          </div>

          {/* Transformation */}
          <div className="rounded-xl p-4 flex items-center gap-4 bg-card border border-border shadow-sm">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 bg-amber-50">
              <Target size={20} className="text-amber-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-muted-foreground">Transformation Rules</p>
              <p className="text-lg font-bold text-foreground">{globalTransformation}%</p>
              <MetricBar label="" value={globalTransformation} color="#f59e0b" />
            </div>
          </div>

          {/* Export Readiness */}
          <div className="rounded-xl p-4 bg-card border border-border shadow-sm">
            <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5">
              <TrendingUp size={12} /> Export Readiness
            </p>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs text-emerald-700 flex items-center gap-1"><CheckCircle2 size={10} /> Ready</span>
                <span className="text-xs font-bold text-foreground">{readyCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-amber-700 flex items-center gap-1"><AlertTriangle size={10} /> Review</span>
                <span className="text-xs font-bold text-foreground">{reviewCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-red-700 flex items-center gap-1"><XCircle size={10} /> Incomplete</span>
                <span className="text-xs font-bold text-foreground">{incompleteCount}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Empty state */}
      {projects.length === 0 && (
        <div className="rounded-xl p-12 text-center bg-card border border-border">
          <Layers size={40} className="text-muted-foreground mx-auto mb-3" />
          <p className="text-foreground font-semibold mb-1">No mapping data found</p>
          <p className="text-sm text-muted-foreground">
            Generate mappings in the Mapping Generator to see quality metrics here.
          </p>
        </div>
      )}

      {/* Per-project sections */}
      {projects.map((project) => {
        const isExpanded = expandedProjects.has(project.projectName);
        const filteredObjects = project.objects.filter(filterObject);

        return (
          <div
            key={project.projectName}
            className="rounded-xl overflow-hidden bg-card border border-border shadow-sm"
          >
            {/* Project header */}
            <button
              className="w-full flex items-center gap-3 px-5 py-4 hover:bg-secondary/40 transition-colors text-left"
              onClick={() => toggleProject(project.projectName)}
            >
              {isExpanded ? (
                <ChevronDown size={16} className="text-muted-foreground flex-shrink-0" />
              ) : (
                <ChevronRight size={16} className="text-muted-foreground flex-shrink-0" />
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-bold text-foreground">{project.projectName}</span>
                  <span className="text-xs text-muted-foreground">{project.clientName}</span>
                </div>
              </div>
              {/* Mini metrics */}
              <div className="hidden md:flex items-center gap-6 mr-2">
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">Completeness</p>
                  <p className="text-sm font-bold" style={{ color: project.avgCompleteness >= 80 ? '#16a34a' : project.avgCompleteness >= 60 ? '#d97706' : '#dc2626' }}>
                    {project.avgCompleteness}%
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">Validation</p>
                  <p className="text-sm font-bold text-purple-600">{project.avgValidation}%</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">Transformation</p>
                  <p className="text-sm font-bold text-amber-600">{project.avgTransformation}%</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">Quality Score</p>
                  <p className="text-sm font-bold text-foreground">{project.avgQualityScore}/100</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">Ready</p>
                  <p className="text-sm font-bold text-emerald-600">{project.readyObjects}/{project.totalObjects}</p>
                </div>
              </div>
            </button>

            {/* Object table */}
            {isExpanded && (
              <div className="border-t border-border">
                {filteredObjects.length === 0 ? (
                  <div className="px-6 py-6 text-center">
                    <p className="text-sm text-muted-foreground">No objects match the selected filter.</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-secondary/50 border-b border-border">
                          <th className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">Object Name</th>
                          <th className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">Process Area</th>
                          <th className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">
                            <span className="flex items-center gap-1">
                              Completeness
                              <Info size={10} className="text-muted-foreground" title="% of target fields with a source mapping" />
                            </span>
                          </th>
                          <th className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">
                            <span className="flex items-center gap-1">
                              Validation Coverage
                              <Info size={10} className="text-muted-foreground" title="% of fields with a validation rule defined" />
                            </span>
                          </th>
                          <th className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">
                            <span className="flex items-center gap-1">
                              Transformation Rules
                              <Info size={10} className="text-muted-foreground" title="% of non-direct fields with transformation rule text" />
                            </span>
                          </th>
                          <th className="px-4 py-2.5 text-center text-xs font-semibold text-muted-foreground">Mandatory Gaps</th>
                          <th className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">Quality Score</th>
                          <th className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredObjects.map((obj) => (
                          <ObjectQualityRow key={obj.objectName} obj={obj} />
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Legend */}
                <div className="px-5 py-3 flex items-center gap-4 flex-wrap border-t border-border bg-secondary/20">
                  <span className="text-xs text-muted-foreground flex items-center gap-1.5">
                    <Info size={11} />
                    Click a row to expand gap details.
                  </span>
                  <span className="text-xs text-emerald-700 font-medium">≥80 Ready</span>
                  <span className="text-xs text-amber-700 font-medium">60–79 Needs Review</span>
                  <span className="text-xs text-red-700 font-medium">&lt;60 Incomplete</span>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
