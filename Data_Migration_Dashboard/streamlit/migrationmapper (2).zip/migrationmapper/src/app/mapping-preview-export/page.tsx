import React from 'react';
import AppLayout from '@/components/AppLayout';
import MappingPreviewContent from './components/MappingPreviewContent';

export default function MappingPreviewPage() {
  return (
    <AppLayout>
      <MappingPreviewContent />
    </AppLayout>
  );
}