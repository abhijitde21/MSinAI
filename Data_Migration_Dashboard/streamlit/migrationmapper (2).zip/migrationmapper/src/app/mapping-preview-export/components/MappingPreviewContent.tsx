'use client';

import React, { useState, useEffect } from 'react';
import { getMappingSession } from '@/lib/mappingStore';
import type { MappingSession, FieldMapping } from '@/lib/mappingStore';
import MappingProjectHeader from './MappingProjectHeader';
import MappingSummaryStats from './MappingSummaryStats';
import MappingTable from './MappingTable';
import ExportPanel from './ExportPanel';
import { TableProperties, ArrowLeft } from 'lucide-react';
import Link from 'next/link';

export default function MappingPreviewContent() {
  const [session, setSession] = useState<MappingSession | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const s = getMappingSession();
    setSession(s);
    setLoaded(true);
  }, []);

  const handleMappingUpdate = (updated: FieldMapping[]) => {
    if (!session) return;
    setSession({ ...session, mappings: updated });
  };

  if (!loaded) {
    return (
      <div className="p-8 max-w-screen-2xl">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-secondary rounded-lg w-64" />
          <div className="h-32 bg-secondary rounded-xl" />
          <div className="h-96 bg-secondary rounded-xl" />
        </div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center p-8">
        <div className="card-panel p-10 max-w-md text-center">
          <div className="w-14 h-14 rounded-xl bg-secondary flex items-center justify-center mx-auto mb-4">
            <TableProperties size={24} className="text-muted-foreground" />
          </div>
          <h2 className="text-lg font-semibold text-foreground mb-2">No Mapping Sheet Found</h2>
          <p className="text-sm text-muted-foreground mb-6">
            No mapping session is active. Go to the Mapping Generator to upload an XML template and generate a mapping sheet before previewing it here.
          </p>
          <Link href="/" className="btn-primary inline-flex">
            <ArrowLeft size={15} />
            Go to Mapping Generator
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen px-4 py-6 xl:px-8 2xl:px-12 max-w-screen-2xl">
      {/* Page header */}
      <div className="flex items-start justify-between mb-5 gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
            <TableProperties size={13} />
            <span>Mapping Sheet Preview</span>
          </div>
          <h1 className="page-title">Preview & Export</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Review all field mappings, edit inline, then export a branded Excel file.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <Link href="/" className="btn-secondary text-sm">
            <ArrowLeft size={14} />
            Back to Generator
          </Link>
        </div>
      </div>

      {/* Project header */}
      <MappingProjectHeader session={session} />

      {/* Summary stats */}
      <div className="mt-5">
        <MappingSummaryStats mappings={session.mappings} />
      </div>

      {/* Export panel */}
      <div className="mt-5">
        <ExportPanel session={session} />
      </div>

      {/* Mapping table */}
      <div className="mt-5">
        <MappingTable
          mappings={session.mappings}
          onUpdate={handleMappingUpdate}
        />
      </div>
    </div>
  );
}