'use client';

import React from 'react';
import type { FieldMapping } from '@/lib/mappingStore';
import {
  Hash,
  AlertTriangle,
  CheckCircle2,
  Zap,
} from 'lucide-react';

interface Props {
  mappings: FieldMapping[];
}

export default function MappingSummaryStats({ mappings }: Props) {
  const total = mappings.length;
  const mandatory = mappings.filter((m) => m.target.mandatory === 'Yes').length;
  const migrationRequired = mappings.filter((m) => m.target.migrationRequired === 'Yes').length;
  const rulesPopulated = mappings.filter((m) => m.target.transformationRule && m.target.transformationRule.trim()).length;
  const rulesPct = total > 0 ? Math.round((rulesPopulated / total) * 100) : 0;

  const stats = [
    {
      id: 'stat-total',
      label: 'Total Fields',
      value: String(total),
      sub: 'from XML template',
      icon: <Hash size={18} className="text-primary" />,
      bg: 'bg-blue-50',
      border: 'border-blue-100',
    },
    {
      id: 'stat-mandatory',
      label: 'Mandatory Fields',
      value: String(mandatory),
      sub: `${total - mandatory} optional`,
      icon: <AlertTriangle size={18} className="text-warning" />,
      bg: 'bg-warning-bg',
      border: 'border-amber-100',
    },
    {
      id: 'stat-migration',
      label: 'Migration Required',
      value: String(migrationRequired),
      sub: `${total - migrationRequired} not required`,
      icon: <CheckCircle2 size={18} className="text-success" />,
      bg: 'bg-success-bg',
      border: 'border-green-100',
    },
    {
      id: 'stat-rules',
      label: 'Rules Populated',
      value: `${rulesPct}%`,
      sub: `${rulesPopulated} of ${total} fields`,
      icon: <Zap size={18} className="text-accent" />,
      bg: 'bg-info-bg',
      border: 'border-sky-100',
    },
  ];

  return (
    <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
      {stats.map((s) => (
        <div
          key={s.id}
          className={`card-panel p-4 flex items-start gap-3 ${s.bg} ${s.border}`}
        >
          <div className="w-9 h-9 rounded-lg bg-white flex items-center justify-center shadow-sm flex-shrink-0">
            {s.icon}
          </div>
          <div>
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-0.5">
              {s.label}
            </p>
            <p className="text-2xl font-bold font-tabular text-foreground leading-none mb-0.5">
              {s.value}
            </p>
            <p className="text-xs text-muted-foreground">{s.sub}</p>
          </div>
        </div>
      ))}
    </div>
  );
}