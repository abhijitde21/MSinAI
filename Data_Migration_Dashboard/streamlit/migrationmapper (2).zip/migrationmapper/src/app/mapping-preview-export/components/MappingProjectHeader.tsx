'use client';

import React from 'react';
import type { MappingSession } from '@/lib/mappingStore';
import AppImage from '@/components/ui/AppImage';
import { User, Calendar, Layers, FileCode2, GitBranch, Server } from 'lucide-react';

interface Props {
  session: MappingSession;
}

export default function MappingProjectHeader({ session }: Props) {
  const pd = session.projectDetails;

  return (
    <div className="card-panel overflow-hidden">
      {/* Top gradient band */}
      <div className="gradient-primary px-6 py-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          {pd.clientLogoDataUrl && (
            <div className="h-10 bg-white rounded-lg px-3 flex items-center">
              <AppImage
                src={pd.clientLogoDataUrl}
                alt={`${pd.clientName} logo`}
                width={100}
                height={36}
                className="h-8 w-auto object-contain"
              />
            </div>
          )}
          <div>
            <h2 className="text-white font-bold text-lg leading-tight">{pd.projectName}</h2>
            <p className="text-blue-200 text-sm">{pd.clientName}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {pd.partnerLogoDataUrl && (
            <div className="h-10 bg-white rounded-lg px-3 flex items-center">
              <AppImage
                src={pd.partnerLogoDataUrl}
                alt="Partner consulting firm logo"
                width={100}
                height={36}
                className="h-8 w-auto object-contain"
              />
            </div>
          )}
          <div className="text-right">
            <p className="text-blue-200 text-xs font-medium">Field-to-Field Mapping</p>
            <p className="text-white text-xs">Generated {session.generatedAt}</p>
          </div>
        </div>
      </div>

      {/* Metadata row */}
      <div className="px-6 py-4 grid grid-cols-2 md:grid-cols-3 xl:grid-cols-7 gap-4">
        {[
          { icon: <Layers size={13} />, label: 'Process Area', value: pd.processArea || '—' },
          { icon: <GitBranch size={13} />, label: 'Phase', value: pd.phase || '—' },
          { icon: <FileCode2 size={13} />, label: 'Object Name', value: pd.objectName || '—' },
          { icon: <Server size={13} />, label: 'Source System', value: pd.sourceSystem || '—' },
          { icon: <User size={13} />, label: 'DM Consultant', value: pd.dmConsultant || '—' },
          { icon: <User size={13} />, label: 'Functional Owner', value: pd.functionalOwner || '—' },
          { icon: <Calendar size={13} />, label: 'Created Date', value: pd.createdDate || '—' },
        ].map((item) => (
          <div key={`hdr-${item.label}`}>
            <div className="flex items-center gap-1 text-muted-foreground mb-0.5">
              {item.icon}
              <span className="text-xs font-medium uppercase tracking-wider">{item.label}</span>
            </div>
            <p className="text-sm font-semibold text-foreground truncate" title={item.value}>
              {item.value}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}