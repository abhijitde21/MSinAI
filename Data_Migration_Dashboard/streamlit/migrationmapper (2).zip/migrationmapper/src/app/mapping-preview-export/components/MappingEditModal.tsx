'use client';

import React, { useEffect, useRef } from 'react';
import { useForm } from 'react-hook-form';
import type { FieldMapping } from '@/lib/mappingStore';
import { X, Save, Loader2, AlertTriangle } from 'lucide-react';

interface Props {
  row: FieldMapping;
  onSave: (updated: FieldMapping) => void;
  onClose: () => void;
}

interface FormValues {
  // Source
  srcTableName: string;
  srcTableDescription: string;
  srcFieldName: string;
  srcFieldDescription: string;
  srcDataType: string;
  srcLength: string;
  srcDecimal: string;
  // Target
  targetViewName: string;
  targetFieldName: string;
  targetFieldDescription: string;
  targetFieldDataType: string;
  targetFieldLength: string;
  targetFieldDecimal: string;
  targetHanaTable: string;
  checkTable: string;
  mandatory: 'Yes' | 'No';
  migrationRequired: 'Yes' | 'No';
  transformationType: FieldMapping['target']['transformationType'];
  transformationRule: string;
  validationRule: string;
}

const DATA_TYPES = ['CHAR', 'NUMC', 'DATS', 'TIMS', 'CURR', 'CUKY', 'QUAN', 'UNIT', 'LANG', 'CLNT', 'INT1', 'INT2', 'INT4', 'FLTP', 'DEC', 'RAW', 'LRAW', 'STRING', 'XSTRING'];
const TRANS_TYPES: FieldMapping['target']['transformationType'][] = ['Direct', 'Lookup', 'Concatenation', 'Default', 'Conditional', 'Derivation', 'None'];

export default function MappingEditModal({ row, onSave, onClose }: Props) {
  const overlayRef = useRef<HTMLDivElement>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    defaultValues: {
      srcTableName: row.source.tableName,
      srcTableDescription: row.source.tableDescription,
      srcFieldName: row.source.fieldName,
      srcFieldDescription: row.source.fieldDescription,
      srcDataType: row.source.dataType,
      srcLength: row.source.length,
      srcDecimal: row.source.decimal,
      targetViewName: row.target.targetViewName,
      targetFieldName: row.target.targetFieldName,
      targetFieldDescription: row.target.targetFieldDescription,
      targetFieldDataType: row.target.targetFieldDataType,
      targetFieldLength: row.target.targetFieldLength,
      targetFieldDecimal: row.target.targetFieldDecimal,
      targetHanaTable: row.target.targetHanaTable,
      checkTable: row.target.checkTable,
      mandatory: row.target.mandatory,
      migrationRequired: row.target.migrationRequired,
      transformationType: row.target.transformationType,
      transformationRule: row.target.transformationRule,
      validationRule: row.target.validationRule,
    },
  });

  // Close on Escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [onClose]);

  // Close on backdrop click
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === overlayRef.current) onClose();
  };

  const onFormSubmit = (data: FormValues) => {
    const updated: FieldMapping = {
      ...row,
      source: {
        ...row.source,
        tableName: data.srcTableName,
        tableDescription: data.srcTableDescription,
        fieldName: data.srcFieldName,
        fieldDescription: data.srcFieldDescription,
        dataType: data.srcDataType,
        length: data.srcLength,
        decimal: data.srcDecimal,
      },
      target: {
        targetViewName: data.targetViewName,
        targetFieldName: data.targetFieldName,
        targetFieldDescription: data.targetFieldDescription,
        targetFieldDataType: data.targetFieldDataType,
        targetFieldLength: data.targetFieldLength,
        targetFieldDecimal: data.targetFieldDecimal,
        targetHanaTable: data.targetHanaTable,
        checkTable: data.checkTable,
        mandatory: data.mandatory,
        migrationRequired: data.migrationRequired,
        transformationType: data.transformationType,
        transformationRule: data.transformationRule,
        validationRule: data.validationRule,
      },
    };
    onSave(updated);
  };

  return (
    <div
      ref={overlayRef}
      className="fixed inset-0 z-50 modal-backdrop flex items-center justify-center p-4"
      onClick={handleBackdropClick}
      role="dialog"
      aria-modal="true"
      aria-label={`Edit mapping for field ${row.target.targetFieldName}`}
    >
      <div className="bg-card rounded-2xl shadow-modal w-full max-w-3xl max-h-[90vh] flex flex-col animate-fadeScale">
        {/* Modal header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div>
            <h2 className="text-base font-semibold text-foreground">
              Edit Field Mapping — Row {row.seq}
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              <span className="font-mono font-semibold text-foreground">{row.source.fieldName}</span>
              <span className="mx-2 text-border">→</span>
              <span className="font-mono font-semibold text-blue-700">{row.target.targetFieldName}</span>
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
            aria-label="Close edit modal"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal body — scrollable */}
        <form onSubmit={handleSubmit(onFormSubmit)} className="flex flex-col flex-1 min-h-0">
          <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-6">
            {/* Source section */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-2 h-2 rounded-full bg-muted-foreground" />
                <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider">Source Fields</h3>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="col-span-2">
                  <label className="label-field" htmlFor="edit-srcTableName">Table Name</label>
                  <input id="edit-srcTableName" className="input-field" placeholder="EKKO" {...register('srcTableName')} />
                </div>
                <div className="col-span-2">
                  <label className="label-field" htmlFor="edit-srcTableDescription">Table Description</label>
                  <input id="edit-srcTableDescription" className="input-field" placeholder="Purchasing Document Header" {...register('srcTableDescription')} />
                </div>
                <div className="col-span-2">
                  <label className="label-field" htmlFor="edit-srcFieldName">
                    Field Name <span className="text-danger">*</span>
                  </label>
                  <input
                    id="edit-srcFieldName"
                    className="input-field font-mono uppercase"
                    placeholder="LIFNR"
                    {...register('srcFieldName', { required: 'Source field name is required.' })}
                  />
                  {errors.srcFieldName && <p className="error-text">{errors.srcFieldName.message}</p>}
                </div>
                <div className="col-span-2">
                  <label className="label-field" htmlFor="edit-srcFieldDescription">Field Description</label>
                  <input id="edit-srcFieldDescription" className="input-field" placeholder="Vendor Account Number" {...register('srcFieldDescription')} />
                </div>
                {/* Combined Data Type / Length / Decimal for Source */}
                <div className="col-span-2 md:col-span-4">
                  <label className="label-field">Data Type / Length / Decimal</label>
                  <div className="flex items-center gap-2">
                    <select id="edit-srcDataType" className="select-field flex-1" {...register('srcDataType')} aria-label="Source data type">
                      {DATA_TYPES.map((dt) => (
                        <option key={`edit-src-dt-${dt}`} value={dt}>{dt}</option>
                      ))}
                    </select>
                    <span className="text-muted-foreground font-medium">/</span>
                    <input id="edit-srcLength" className="input-field font-tabular w-24" placeholder="Length" {...register('srcLength')} aria-label="Source length" />
                    <span className="text-muted-foreground font-medium">/</span>
                    <input id="edit-srcDecimal" className="input-field font-tabular w-24" placeholder="Decimal" {...register('srcDecimal')} aria-label="Source decimal" />
                  </div>
                </div>
              </div>
            </div>

            {/* Divider */}
            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-border" />
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-2">Target (SAP S/4HANA)</span>
              <div className="flex-1 h-px bg-border" />
            </div>

            {/* Target section */}
            <div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="col-span-2">
                  <label className="label-field" htmlFor="edit-targetViewName">Target View Name</label>
                  <input id="edit-targetViewName" className="input-field font-mono" placeholder="I_BUPA_HEADER" {...register('targetViewName')} />
                </div>
                <div className="col-span-2">
                  <label className="label-field" htmlFor="edit-targetFieldName">
                    Target Field Name <span className="text-danger">*</span>
                  </label>
                  <input
                    id="edit-targetFieldName"
                    className="input-field font-mono uppercase"
                    placeholder="PARTNER"
                    {...register('targetFieldName', { required: 'Target field name is required.' })}
                  />
                  {errors.targetFieldName && <p className="error-text">{errors.targetFieldName.message}</p>}
                </div>
                <div className="col-span-2 md:col-span-4">
                  <label className="label-field" htmlFor="edit-targetFieldDescription">Target Field Description</label>
                  <input id="edit-targetFieldDescription" className="input-field" placeholder="Business Partner Number" {...register('targetFieldDescription')} />
                </div>
                {/* Combined Data Type / Length / Decimal for Target */}
                <div className="col-span-2 md:col-span-4">
                  <label className="label-field">Data Type / Length / Decimal</label>
                  <div className="flex items-center gap-2">
                    <select id="edit-targetFieldDataType" className="select-field flex-1" {...register('targetFieldDataType')} aria-label="Target data type">
                      {DATA_TYPES.map((dt) => (
                        <option key={`edit-tgt-dt-${dt}`} value={dt}>{dt}</option>
                      ))}
                    </select>
                    <span className="text-muted-foreground font-medium">/</span>
                    <input id="edit-targetFieldLength" className="input-field font-tabular w-24" placeholder="Length" {...register('targetFieldLength')} aria-label="Target length" />
                    <span className="text-muted-foreground font-medium">/</span>
                    <input id="edit-targetFieldDecimal" className="input-field font-tabular w-24" placeholder="Decimal" {...register('targetFieldDecimal')} aria-label="Target decimal" />
                  </div>
                </div>
                <div>
                  <label className="label-field" htmlFor="edit-targetHanaTable">HANA Table</label>
                  <input id="edit-targetHanaTable" className="input-field font-mono" placeholder="BUT000" {...register('targetHanaTable')} />
                </div>
                <div>
                  <label className="label-field" htmlFor="edit-checkTable">Check Table</label>
                  <input id="edit-checkTable" className="input-field font-mono" placeholder="T005" {...register('checkTable')} />
                </div>
                <div>
                  <label className="label-field" htmlFor="edit-mandatory">
                    Mandatory
                  </label>
                  <p className="helper-text mb-1">Is this field required in the target?</p>
                  <select id="edit-mandatory" className="select-field" {...register('mandatory')}>
                    <option value="Yes">Yes — Mandatory</option>
                    <option value="No">No — Optional</option>
                  </select>
                </div>
                <div>
                  <label className="label-field" htmlFor="edit-migrationRequired">
                    Migration Required
                  </label>
                  <p className="helper-text mb-1">Should this field be populated during migration?</p>
                  <select id="edit-migrationRequired" className="select-field" {...register('migrationRequired')}>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                  </select>
                </div>
                <div>
                  <label className="label-field" htmlFor="edit-transformationType">Transformation Type</label>
                  <select id="edit-transformationType" className="select-field" {...register('transformationType')}>
                    {TRANS_TYPES.map((t) => (
                      <option key={`edit-trans-${t}`} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="mt-4 space-y-4">
                <div>
                  <label className="label-field" htmlFor="edit-transformationRule">
                    Transformation Rule
                  </label>
                  <p className="helper-text mb-1">
                    Describe how the source value is converted to the target format. Be specific about format conversions, lookups, and defaults.
                  </p>
                  <textarea
                    id="edit-transformationRule"
                    className="input-field min-h-[80px] resize-y text-xs leading-relaxed"
                    placeholder="e.g. Map source field directly to target field. Trim trailing spaces."
                    {...register('transformationRule')}
                  />
                </div>
                <div>
                  <label className="label-field" htmlFor="edit-validationRule">
                    Validation Rule
                  </label>
                  <p className="helper-text mb-1">
                    Define how the migrated value should be validated before loading into SAP S/4HANA.
                  </p>
                  <textarea
                    id="edit-validationRule"
                    className="input-field min-h-[80px] resize-y text-xs leading-relaxed"
                    placeholder="e.g. Check length does not exceed target field length. Validate against check table."
                    {...register('validationRule')}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Modal footer */}
          <div className="px-6 py-4 border-t border-border flex items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <AlertTriangle size={12} className="text-warning" />
              <span>Changes are saved to the current session only. Re-export to update the Excel file.</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="btn-secondary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-primary"
                disabled={isSubmitting}
                style={{ minWidth: 120 }}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 size={14} className="animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save size={14} />
                    Save Changes
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}