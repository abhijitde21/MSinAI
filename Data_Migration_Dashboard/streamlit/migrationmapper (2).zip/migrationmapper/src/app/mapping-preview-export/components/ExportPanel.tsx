'use client';

import React, { useState } from 'react';
import type { MappingSession } from '@/lib/mappingStore';
import { exportMappingToExcel } from '@/lib/excelExporter';
import {
  Download,
  FileSpreadsheet,
  Loader2,
  CheckCircle2,
  Info,
} from 'lucide-react';

interface Props {
  session: MappingSession;
}

export default function ExportPanel({ session }: Props) {
  const [exporting, setExporting] = useState(false);
  const [exported, setExported] = useState(false);
  const [exportError, setExportError] = useState('');

  const handleExport = async () => {
    setExporting(true);
    setExportError('');
    setExported(false);
    try {
      await exportMappingToExcel(session);
      setExported(true);
      setTimeout(() => setExported(false), 4000);
    } catch (err: unknown) {
      setExportError(
        err instanceof Error ? err.message : 'Export failed. Please try again.'
      );
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="card-panel p-5 flex items-start justify-between gap-5 flex-wrap">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center flex-shrink-0">
          <FileSpreadsheet size={18} className="text-white" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-foreground mb-0.5">Export Branded Mapping Sheet</h3>
          <p className="text-xs text-muted-foreground max-w-lg">
            Downloads a formatted Excel workbook (.xlsx) with a Project Details cover sheet and the full field mapping table. Client and partner logos are embedded in the file header.
          </p>
          {exportError && (
            <p className="text-xs text-danger mt-1 flex items-center gap-1">
              <Info size={12} />
              {exportError}
            </p>
          )}
          {exported && (
            <p className="text-xs text-success mt-1 flex items-center gap-1 animate-fadeIn">
              <CheckCircle2 size={12} />
              Excel file downloaded successfully.
            </p>
          )}
        </div>
      </div>

      <div className="flex items-center gap-3 flex-shrink-0">
        <div className="text-right hidden md:block">
          <p className="text-xs font-medium text-foreground">{session.projectDetails.objectName}</p>
          <p className="text-xs text-muted-foreground">{session.mappings.length} fields · {session.xmlFileName}</p>
        </div>
        <button
          onClick={handleExport}
          disabled={exporting}
          className="btn-primary"
          style={{ minWidth: 180 }}
        >
          {exporting ? (
            <>
              <Loader2 size={15} className="animate-spin" />
              <span>Generating Excel...</span>
            </>
          ) : exported ? (
            <>
              <CheckCircle2 size={15} />
              <span>Downloaded</span>
            </>
          ) : (
            <>
              <Download size={15} />
              <span>Download Excel (.xlsx)</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}