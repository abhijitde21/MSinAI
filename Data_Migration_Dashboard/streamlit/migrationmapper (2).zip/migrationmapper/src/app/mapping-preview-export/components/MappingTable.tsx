'use client';

import React, { useState, useMemo } from 'react';
import type { FieldMapping } from '@/lib/mappingStore';
import { updateMappingRow } from '@/lib/mappingStore';
import MappingEditModal from './MappingEditModal';
import {
  Search,
  Edit3,
  Filter,
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  AlertTriangle,
  Plus,
  Trash2,
} from 'lucide-react';

interface Props {
  mappings: FieldMapping[];
  onUpdate: (updated: FieldMapping[]) => void;
}

type SortKey = 'seq' | 'source.fieldName' | 'target.targetFieldName' | 'target.mandatory' | 'target.migrationRequired' | 'target.transformationType';
type SortDir = 'asc' | 'desc';

const TRANSFORMATION_BADGE: Record<string, string> = {
  Direct: 'badge-direct',
  Lookup: 'badge-lookup',
  Concatenation: 'badge-concat',
  Default: 'badge-default',
  Conditional: 'badge-conditional',
  Derivation: 'badge-lookup',
  None: 'badge-optional',
};

function createEmptyRow(seq: number): FieldMapping {
  return {
    id: `mapping-manual-${Date.now()}-${seq}`,
    seq,
    source: {
      id: `src-manual-${Date.now()}-${seq}`,
      tableName: '',
      tableDescription: '',
      fieldName: '',
      fieldDescription: '',
      dataType: 'CHAR',
      length: '0',
      decimal: '0',
    },
    target: {
      targetViewName: '',
      targetFieldName: '',
      targetFieldDescription: '',
      targetFieldDataType: 'CHAR',
      targetFieldLength: '0',
      targetFieldDecimal: '0',
      targetHanaTable: '',
      checkTable: '',
      mandatory: 'No',
      migrationRequired: 'Yes',
      transformationType: 'Direct',
      transformationRule: '',
      validationRule: '',
    },
  };
}

export default function MappingTable({ mappings, onUpdate }: Props) {
  const [search, setSearch] = useState('');
  const [filterMandatory, setFilterMandatory] = useState<'all' | 'Yes' | 'No'>('all');
  const [filterMigration, setFilterMigration] = useState<'all' | 'Yes' | 'No'>('all');
  const [filterTransType, setFilterTransType] = useState<string>('all');
  const [sortKey, setSortKey] = useState<SortKey>('seq');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [editRow, setEditRow] = useState<FieldMapping | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const transTypes = useMemo(() => {
    const set = new Set(mappings.map((m) => m.target.transformationType));
    return Array.from(set).sort();
  }, [mappings]);

  const filtered = useMemo(() => {
    let rows = mappings;
    if (search.trim()) {
      const q = search.toLowerCase();
      rows = rows.filter(
        (m) =>
          m.source.fieldName.toLowerCase().includes(q) ||
          m.source.fieldDescription.toLowerCase().includes(q) ||
          m.target.targetFieldName.toLowerCase().includes(q) ||
          m.target.targetFieldDescription.toLowerCase().includes(q) ||
          m.target.targetViewName.toLowerCase().includes(q) ||
          m.source.tableName.toLowerCase().includes(q)
      );
    }
    if (filterMandatory !== 'all') rows = rows.filter((m) => m.target.mandatory === filterMandatory);
    if (filterMigration !== 'all') rows = rows.filter((m) => m.target.migrationRequired === filterMigration);
    if (filterTransType !== 'all') rows = rows.filter((m) => m.target.transformationType === filterTransType);
    return rows;
  }, [mappings, search, filterMandatory, filterMigration, filterTransType]);

  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      let av: string | number = '';
      let bv: string | number = '';
      if (sortKey === 'seq') { av = a.seq; bv = b.seq; }
      else if (sortKey === 'source.fieldName') { av = a.source.fieldName; bv = b.source.fieldName; }
      else if (sortKey === 'target.targetFieldName') { av = a.target.targetFieldName; bv = b.target.targetFieldName; }
      else if (sortKey === 'target.mandatory') { av = a.target.mandatory; bv = b.target.mandatory; }
      else if (sortKey === 'target.migrationRequired') { av = a.target.migrationRequired; bv = b.target.migrationRequired; }
      else if (sortKey === 'target.transformationType') { av = a.target.transformationType; bv = b.target.transformationType; }

      if (av < bv) return sortDir === 'asc' ? -1 : 1;
      if (av > bv) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filtered, sortKey, sortDir]);

  const totalPages = Math.ceil(sorted.length / pageSize);
  const paginated = sorted.slice((page - 1) * pageSize, page * pageSize);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
    setPage(1);
  };

  const SortIcon = ({ col }: { col: SortKey }) => {
    if (sortKey !== col) return <ChevronsUpDown size={12} className="text-muted-foreground" />;
    return sortDir === 'asc' ? (
      <ChevronUp size={12} className="text-primary" />
    ) : (
      <ChevronDown size={12} className="text-primary" />
    );
  };

  const handleEditSave = (updated: FieldMapping) => {
    updateMappingRow(updated.id, updated);
    onUpdate(mappings.map((m) => (m.id === updated.id ? updated : m)));
    setEditRow(null);
  };

  const handleAddRow = () => {
    const newRow = createEmptyRow(mappings.length + 1);
    const updated = [...mappings, newRow];
    onUpdate(updated);
    // Open edit modal for the new row immediately
    setEditRow(newRow);
    // Go to last page
    const newTotal = Math.ceil((filtered.length + 1) / pageSize);
    setPage(newTotal || 1);
  };

  const handleDeleteRow = (id: string) => {
    const updated = mappings
      .filter((m) => m.id !== id)
      .map((m, i) => ({ ...m, seq: i + 1 }));
    onUpdate(updated);
    setDeleteConfirm(null);
  };

  return (
    <>
      <div className="card-panel">
        {/* Table toolbar */}
        <div className="px-5 py-4 border-b border-border flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              className="input-field pl-8 py-1.5 text-xs"
              placeholder="Search fields, tables, descriptions..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              aria-label="Search mapping fields"
            />
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <Filter size={13} className="text-muted-foreground flex-shrink-0" />

            <select
              className="select-field py-1.5 text-xs w-auto pr-6"
              value={filterMandatory}
              onChange={(e) => { setFilterMandatory(e.target.value as 'all' | 'Yes' | 'No'); setPage(1); }}
              aria-label="Filter by mandatory"
            >
              <option value="all">All Mandatory</option>
              <option value="Yes">Mandatory: Yes</option>
              <option value="No">Mandatory: No</option>
            </select>

            <select
              className="select-field py-1.5 text-xs w-auto pr-6"
              value={filterMigration}
              onChange={(e) => { setFilterMigration(e.target.value as 'all' | 'Yes' | 'No'); setPage(1); }}
              aria-label="Filter by migration required"
            >
              <option value="all">All Migration</option>
              <option value="Yes">Migration: Yes</option>
              <option value="No">Migration: No</option>
            </select>

            <select
              className="select-field py-1.5 text-xs w-auto pr-6"
              value={filterTransType}
              onChange={(e) => { setFilterTransType(e.target.value); setPage(1); }}
              aria-label="Filter by transformation type"
            >
              <option value="all">All Types</option>
              {transTypes.map((t) => (
                <option key={`trans-filter-${t}`} value={t}>{t}</option>
              ))}
            </select>
          </div>

          <div className="ml-auto flex items-center gap-3">
            <span className="text-xs text-muted-foreground">
              {filtered.length} of {mappings.length} fields
            </span>
            <button
              onClick={handleAddRow}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-primary/10 text-primary hover:bg-primary hover:text-white transition-colors"
            >
              <Plus size={13} />
              Add Row
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-secondary border-b border-border">
                {/* Seq */}
                <th
                  className="text-left px-3 py-3 font-semibold text-muted-foreground cursor-pointer hover:text-foreground select-none w-12 sticky left-0 bg-secondary z-10"
                  onClick={() => handleSort('seq')}
                >
                  <div className="flex items-center gap-1">#<SortIcon col="seq" /></div>
                </th>
                {/* Source */}
                <th className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[110px] whitespace-nowrap">Src Table</th>
                <th
                  className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[120px] cursor-pointer hover:text-foreground select-none whitespace-nowrap"
                  onClick={() => handleSort('source.fieldName')}
                >
                  <div className="flex items-center gap-1">Src Field<SortIcon col="source.fieldName" /></div>
                </th>
                <th className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[160px] whitespace-nowrap">Src Description</th>
                <th className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[140px] whitespace-nowrap">
                  Src Type/Len/Dec
                </th>
                {/* Divider */}
                <th className="px-1 py-3 bg-blue-50 w-2" />
                {/* Target */}
                <th className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[130px] bg-blue-50/40 whitespace-nowrap">Target View</th>
                <th
                  className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[130px] bg-blue-50/40 cursor-pointer hover:text-foreground select-none whitespace-nowrap"
                  onClick={() => handleSort('target.targetFieldName')}
                >
                  <div className="flex items-center gap-1">Target Field<SortIcon col="target.targetFieldName" /></div>
                </th>
                <th className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[170px] bg-blue-50/40 whitespace-nowrap">Target Description</th>
                <th className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[140px] bg-blue-50/40 whitespace-nowrap">
                  Tgt Type/Len/Dec
                </th>
                <th className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[110px] bg-blue-50/40 whitespace-nowrap">HANA Table</th>
                <th className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[90px] bg-blue-50/40 whitespace-nowrap">Check Table</th>
                {/* Flags */}
                <th
                  className="text-left px-3 py-3 font-semibold text-muted-foreground w-24 cursor-pointer hover:text-foreground select-none whitespace-nowrap"
                  onClick={() => handleSort('target.mandatory')}
                >
                  <div className="flex items-center gap-1">Mandatory<SortIcon col="target.mandatory" /></div>
                </th>
                <th
                  className="text-left px-3 py-3 font-semibold text-muted-foreground w-28 cursor-pointer hover:text-foreground select-none whitespace-nowrap"
                  onClick={() => handleSort('target.migrationRequired')}
                >
                  <div className="flex items-center gap-1">Mig. Req.<SortIcon col="target.migrationRequired" /></div>
                </th>
                {/* Rules */}
                <th
                  className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[110px] cursor-pointer hover:text-foreground select-none whitespace-nowrap"
                  onClick={() => handleSort('target.transformationType')}
                >
                  <div className="flex items-center gap-1">Trans. Type<SortIcon col="target.transformationType" /></div>
                </th>
                <th className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[200px] whitespace-nowrap">Transformation Rule</th>
                <th className="text-left px-3 py-3 font-semibold text-muted-foreground min-w-[200px] whitespace-nowrap">Validation Rule</th>
                {/* Actions */}
                <th className="px-3 py-3 w-20 text-right font-semibold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {paginated.length === 0 && (
                <tr>
                  <td colSpan={19} className="px-4 py-12 text-center text-muted-foreground">
                    No fields match the current filters.
                  </td>
                </tr>
              )}
              {paginated.map((row) => (
                <tr
                  key={row.id}
                  className={`hover:bg-muted/50 transition-colors group ${
                    row.target.mandatory === 'Yes' ? 'field-highlight-mandatory' : ''
                  }`}
                >
                  {/* Seq */}
                  <td className="px-3 py-2.5 font-tabular text-muted-foreground sticky left-0 bg-card group-hover:bg-muted/50 z-10">
                    {row.seq}
                  </td>
                  {/* Source */}
                  <td className="px-3 py-2.5 font-mono text-foreground table-cell-truncate" title={row.source.tableName}>
                    {row.source.tableName || '—'}
                  </td>
                  <td className="px-3 py-2.5 font-mono font-semibold text-foreground whitespace-nowrap">
                    {row.source.fieldName || <span className="text-muted-foreground italic">—</span>}
                  </td>
                  <td className="px-3 py-2.5 text-foreground table-cell-truncate" title={row.source.fieldDescription}>
                    {row.source.fieldDescription}
                  </td>
                  <td className="px-3 py-2.5 font-mono text-muted-foreground whitespace-nowrap">
                    <span className="inline-flex items-center gap-1">
                      <span className="font-semibold text-foreground">{row.source.dataType}</span>
                      <span className="text-muted-foreground/50">/</span>
                      <span>{row.source.length}</span>
                      <span className="text-muted-foreground/50">/</span>
                      <span>{row.source.decimal}</span>
                    </span>
                  </td>
                  {/* Divider */}
                  <td className="bg-blue-100/60 w-1 p-0" />
                  {/* Target */}
                  <td className="px-3 py-2.5 font-mono text-blue-700 table-cell-truncate bg-blue-50/20" title={row.target.targetViewName}>
                    {row.target.targetViewName}
                  </td>
                  <td className="px-3 py-2.5 font-mono font-semibold text-blue-800 whitespace-nowrap bg-blue-50/20">
                    {row.target.targetFieldName || <span className="text-muted-foreground italic">—</span>}
                  </td>
                  <td className="px-3 py-2.5 text-foreground table-cell-truncate bg-blue-50/20" title={row.target.targetFieldDescription}>
                    {row.target.targetFieldDescription}
                  </td>
                  <td className="px-3 py-2.5 font-mono text-muted-foreground whitespace-nowrap bg-blue-50/20">
                    <span className="inline-flex items-center gap-1">
                      <span className="font-semibold text-blue-700">{row.target.targetFieldDataType}</span>
                      <span className="text-muted-foreground/50">/</span>
                      <span>{row.target.targetFieldLength}</span>
                      <span className="text-muted-foreground/50">/</span>
                      <span>{row.target.targetFieldDecimal}</span>
                    </span>
                  </td>
                  <td className="px-3 py-2.5 font-mono text-muted-foreground table-cell-truncate bg-blue-50/20" title={row.target.targetHanaTable}>
                    {row.target.targetHanaTable || '—'}
                  </td>
                  <td className="px-3 py-2.5 font-mono text-muted-foreground bg-blue-50/20 whitespace-nowrap">
                    {row.target.checkTable || '—'}
                  </td>
                  {/* Flags */}
                  <td className="px-3 py-2.5 whitespace-nowrap">
                    {row.target.mandatory === 'Yes' ? (
                      <span className="badge-mandatory flex items-center gap-1 w-fit">
                        <AlertTriangle size={9} />
                        Yes
                      </span>
                    ) : (
                      <span className="badge-optional w-fit">No</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5 whitespace-nowrap">
                    {row.target.migrationRequired === 'Yes' ? (
                      <span className="badge-yes w-fit">Yes</span>
                    ) : (
                      <span className="badge-no w-fit">No</span>
                    )}
                  </td>
                  {/* Rules */}
                  <td className="px-3 py-2.5 whitespace-nowrap">
                    <span className={`${TRANSFORMATION_BADGE[row.target.transformationType] || 'badge-optional'} w-fit`}>
                      {row.target.transformationType}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-muted-foreground" style={{ maxWidth: 220 }}>
                    <span className="block overflow-hidden text-ellipsis whitespace-nowrap" title={row.target.transformationRule}>
                      {row.target.transformationRule || <span className="text-red-400 italic">— not set —</span>}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-muted-foreground" style={{ maxWidth: 220 }}>
                    <span className="block overflow-hidden text-ellipsis whitespace-nowrap" title={row.target.validationRule}>
                      {row.target.validationRule || <span className="text-amber-400 italic">— not set —</span>}
                    </span>
                  </td>
                  {/* Actions */}
                  <td className="px-3 py-2.5 text-right">
                    <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => setEditRow(row)}
                        className="p-1.5 rounded-md hover:bg-primary/10 hover:text-primary text-muted-foreground transition-all duration-150"
                        aria-label={`Edit mapping for ${row.target.targetFieldName}`}
                        title="Edit row"
                      >
                        <Edit3 size={13} />
                      </button>
                      <button
                        onClick={() => setDeleteConfirm(row.id)}
                        className="p-1.5 rounded-md hover:bg-danger/10 hover:text-danger text-muted-foreground transition-all duration-150"
                        aria-label={`Delete mapping row ${row.seq}`}
                        title="Delete row"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="px-5 py-3 border-t border-border flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>Rows per page:</span>
            <select
              className="select-field py-1 text-xs w-auto"
              value={pageSize}
              onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
              aria-label="Rows per page"
            >
              {[10, 15, 25, 50].map((n) => (
                <option key={`ps-${n}`} value={n}>{n}</option>
              ))}
            </select>
            <span className="ml-2">
              {sorted.length === 0 ? '0' : (page - 1) * pageSize + 1}–{Math.min(page * pageSize, sorted.length)} of {sorted.length}
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage(1)}
              disabled={page === 1}
              className="px-2 py-1 rounded text-xs font-medium text-muted-foreground hover:bg-secondary disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              aria-label="First page"
            >
              «
            </button>
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="px-2.5 py-1 rounded text-xs font-medium text-muted-foreground hover:bg-secondary disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              aria-label="Previous page"
            >
              ‹
            </button>

            {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
              let pageNum: number;
              if (totalPages <= 7) {
                pageNum = i + 1;
              } else if (page <= 4) {
                pageNum = i + 1;
              } else if (page >= totalPages - 3) {
                pageNum = totalPages - 6 + i;
              } else {
                pageNum = page - 3 + i;
              }
              return (
                <button
                  key={`page-${pageNum}`}
                  onClick={() => setPage(pageNum)}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                    page === pageNum
                      ? 'bg-primary text-white' :'text-muted-foreground hover:bg-secondary'
                  }`}
                  aria-label={`Page ${pageNum}`}
                  aria-current={page === pageNum ? 'page' : undefined}
                >
                  {pageNum}
                </button>
              );
            })}

            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages || totalPages === 0}
              className="px-2.5 py-1 rounded text-xs font-medium text-muted-foreground hover:bg-secondary disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              aria-label="Next page"
            >
              ›
            </button>
            <button
              onClick={() => setPage(totalPages)}
              disabled={page === totalPages || totalPages === 0}
              className="px-2 py-1 rounded text-xs font-medium text-muted-foreground hover:bg-secondary disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              aria-label="Last page"
            >
              »
            </button>
          </div>
        </div>
      </div>

      {/* Edit Modal */}
      {editRow && (
        <MappingEditModal
          row={editRow}
          onSave={handleEditSave}
          onClose={() => setEditRow(null)}
        />
      )}

      {/* Delete confirm modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="card-panel p-6 max-w-sm w-full animate-fadeScale">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-danger/10 flex items-center justify-center flex-shrink-0">
                <AlertTriangle size={18} className="text-danger" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">Delete Row?</p>
                <p className="text-xs text-muted-foreground mt-0.5">This mapping row will be permanently removed.</p>
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setDeleteConfirm(null)} className="btn-secondary text-sm">Cancel</button>
              <button
                onClick={() => handleDeleteRow(deleteConfirm)}
                className="px-4 py-2 rounded-lg text-sm font-medium bg-danger text-white hover:bg-danger/90 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}