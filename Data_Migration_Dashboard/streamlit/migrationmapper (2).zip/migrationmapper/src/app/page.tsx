import React from 'react';
import AppLayout from '@/components/AppLayout';
import MappingGeneratorContent from './components/MappingGeneratorContent';

export default function MappingGeneratorPage() {
  return (
    <AppLayout>
      <MappingGeneratorContent />
    </AppLayout>
  );
}