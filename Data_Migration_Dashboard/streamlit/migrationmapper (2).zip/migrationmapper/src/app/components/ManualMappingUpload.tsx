'use client';

import React, { useState, useRef, useCallback } from 'react';
import {
  Download,
  Upload,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  ArrowRight,
  X,
  Info,
} from 'lucide-react';
import type { FieldMapping } from '@/lib/mappingStore';

// ── Types ──────────────────────────────────────────────────────────────────────

export interface ManualMappingRow {
  seq: number;
  // Source
  sourceTable: string;
  sourceTableDesc: string;
  sourceField: string;
  sourceFieldDesc: string;
  sourceDataType: string;
  sourceLength: string;
  sourceDecimal: string;
  // Target
  targetView: string;
  targetHanaTable: string;
  targetField: string;
  targetFieldDesc: string;
  targetDataType: string;
  targetLength: string;
  targetDecimal: string;
  checkTable: string;
  mandatory: 'Yes' | 'No';
  migrationRequired: 'Yes' | 'No';
  transformationType: FieldMapping['target']['transformationType'];
  transformationRule: string;
  validationRule: string;
}

interface ManualMappingUploadProps {
  onComplete: (rows: ManualMappingRow[]) => void;
  onBack?: () => void;
}

// ── CSV Template Columns ───────────────────────────────────────────────────────

const TEMPLATE_COLUMNS = [
  'Seq',
  'Source Table',
  'Source Table Description',
  'Source Field',
  'Source Field Description',
  'Source Data Type',
  'Source Length',
  'Source Decimal',
  'Target View',
  'Target HANA Table',
  'Target Field',
  'Target Field Description',
  'Target Data Type',
  'Target Length',
  'Target Decimal',
  'Check Table',
  'Mandatory (Yes/No)',
  'Migration Required (Yes/No)',
  'Transformation Type (Direct/Lookup/Concatenation/Default/Conditional/Derivation/None)',
  'Transformation Rule',
  'Validation Rule',
];

const SAMPLE_ROW = [
  '1',
  'KNA1',
  'Customer Master General Data',
  'KUNNR',
  'Customer Account Number',
  'CHAR',
  '10',
  '0',
  'I_BUSINESSPARTNER',
  'BUT000',
  'PARTNER',
  'Business Partner Number',
  'CHAR',
  '10',
  '0',
  'BUT000',
  'Yes',
  'Yes',
  'Direct',
  'Map KNA1-KUNNR directly to PARTNER field',
  'Must not be blank. Must exist in BUT000.',
];

// ── Helpers ────────────────────────────────────────────────────────────────────

function downloadCsvTemplate() {
  const rows = [TEMPLATE_COLUMNS, SAMPLE_ROW];
  const csv = rows
    .map((row) =>
      row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(',')
    )
    .join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'mapping_template.csv';
  a.click();
  URL.revokeObjectURL(url);
}

function parseCsvLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  result.push(current.trim());
  return result;
}

function parseCsvToRows(csv: string): ManualMappingRow[] {
  const lines = csv.split(/\r?\n/).filter((l) => l.trim());
  if (lines.length < 2) return [];
  // Skip header row
  const dataLines = lines.slice(1);
  const rows: ManualMappingRow[] = [];

  for (const line of dataLines) {
    if (!line.trim()) continue;
    const cells = parseCsvLine(line);
    if (cells.length < 20) continue;

    const transformationType = cells[18] as FieldMapping['target']['transformationType'];
    const validTypes: FieldMapping['target']['transformationType'][] = [
      'Direct', 'Lookup', 'Concatenation', 'Default', 'Conditional', 'Derivation', 'None',
    ];

    rows.push({
      seq: parseInt(cells[0]) || rows.length + 1,
      sourceTable: cells[1] || '',
      sourceTableDesc: cells[2] || '',
      sourceField: cells[3] || '',
      sourceFieldDesc: cells[4] || '',
      sourceDataType: cells[5] || 'CHAR',
      sourceLength: cells[6] || '0',
      sourceDecimal: cells[7] || '0',
      targetView: cells[8] || '',
      targetHanaTable: cells[9] || '',
      targetField: cells[10] || '',
      targetFieldDesc: cells[11] || '',
      targetDataType: cells[12] || 'CHAR',
      targetLength: cells[13] || '0',
      targetDecimal: cells[14] || '0',
      checkTable: cells[15] || '',
      mandatory: cells[16]?.toLowerCase() === 'yes' ? 'Yes' : 'No',
      migrationRequired: cells[17]?.toLowerCase() === 'yes' ? 'Yes' : 'No',
      transformationType: validTypes.includes(transformationType) ? transformationType : 'Direct',
      transformationRule: cells[19] || '',
      validationRule: cells[20] || '',
    });
  }

  return rows;
}

function emptyRow(seq: number): ManualMappingRow {
  return {
    seq,
    sourceTable: '',
    sourceTableDesc: '',
    sourceField: '',
    sourceFieldDesc: '',
    sourceDataType: 'CHAR',
    sourceLength: '0',
    sourceDecimal: '0',
    targetView: '',
    targetHanaTable: '',
    targetField: '',
    targetFieldDesc: '',
    targetDataType: 'CHAR',
    targetLength: '0',
    targetDecimal: '0',
    checkTable: '',
    mandatory: 'No',
    migrationRequired: 'Yes',
    transformationType: 'Direct',
    transformationRule: '',
    validationRule: '',
  };
}

// ── Component ──────────────────────────────────────────────────────────────────

export default function ManualMappingUpload({ onComplete, onBack }: ManualMappingUploadProps) {
  const [rows, setRows] = useState<ManualMappingRow[]>([emptyRow(1)]);
  const [uploadError, setUploadError] = useState<string>('');
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // ── File Upload ──────────────────────────────────────────────────────────────

  const processFile = useCallback((file: File) => {
    if (!file.name.endsWith('.csv')) {
      setUploadError('Only CSV files are supported. Please download the template, fill it, and upload as CSV.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const parsed = parseCsvToRows(content);
      if (parsed.length === 0) {
        setUploadError('No valid data rows found. Make sure the CSV follows the template format.');
        return;
      }
      setRows(parsed);
      setUploadedFileName(file.name);
      setUploadError('');
    };
    reader.readAsText(file);
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
    e.target.value = '';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  };

  // ── Row Editing ──────────────────────────────────────────────────────────────

  const updateRow = (idx: number, field: keyof ManualMappingRow, value: string) => {
    setRows((prev) =>
      prev.map((r, i) => (i === idx ? { ...r, [field]: value } : r))
    );
  };

  const addRow = () => {
    setRows((prev) => [...prev, emptyRow(prev.length + 1)]);
  };

  const removeRow = (idx: number) => {
    setRows((prev) => {
      const updated = prev.filter((_, i) => i !== idx);
      return updated.map((r, i) => ({ ...r, seq: i + 1 }));
    });
  };

  const clearAll = () => {
    setRows([emptyRow(1)]);
    setUploadedFileName('');
    setUploadError('');
  };

  // ── Submit ───────────────────────────────────────────────────────────────────

  const handleSubmit = () => {
    const validRows = rows.filter(
      (r) => r.sourceField.trim() && r.targetField.trim()
    );
    if (validRows.length === 0) {
      setUploadError('Please add at least one row with Source Field and Target Field filled in.');
      return;
    }
    onComplete(validRows);
  };

  const TRANSFORMATION_TYPES: FieldMapping['target']['transformationType'][] = [
    'Direct', 'Lookup', 'Concatenation', 'Default', 'Conditional', 'Derivation', 'None',
  ];

  const DATA_TYPES = ['CHAR', 'NUMC', 'DATS', 'TIMS', 'CURR', 'CUKY', 'QUAN', 'UNIT', 'LANG', 'CLNT', 'INT4', 'DEC', 'FLTP'];

  return (
    <div className="space-y-5">
      {/* Info Banner */}
      <div className="flex items-start gap-3 p-4 rounded-xl border border-blue-200 bg-blue-50">
        <Info size={15} className="text-blue-500 flex-shrink-0 mt-0.5" />
        <div className="text-xs text-blue-700 space-y-1">
          <p className="font-semibold">Manual Mapping — Bulk Template Approach</p>
          <p>
            Download the CSV template, fill in all mapping details offline, then upload the completed file to load all rows at once.
            You can also add or edit rows directly in the table below.
          </p>
        </div>
      </div>

      {/* Template Download + Upload */}
      <div className="card-panel p-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          {/* Download */}
          <div className="flex-1">
            <p className="text-sm font-semibold text-foreground mb-0.5">Step 1 — Download Template</p>
            <p className="text-xs text-muted-foreground">Get the pre-structured CSV template with all required columns and a sample row.</p>
            <button
              onClick={downloadCsvTemplate}
              className="mt-2 inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
            >
              <Download size={13} />
              Download Template (CSV)
            </button>
          </div>

          <div className="hidden sm:block w-px h-16 bg-border" />

          {/* Upload */}
          <div className="flex-1">
            <p className="text-sm font-semibold text-foreground mb-0.5">Step 2 — Upload Filled Template</p>
            <p className="text-xs text-muted-foreground">Upload your completed CSV to load all mapping rows at once.</p>

            {uploadedFileName ? (
              <div className="mt-2 flex items-center gap-2">
                <span className="flex items-center gap-1.5 text-xs font-medium text-success bg-success-bg px-2.5 py-1 rounded-full">
                  <CheckCircle2 size={11} />
                  {uploadedFileName}
                </span>
                <button
                  onClick={clearAll}
                  className="p-1 rounded-md text-muted-foreground hover:text-danger hover:bg-danger/10 transition-colors"
                  title="Clear uploaded data"
                >
                  <X size={13} />
                </button>
              </div>
            ) : (
              <label className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-card border border-border text-foreground hover:bg-secondary cursor-pointer transition-colors">
                <Upload size={12} />
                Upload CSV
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </label>
            )}
          </div>
        </div>

        {/* Drag & Drop Zone */}
        {!uploadedFileName && (
          <div
            className={`mt-4 border-2 border-dashed rounded-xl p-6 text-center transition-colors ${
              isDragging ? 'border-primary bg-primary/5' : 'border-border bg-secondary/20'
            }`}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
          >
            <FileSpreadsheet size={24} className="mx-auto text-muted-foreground mb-2" />
            <p className="text-xs text-muted-foreground">
              Drag & drop your filled CSV template here, or{' '}
              <button
                className="text-primary underline"
                onClick={() => fileInputRef.current?.click()}
              >
                browse
              </button>
            </p>
          </div>
        )}

        {uploadError && (
          <div className="mt-3 flex items-start gap-2 p-3 rounded-lg border border-red-200 bg-danger-bg">
            <AlertCircle size={14} className="text-danger flex-shrink-0 mt-0.5" />
            <p className="text-xs text-danger">{uploadError}</p>
          </div>
        )}
      </div>

      {/* Mapping Table */}
      <div className="card-panel p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm font-semibold text-foreground">Step 3 — Review & Edit Rows</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              {rows.length} row{rows.length !== 1 ? 's' : ''} — edit inline or add new rows manually.
            </p>
          </div>
          <button
            onClick={addRow}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-secondary border border-border text-foreground hover:bg-secondary/80 transition-colors"
          >
            <Plus size={13} />
            Add Row
          </button>
        </div>

        <div className="overflow-x-auto rounded-lg border border-border">
          <table className="w-full text-xs min-w-[1400px]">
            <thead>
              <tr className="bg-secondary/60 border-b border-border">
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground w-8">#</th>
                {/* Source */}
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Src Table</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Src Table Desc</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Src Field <span className="text-danger">*</span></th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Src Field Desc</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Src Type</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Src Len</th>
                {/* Target */}
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Tgt View</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Tgt HANA Table</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Tgt Field <span className="text-danger">*</span></th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Tgt Field Desc</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Tgt Type</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Tgt Len</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Check Tbl</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Mand.</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Mig. Req.</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Transform Type</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Transform Rule</th>
                <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Validation Rule</th>
                <th className="px-2 py-2 text-center font-semibold text-muted-foreground">Del</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, idx) => (
                <tr key={idx} className="border-b border-border last:border-0 hover:bg-secondary/20 transition-colors">
                  <td className="px-2 py-1.5 text-muted-foreground font-medium">{row.seq}</td>
                  {/* Source */}
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs min-w-[80px]" value={row.sourceTable} onChange={(e) => updateRow(idx, 'sourceTable', e.target.value)} placeholder="KNA1" />
                  </td>
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs min-w-[120px]" value={row.sourceTableDesc} onChange={(e) => updateRow(idx, 'sourceTableDesc', e.target.value)} placeholder="Customer Master" />
                  </td>
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs min-w-[80px] border-primary/40" value={row.sourceField} onChange={(e) => updateRow(idx, 'sourceField', e.target.value)} placeholder="KUNNR" />
                  </td>
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs min-w-[120px]" value={row.sourceFieldDesc} onChange={(e) => updateRow(idx, 'sourceFieldDesc', e.target.value)} placeholder="Customer No." />
                  </td>
                  <td className="px-1 py-1">
                    <select className="select-field py-1 text-xs min-w-[70px]" value={row.sourceDataType} onChange={(e) => updateRow(idx, 'sourceDataType', e.target.value)}>
                      {DATA_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </td>
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs w-14" value={row.sourceLength} onChange={(e) => updateRow(idx, 'sourceLength', e.target.value)} placeholder="10" />
                  </td>
                  {/* Target */}
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs min-w-[100px]" value={row.targetView} onChange={(e) => updateRow(idx, 'targetView', e.target.value)} placeholder="I_BPARTNER" />
                  </td>
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs min-w-[100px]" value={row.targetHanaTable} onChange={(e) => updateRow(idx, 'targetHanaTable', e.target.value)} placeholder="BUT000" />
                  </td>
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs min-w-[80px] border-primary/40" value={row.targetField} onChange={(e) => updateRow(idx, 'targetField', e.target.value)} placeholder="PARTNER" />
                  </td>
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs min-w-[120px]" value={row.targetFieldDesc} onChange={(e) => updateRow(idx, 'targetFieldDesc', e.target.value)} placeholder="Business Partner" />
                  </td>
                  <td className="px-1 py-1">
                    <select className="select-field py-1 text-xs min-w-[70px]" value={row.targetDataType} onChange={(e) => updateRow(idx, 'targetDataType', e.target.value)}>
                      {DATA_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </td>
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs w-14" value={row.targetLength} onChange={(e) => updateRow(idx, 'targetLength', e.target.value)} placeholder="10" />
                  </td>
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs w-16" value={row.checkTable} onChange={(e) => updateRow(idx, 'checkTable', e.target.value)} placeholder="BUT000" />
                  </td>
                  <td className="px-1 py-1">
                    <select className="select-field py-1 text-xs w-16" value={row.mandatory} onChange={(e) => updateRow(idx, 'mandatory', e.target.value as 'Yes' | 'No')}>
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                  </td>
                  <td className="px-1 py-1">
                    <select className="select-field py-1 text-xs w-16" value={row.migrationRequired} onChange={(e) => updateRow(idx, 'migrationRequired', e.target.value as 'Yes' | 'No')}>
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                  </td>
                  <td className="px-1 py-1">
                    <select className="select-field py-1 text-xs min-w-[90px]" value={row.transformationType} onChange={(e) => updateRow(idx, 'transformationType', e.target.value as FieldMapping['target']['transformationType'])}>
                      {TRANSFORMATION_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </td>
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs min-w-[160px]" value={row.transformationRule} onChange={(e) => updateRow(idx, 'transformationRule', e.target.value)} placeholder="Map directly..." />
                  </td>
                  <td className="px-1 py-1">
                    <input className="input-field py-1 text-xs min-w-[160px]" value={row.validationRule} onChange={(e) => updateRow(idx, 'validationRule', e.target.value)} placeholder="Must not be blank..." />
                  </td>
                  <td className="px-2 py-1 text-center">
                    <button
                      onClick={() => removeRow(idx)}
                      disabled={rows.length === 1}
                      className="p-1 rounded-md text-muted-foreground hover:text-danger hover:bg-danger/10 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                      title="Remove row"
                    >
                      <Trash2 size={13} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-3 flex items-center justify-between">
          <button
            onClick={addRow}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-primary border border-primary/30 hover:bg-primary/5 transition-colors"
          >
            <Plus size={13} />
            Add Row
          </button>
          <p className="text-xs text-muted-foreground">
            Fields marked <span className="text-danger font-medium">*</span> are required per row.
          </p>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between">
        {onBack && (
          <button onClick={onBack} className="btn-secondary flex items-center gap-2">
            Back
          </button>
        )}
        <button
          onClick={handleSubmit}
          className="btn-primary flex items-center gap-2 ml-auto"
        >
          Load Mappings
          <ArrowRight size={15} />
        </button>
      </div>
    </div>
  );
}
