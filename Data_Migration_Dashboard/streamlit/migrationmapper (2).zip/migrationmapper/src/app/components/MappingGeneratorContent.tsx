'use client';

import React, { useState, useCallback, useEffect } from 'react';
import XmlUploadZone from './XmlUploadZone';
import SourceMetadataEditor from './SourceMetadataEditor';
import ProjectDetailsForm from './ProjectDetailsForm';
import GenerationProgress from './GenerationProgress';
import ManualMappingUpload, { type ManualMappingRow } from './ManualMappingUpload';
import { parseXmlTemplate } from '@/lib/xmlParser';
import { setMappingSession, getStandaloneProjects, type StandaloneProject } from '@/lib/mappingStore';
import type { SourceField, FieldMapping, ProjectDetails } from '@/lib/mappingStore';
import { useRouter } from 'next/navigation';
import { getChatCompletion } from '@/lib/ai/chatCompletion';
import toast from 'react-hot-toast';
import { FileCode2, Table2, FolderOpen, CheckCircle2, AlertCircle, Sparkles, ArrowRight, Upload, X, FileSpreadsheet, Plus, Database, PenLine } from 'lucide-react';

type Step = 'upload' | 'metadata' | 'project' | 'generating' | 'done';
type MappingMode = 'xml' | 'manual';

const STEPS = [
  { id: 'upload', label: 'Upload XML', icon: <FileCode2 size={15} /> },
  { id: 'metadata', label: 'Source Metadata', icon: <Table2 size={15} /> },
  { id: 'project', label: 'Project Details', icon: <FolderOpen size={15} /> },
];

const MANUAL_STEPS = [
  { id: 'upload', label: 'Manual Mapping', icon: <PenLine size={15} /> },
  { id: 'project', label: 'Project Details', icon: <FolderOpen size={15} /> },
];

const PROCESS_AREAS = ['FI – Finance', 'CO – Controlling', 'MM – Materials Management', 'SD – Sales & Distribution', 'PP – Production Planning', 'HR – Human Resources', 'PS – Project System', 'PM – Plant Maintenance', 'QM – Quality Management', 'WM – Warehouse Management', 'RE – Real Estate', 'TR – Treasury'];

// ── Project Selector Step ──────────────────────────────────────────────────────

interface ProjectSelectorProps {
  projects: StandaloneProject[];
  selectedProjectId: string;
  onSelect: (id: string) => void;
  selectedSourceSystem: string;
  onSelectSourceSystem: (sys: string) => void;
  objectName: string;
  onObjectNameChange: (val: string) => void;
  processArea: string;
  onProcessAreaChange: (val: string) => void;
  onSubmit: () => void;
  onBack: () => void;
  submitLabel?: string;
}

function ProjectSelector({
  projects,
  selectedProjectId,
  onSelect,
  selectedSourceSystem,
  onSelectSourceSystem,
  objectName,
  onObjectNameChange,
  processArea,
  onProcessAreaChange,
  onSubmit,
  onBack,
  submitLabel = 'Generate Mapping',
}: ProjectSelectorProps) {
  const selectedProject = projects.find((p) => p.projectId === selectedProjectId) || null;
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!selectedProjectId) e.project = 'Please select a project.';
    if (!selectedSourceSystem) e.sourceSystem = 'Please select a source system.';
    if (!objectName.trim()) e.objectName = 'Object name is required.';
    if (!processArea) e.processArea = 'Process area is required.';
    return e;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    onSubmit();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="card-panel p-6">
        <div className="flex items-center gap-2 mb-5">
          <FolderOpen size={18} className="text-primary" />
          <h2 className="section-header">Select Project</h2>
        </div>

        {projects.length === 0 ? (
          <div className="flex flex-col items-center gap-3 py-8 text-center">
            <FolderOpen size={32} className="text-muted-foreground" />
            <p className="text-sm text-muted-foreground">No projects found. Create a project first before generating mappings.</p>
            <a
              href="/create-project"
              className="btn-primary flex items-center gap-2 text-sm"
            >
              <Plus size={14} />
              Create Project
            </a>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Project Name Dropdown */}
            <div>
              <label className="label-field">Project Name <span className="text-danger">*</span></label>
              <p className="helper-text mb-1">Select the project this mapping belongs to.</p>
              <div className="relative">
                <select
                  className="select-field"
                  value={selectedProjectId}
                  onChange={(e) => { onSelect(e.target.value); onSelectSourceSystem(''); }}
                >
                  <option value="">Select project...</option>
                  {projects.map((p) => (
                    <option key={p.projectId} value={p.projectId}>
                      {p.projectName}
                    </option>
                  ))}
                </select>
              </div>
              {errors.project && <p className="error-text">{errors.project}</p>}
            </div>

            {/* Source System — from project's source systems, only shown after project selected */}
            {selectedProject && (
              <div>
                <label className="label-field">Source System <span className="text-danger">*</span></label>
                <p className="helper-text mb-1">Select the source system for this specific mapping.</p>
                <div className="relative">
                  <select
                    className="select-field"
                    value={selectedSourceSystem}
                    onChange={(e) => onSelectSourceSystem(e.target.value)}
                  >
                    <option value="">Select source system...</option>
                    {selectedProject.sourceSystems.map((sys) => (
                      <option key={sys} value={sys}>{sys}</option>
                    ))}
                  </select>
                </div>
                {errors.sourceSystem && <p className="error-text">{errors.sourceSystem}</p>}
              </div>
            )}

            {/* Object Name & Process Area */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="label-field">Migration Object Name <span className="text-danger">*</span></label>
                <p className="helper-text mb-1">As named in SAP Migration Cockpit (e.g. BusinessPartner, Material).</p>
                <input
                  className="input-field"
                  placeholder="BusinessPartner"
                  value={objectName}
                  onChange={(e) => onObjectNameChange(e.target.value)}
                />
                {errors.objectName && <p className="error-text">{errors.objectName}</p>}
              </div>

              <div>
                <label className="label-field">Process Area <span className="text-danger">*</span></label>
                <p className="helper-text mb-1">SAP functional module for this migration object.</p>
                <select
                  className="select-field"
                  value={processArea}
                  onChange={(e) => onProcessAreaChange(e.target.value)}
                >
                  <option value="">Select process area...</option>
                  {PROCESS_AREAS.map((pa) => (
                    <option key={pa} value={pa}>{pa}</option>
                  ))}
                </select>
                {errors.processArea && <p className="error-text">{errors.processArea}</p>}
              </div>
            </div>

            {/* Target System — fixed, read-only */}
            <div>
              <label className="label-field">Target System</label>
              <div className="input-field bg-muted/30 flex items-center gap-2 cursor-not-allowed">
                <Database size={14} className="text-primary flex-shrink-0" />
                <span className="text-foreground font-medium">S4 HANA</span>
                <span className="ml-auto text-xs text-muted-foreground bg-secondary px-2 py-0.5 rounded-full">Fixed</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {projects.length > 0 && (
        <div className="flex items-center justify-between">
          <button type="button" onClick={onBack} className="btn-secondary flex items-center gap-2">
            Back
          </button>
          <button type="submit" className="btn-primary flex items-center gap-2">
            {submitLabel}
            <ArrowRight size={15} />
          </button>
        </div>
      )}
    </form>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────

export default function MappingGeneratorContent() {
  const router = useRouter();
  const [mappingMode, setMappingMode] = useState<MappingMode>('xml');
  const [currentStep, setCurrentStep] = useState<Step>('upload');
  const [xmlContent, setXmlContent] = useState<string>('');
  const [xmlFileName, setXmlFileName] = useState<string>('');
  const [sourceFields, setSourceFields] = useState<SourceField[]>([]);
  const [projectDetails, setProjectDetails] = useState<ProjectDetails | null>(null);
  const [generationError, setGenerationError] = useState<string>('');
  const [progressLog, setProgressLog] = useState<string[]>([]);
  const [historicalMappingContent, setHistoricalMappingContent] = useState<string>('');
  const [historicalMappingFileName, setHistoricalMappingFileName] = useState<string>('');

  // Manual mapping rows
  const [manualRows, setManualRows] = useState<ManualMappingRow[]>([]);

  // Project selector state
  const [standaloneProjects, setStandaloneProjects] = useState<StandaloneProject[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const [selectedSourceSystem, setSelectedSourceSystem] = useState<string>('');
  const [objectName, setObjectName] = useState<string>('');
  const [processArea, setProcessArea] = useState<string>('');

  useEffect(() => {
    setStandaloneProjects(getStandaloneProjects());
  }, []);

  // Reset step when mode changes
  const handleModeChange = (mode: MappingMode) => {
    setMappingMode(mode);
    setCurrentStep('upload');
    setGenerationError('');
    setProgressLog([]);
    setManualRows([]);
    setXmlContent('');
    setXmlFileName('');
    setSourceFields([]);
  };

  const handleXmlUploaded = useCallback((content: string, fileName: string) => {
    setXmlContent(content);
    setXmlFileName(fileName);
    setSourceFields([]);
    setCurrentStep('metadata');
  }, []);

  const handleMetadataNext = useCallback((fields: SourceField[]) => {
    setSourceFields(fields);
    setCurrentStep('project');
  }, []);

  const handleHistoricalMappingUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const content = ev.target?.result as string;
      setHistoricalMappingContent(content);
      setHistoricalMappingFileName(file.name);
      toast.success(`Historical mapping "${file.name}" loaded — AI will use it as reference.`);
    };
    reader.readAsText(file);
    e.target.value = '';
  }, []);

  const handleClearHistoricalMapping = useCallback(() => {
    setHistoricalMappingContent('');
    setHistoricalMappingFileName('');
  }, []);

  // Manual mapping: rows collected → go to project step
  const handleManualMappingComplete = useCallback((rows: ManualMappingRow[]) => {
    setManualRows(rows);
    setCurrentStep('project');
  }, []);

  // Build ProjectDetails from selected standalone project + object-level fields
  const handleProjectSelectorSubmit = useCallback(async () => {
    const selectedProject = standaloneProjects.find((p) => p.projectId === selectedProjectId);
    if (!selectedProject) return;

    const details: ProjectDetails = {
      projectName: selectedProject.projectName,
      clientName: selectedProject.clientName,
      sourceSystem: selectedSourceSystem,
      sourceSystems: selectedProject.sourceSystems,
      targetSystem: 'S4 HANA',
      dmConsultant: selectedProject.dmConsultant,
      functionalOwner: selectedProject.functionalOwner || '',
      businessOwner: selectedProject.businessOwner || '',
      phase: selectedProject.phase,
      createdDate: selectedProject.createdDate,
      processArea,
      objectName,
      clientLogoDataUrl: selectedProject.clientLogoDataUrl,
      partnerLogoDataUrl: selectedProject.partnerLogoDataUrl,
    };

    setProjectDetails(details);
    setCurrentStep('generating');
    setGenerationError('');
    setProgressLog([]);

    try {
      if (mappingMode === 'manual') {
        // Convert manual rows to FieldMappings directly
        await runManualMapping(manualRows, details, setProgressLog);
      } else {
        await runGeneration(xmlContent, xmlFileName, sourceFields, details, setProgressLog, historicalMappingContent);
      }
      setCurrentStep('done');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Generation failed. Please try again.';
      setGenerationError(msg);
      toast.error(msg);
      setCurrentStep('project');
    }
  }, [standaloneProjects, selectedProjectId, selectedSourceSystem, objectName, processArea, xmlContent, xmlFileName, sourceFields, historicalMappingContent, mappingMode, manualRows]);

  // Fallback: if no standalone projects, use the old ProjectDetailsForm
  const handleProjectFormSubmit = useCallback(
    async (details: ProjectDetails) => {
      const detailsWithTarget: ProjectDetails = { ...details, targetSystem: 'S4 HANA' };
      setProjectDetails(detailsWithTarget);
      setCurrentStep('generating');
      setGenerationError('');
      setProgressLog([]);

      try {
        if (mappingMode === 'manual') {
          await runManualMapping(manualRows, detailsWithTarget, setProgressLog);
        } else {
          await runGeneration(xmlContent, xmlFileName, sourceFields, detailsWithTarget, setProgressLog, historicalMappingContent);
        }
        setCurrentStep('done');
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Generation failed. Please try again.';
        setGenerationError(msg);
        toast.error(msg);
        setCurrentStep('project');
      }
    },
    [xmlContent, xmlFileName, sourceFields, historicalMappingContent, mappingMode, manualRows]
  );

  const handleGoToPreview = () => {
    router.push('/mapping-preview-export');
  };

  const activeSteps = mappingMode === 'manual' ? MANUAL_STEPS : STEPS;
  const stepIndex = activeSteps.findIndex((s) => s.id === currentStep);

  return (
    <div className="min-h-screen px-6 py-6 xl:px-10 2xl:px-14 max-w-screen-2xl">
      {/* Page header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
          <Sparkles size={13} />
          <span>AI-Powered Mapping Generation</span>
        </div>
        <h1 className="page-title">Mapping Generator</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Upload a SAP Migration Cockpit XML template and generate a complete field-to-field mapping sheet.
        </p>
      </div>

      {/* Mode Toggle */}
      {(currentStep === 'upload') && (
        <div className="mb-6 flex items-center gap-2 p-1 rounded-xl bg-secondary/60 border border-border w-fit">
          <button
            onClick={() => handleModeChange('xml')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              mappingMode === 'xml' ?'bg-card shadow-sm text-primary border border-border' :'text-muted-foreground hover:text-foreground'
            }`}
          >
            <FileCode2 size={15} />
            XML Upload (AI)
          </button>
          <button
            onClick={() => handleModeChange('manual')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              mappingMode === 'manual' ?'bg-card shadow-sm text-primary border border-border' :'text-muted-foreground hover:text-foreground'
            }`}
          >
            <PenLine size={15} />
            Manual Mapping
          </button>
        </div>
      )}

      {/* Historical Mapping Upload — only for XML mode */}
      {mappingMode === 'xml' && (currentStep === 'upload' || currentStep === 'metadata' || currentStep === 'project') && (
        <div className="mb-6 p-4 rounded-xl border border-dashed border-border bg-secondary/30">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center flex-shrink-0 mt-0.5">
              <FileSpreadsheet size={15} className="text-amber-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground">
                Historical Mapping Reference <span className="text-xs font-normal text-muted-foreground ml-1">(optional)</span>
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Upload an existing mapping file (CSV, XLSX exported as CSV, or TXT) to help AI generate more accurate transformation rules based on past mappings.
              </p>
              {historicalMappingFileName ? (
                <div className="flex items-center gap-2 mt-2">
                  <span className="flex items-center gap-1.5 text-xs font-medium text-success bg-success-bg px-2.5 py-1 rounded-full">
                    <CheckCircle2 size={11} />
                    {historicalMappingFileName}
                  </span>
                  <button
                    onClick={handleClearHistoricalMapping}
                    className="p-1 rounded-md text-muted-foreground hover:text-danger hover:bg-danger/10 transition-colors"
                    title="Remove historical mapping"
                  >
                    <X size={13} />
                  </button>
                </div>
              ) : (
                <label className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-card border border-border text-foreground hover:bg-secondary cursor-pointer transition-colors">
                  <Upload size={12} />
                  Upload Historical Mapping
                  <input
                    type="file"
                    accept=".csv,.txt,.tsv"
                    className="hidden"
                    onChange={handleHistoricalMappingUpload}
                  />
                </label>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Step indicator */}
      {currentStep !== 'generating' && currentStep !== 'done' && (
        <div className="flex items-center gap-0 mb-8">
          {activeSteps.map((step, idx) => {
            const isActive = step.id === currentStep;
            const isComplete = idx < stepIndex;
            return (
              <React.Fragment key={`step-${step.id}-${idx}`}>
                <div className="flex items-center gap-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-200 ${
                      isComplete
                        ? 'step-complete'
                        : isActive
                        ? 'step-active' :'step-pending'
                    }`}
                  >
                    {isComplete ? <CheckCircle2 size={14} /> : idx + 1}
                  </div>
                  <div>
                    <p
                      className={`text-xs font-semibold ${
                        isActive ? 'text-primary' : isComplete ? 'text-success' : 'text-muted-foreground'
                      }`}
                    >
                      {step.label}
                    </p>
                  </div>
                </div>
                {idx < activeSteps.length - 1 && (
                  <div
                    className={`flex-1 h-0.5 mx-3 rounded transition-all duration-200 ${
                      isComplete ? 'bg-success' : 'bg-border'
                    }`}
                  />
                )}
              </React.Fragment>
            );
          })}
        </div>
      )}

      {/* Error banner */}
      {generationError && (
        <div className="mb-5 flex items-start gap-3 p-4 rounded-lg border border-red-200 bg-danger-bg animate-fadeIn">
          <AlertCircle size={16} className="text-danger flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-danger">Generation Failed</p>
            <p className="text-sm text-danger mt-0.5">{generationError}</p>
          </div>
        </div>
      )}

      {/* Step content */}
      <div className="animate-fadeIn">
        {/* XML Mode Steps */}
        {mappingMode === 'xml' && currentStep === 'upload' && (
          <XmlUploadZone onUploaded={handleXmlUploaded} />
        )}
        {mappingMode === 'xml' && currentStep === 'metadata' && (
          <SourceMetadataEditor
            xmlContent={xmlContent}
            xmlFileName={xmlFileName}
            initialFields={sourceFields}
            onNext={handleMetadataNext}
            onBack={() => setCurrentStep('upload')}
          />
        )}

        {/* Manual Mode Steps */}
        {mappingMode === 'manual' && currentStep === 'upload' && (
          <ManualMappingUpload
            onComplete={handleManualMappingComplete}
          />
        )}

        {/* Shared: Project Step */}
        {currentStep === 'project' && (
          standaloneProjects.length > 0 ? (
            <ProjectSelector
              projects={standaloneProjects}
              selectedProjectId={selectedProjectId}
              onSelect={setSelectedProjectId}
              selectedSourceSystem={selectedSourceSystem}
              onSelectSourceSystem={setSelectedSourceSystem}
              objectName={objectName}
              onObjectNameChange={setObjectName}
              processArea={processArea}
              onProcessAreaChange={setProcessArea}
              onSubmit={handleProjectSelectorSubmit}
              onBack={() => setCurrentStep('upload')}
              submitLabel={mappingMode === 'manual' ? 'Save Mapping' : 'Generate Mapping'}
            />
          ) : (
            <ProjectDetailsForm
              onSubmit={handleProjectFormSubmit}
              onBack={() => setCurrentStep('upload')}
              initialValues={projectDetails}
            />
          )
        )}

        {currentStep === 'generating' && (
          <GenerationProgress progressLog={progressLog} />
        )}
        {currentStep === 'done' && (
          <div className="card-panel p-10 flex flex-col items-center justify-center text-center max-w-lg mx-auto animate-fadeScale">
            <div className="w-16 h-16 rounded-full bg-success-bg flex items-center justify-center mb-4">
              <CheckCircle2 size={32} className="text-success" />
            </div>
            <h2 className="text-xl font-semibold text-foreground mb-2">
              {mappingMode === 'manual' ? 'Mapping Sheet Saved' : 'Mapping Sheet Generated'}
            </h2>
            <p className="text-sm text-muted-foreground mb-6">
              {mappingMode === 'manual' ?'Your manually entered mappings have been saved. Review and edit them before exporting.' :'All target fields have been extracted and mapped. Review and edit the mappings before exporting your branded Excel file.'}
            </p>
            <button onClick={handleGoToPreview} className="btn-primary gap-2">
              Preview & Export Mapping
              <ArrowRight size={16} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Manual Mapping → FieldMappings ────────────────────────────────────────────

async function runManualMapping(
  rows: ManualMappingRow[],
  projectDetails: ProjectDetails,
  setProgressLog: React.Dispatch<React.SetStateAction<string[]>>
): Promise<void> {
  const log = (msg: string) => setProgressLog((p) => [...p, msg]);

  log(`Processing ${rows.length} manually entered mapping rows...`);
  await delay(400);

  const mappings: FieldMapping[] = rows.map((row, idx) => ({
    id: `mapping-${String(idx + 1).padStart(3, '0')}`,
    seq: row.seq || idx + 1,
    source: {
      id: `src-manual-${idx + 1}`,
      tableName: row.sourceTable || 'LEGACY_TABLE',
      tableDescription: row.sourceTableDesc || 'Source Table',
      fieldName: row.sourceField,
      fieldDescription: row.sourceFieldDesc || '',
      dataType: row.sourceDataType || 'CHAR',
      length: row.sourceLength || '0',
      decimal: row.sourceDecimal || '0',
    },
    target: {
      targetViewName: row.targetView || `I_${(projectDetails.objectName || 'OBJECT').toUpperCase().replace(/\s/g, '_')}`,
      targetFieldName: row.targetField,
      targetFieldDescription: row.targetFieldDesc || '',
      targetFieldDataType: row.targetDataType || 'CHAR',
      targetFieldLength: row.targetLength || '0',
      targetFieldDecimal: row.targetDecimal || '0',
      targetHanaTable: row.targetHanaTable || projectDetails.objectName || 'MIGRATION_TABLE',
      checkTable: row.checkTable || '',
      mandatory: row.mandatory,
      migrationRequired: row.migrationRequired,
      transformationType: row.transformationType,
      transformationRule: row.transformationRule || '',
      validationRule: row.validationRule || '',
    },
  }));

  log(`Mapped ${mappings.length} fields.`);
  await delay(300);
  log('Saving mapping sheet...');
  await delay(300);

  setMappingSession({
    projectDetails: { ...projectDetails, targetSystem: 'S4 HANA' },
    mappings,
    xmlFileName: 'manual-mapping.csv',
    generatedAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
  });

  log('✓ Manual mapping sheet ready for review.');
}

// ── SAP ECC Standard Table Knowledge Base ─────────────────────────────────────
const SAP_ECC_TABLE_KNOWLEDGE = `
You are an SAP ECC to S/4HANA migration expert with deep knowledge of SAP standard tables and fields.
When the source system is SAP ECC, you MUST use actual SAP ECC standard table names and field names.

Key SAP ECC standard tables by process area:
- FI/Finance: BKPF (Accounting Document Header), BSEG (Accounting Document Segment), SKA1 (G/L Account Master - Chart of Accounts), SKAT (G/L Account Master - Chart of Accounts Texts), KNA1 (Customer Master General Data), KNB1 (Customer Master Company Code Data), LFA1 (Vendor Master General Data), LFB1 (Vendor Master Company Code Data), BSAD (Accounting: Secondary Index for Customers), BSAK (Accounting: Secondary Index for Vendors), BSID (Accounting: Secondary Index for Customers), BSIK (Accounting: Secondary Index for Vendors), T001 (Company Codes), T004 (Chart of Accounts), FAGLFLEXT (General Ledger: Totals)
- CO/Controlling: CSKA (Cost Elements - Chart of Accounts), CSKB (Cost Elements - Controlling Area), CSKS (Cost Center Master Data), CSKT (Cost Center Texts), AUFK (Order Master Data), COSP (CO Object: Cost Totals for External Postings), COSS (CO Object: Cost Totals for Internal Postings), PRPS (WBS Element Master Data), PROJ (Project Definition)
- MM/Materials Management: MARA (General Material Data), MARC (Plant Data for Material), MARD (Storage Location Data for Material), MAKT (Material Descriptions), EKKO (Purchasing Document Header), EKPO (Purchasing Document Item), EINA (Purchasing Info Record - General Data), EINE (Purchasing Info Record - Purchasing Org. Data), LFA1 (Vendor Master General Data), MBEW (Material Valuation), MCHB (Batch Stocks), MKPF (Header: Material Document), MSEG (Document Segment: Material), T001W (Plants/Branches), T024 (Purchasing Groups)
- SD/Sales & Distribution: VBAK (Sales Document Header Data), VBAP (Sales Document Item Data), VBKD (Sales Document Business Data), VBPA (Sales Document Partner), KNA1 (Customer Master General Data), KNVV (Customer Master Sales Data), KNVP (Customer Master Partner Functions), MARA (General Material Data), TVAK (Sales Document Types), TVAP (Sales Document Item Categories), VBRK (Billing Document Header), VBRP (Billing Document Item)
- HR/Human Resources: PA0001 (HR Master Record Infotype 0001 - Org. Assignment), PA0002 (HR Master Record Infotype 0002 - Personal Data), PA0006 (HR Master Record Infotype 0006 - Addresses), PA0007 (HR Master Record Infotype 0007 - Planned Working Time), PA0008 (HR Master Record Infotype 0008 - Basic Pay), PA0009 (HR Master Record Infotype 0009 - Bank Details), PA0014 (HR Master Record Infotype 0014 - Recurring Payments), PA0015 (HR Master Record Infotype 0015 - Additional Payments), HRP1000 (Infotype 1000 DB Table for Object), HRP1001 (Infotype 1001 DB Table for Relationships)
- PP/Production Planning: MARA (General Material Data), MARC (Plant Data for Material), PLKO (Task List Header), PLPO (Task List Operation), STKO (BOM Header), STPO (BOM Item), AFKO (Order Header Data PP Orders), AFPO (Order Item), CRHD (Work Center Header), CRCO (Assignment of Work Center to Cost Center)
- PM/Plant Maintenance: EQUI (Equipment Master Data), EQKT (Equipment Short Texts), IFLOT (Functional Location), IFLOTX (Functional Location Texts), QMEL (Quality Notification), AUFK (Order Master Data), AFIH (Maintenance Order Header)
- QM/Quality Management: QMEL (Quality Notification), QMFE (Notification Items), QMMA (Notification Activities), PRÜF (Inspection Lot), QALS (Inspection Lot Record)
- WM/Warehouse Management: LGKO (Warehouse Number), LGPLA (Storage Bin), LQUA (Quants), LTAP (Transfer Order Item), LTBK (Transfer Order Header)
- RE/Real Estate: VIOB01 (Business Entity), VIOB10 (Property), VIOB20 (Building), VIOB30 (Rental Unit)
- TR/Treasury: VDKBEW (Securities Account Positions), VTBFHA (Transaction), VTBFHAPO (Transaction Flow)

Common SAP ECC field naming conventions:
- MANDT: Client (CLNT, 3)
- BUKRS: Company Code (CHAR, 4)
- WERKS: Plant (CHAR, 4)
- MATNR: Material Number (CHAR, 18)
- LIFNR: Vendor Account Number (CHAR, 10)
- KUNNR: Customer Account Number (CHAR, 10)
- BELNR: Accounting Document Number (CHAR, 10)
- GJAHR: Fiscal Year (NUMC, 4)
- BLDAT: Document Date in Document (DATS, 8)
- BUDAT: Posting Date in the Document (DATS, 8)
- WRBTR: Amount in Document Currency (CURR, 13)
- WAERS: Currency Key (CUKY, 5)
- KOSTL: Cost Center (CHAR, 10)
- AUFNR: Order Number (CHAR, 12)
- PSPNR: Work Breakdown Structure Element (NUMC, 8)
- VBELN: Sales and Distribution Document Number (CHAR, 10)
- POSNR: Item Number of the SD Document (NUMC, 6)
- EBELN: Purchasing Document Number (CHAR, 10)
- EBELP: Item Number of Purchasing Document (NUMC, 5)
- LGNUM: Warehouse Number (CHAR, 3)
- LGTYP: Storage Type (CHAR, 3)
- LGPLA: Storage Bin (CHAR, 10)
- PERNR: Personnel Number (NUMC, 8)
- BEGDA: Start Date (DATS, 8)
- ENDDA: End Date (DATS, 8)
`;

const SAP_ECC_INFERENCE_INSTRUCTION = `
CRITICAL REQUIREMENT: Since the source system is SAP ECC, you MUST use actual SAP ECC standard table names and field names.
- Use real SAP ECC table names (e.g., BKPF, BSEG, KNA1, LFA1, MARA, MARC, VBAK, PA0001, etc.)
- Use real SAP ECC field names with correct data types and lengths (e.g., BUKRS CHAR 4, MATNR CHAR 18, BLDAT DATS 8)
- Match the process area to the appropriate SAP ECC tables
- For each target field, identify the most likely SAP ECC source table and field
- Do NOT use generic names like LEGACY_TABLE or FIELD_1
`;

// ── AI Generation Logic ────────────────────────────────────────────────────────
async function runGeneration(
  xmlContent: string,
  xmlFileName: string,
  sourceFields: SourceField[],
  projectDetails: ProjectDetails,
  setProgressLog: React.Dispatch<React.SetStateAction<string[]>>,
  historicalMappingContent: string = ''
): Promise<void> {
  const log = (msg: string) => setProgressLog((p) => [...p, msg]);

  log('Parsing XML template structure...');
  await delay(400);

  const parsed = parseXmlTemplate(xmlContent);
  log(`Found ${parsed.fields.length} target fields in XML template.`);
  await delay(300);

  let resolvedSourceFields: SourceField[] = sourceFields;

  if (sourceFields.length === 0) {
    const isSapEcc = isSapEccSystem(projectDetails.sourceSystem);
    if (isSapEcc) {
      log('SAP ECC source system detected — inferring source structure using SAP standard tables and fields...');
    } else {
      log('No source metadata provided — inferring source structure from XML via OpenAI...');
    }
    resolvedSourceFields = await inferSourceFieldsWithAI(parsed, xmlContent, projectDetails);
    log(`Inferred ${resolvedSourceFields.length} source fields using OpenAI.`);
  } else {
    log(`Using ${sourceFields.length} manually provided source fields.`);
  }

  if (historicalMappingContent) {
    log('Historical mapping reference detected — AI will use it to improve accuracy.');
  }

  await delay(300);
  log('Generating target field mappings with OpenAI...');

  const mappings = await generateMappingsWithAI(parsed, resolvedSourceFields, projectDetails, log, historicalMappingContent);

  log(`Generated ${mappings.length} field mappings.`);
  await delay(300);
  log('Finalising mapping sheet...');
  await delay(400);

  setMappingSession({
    projectDetails: { ...projectDetails, targetSystem: 'S4 HANA' },
    mappings,
    xmlFileName,
    generatedAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
  });

  log('✓ Mapping sheet ready for review.');
}

function isSapEccSystem(sourceSystem: string): boolean {
  if (!sourceSystem) return false;
  const normalized = sourceSystem.toLowerCase();
  return (
    normalized.includes('sap ecc') ||
    normalized.includes('sap r/3') ||
    normalized.includes('sap r3') ||
    normalized.includes('ecc') ||
    normalized.includes('r/3') ||
    normalized.includes('erp 6') ||
    normalized.includes('sap erp')
  );
}

async function inferSourceFieldsWithAI(
  parsed: ReturnType<typeof parseXmlTemplate>,
  xmlContent: string,
  projectDetails: ProjectDetails
): Promise<SourceField[]> {
  const isSapEcc = isSapEccSystem(projectDetails.sourceSystem || '');

  const systemPrompt = isSapEcc
    ? `You are an SAP ECC to S/4HANA migration expert with deep knowledge of SAP standard tables and fields. Always respond with valid JSON only, no markdown.\n\n${SAP_ECC_TABLE_KNOWLEDGE}`
    : 'You are an SAP S/4HANA data migration expert. Always respond with valid JSON only, no markdown.';

  const sapEccInstruction = isSapEcc ? SAP_ECC_INFERENCE_INSTRUCTION : 'Use realistic legacy system naming conventions.';

  const prompt = `You are an SAP S/4HANA data migration expert. Based on the following SAP Migration Cockpit XML template fields, infer a realistic source table structure that would typically be migrated to these target fields.

Source System: ${projectDetails.sourceSystem || 'Legacy System'}
Process Area: ${projectDetails.processArea || 'Not specified'}
Migration Object: ${parsed.objectName}

Target fields from XML:
${parsed.fields.map((f) => `- ${f.fieldName} (${f.fieldDescription}, ${f.dataType}, length ${f.length})`).join('\n')}

${sapEccInstruction}

Return a JSON array of source fields with this exact structure (no markdown, pure JSON):
[
  {
    "tableName": "TABLE_NAME",
    "tableDescription": "Description of source table",
    "fieldName": "FIELD_NAME",
    "fieldDescription": "Field description",
    "dataType": "CHAR|NUMC|DATS|CURR|etc",
    "length": "10",
    "decimal": "0"
  }
]

Generate one source field per target field. ${isSapEcc ? 'Use actual SAP ECC standard table and field names matching the process area and migration object.' : 'Use realistic legacy system naming conventions.'}`;

  const response = await getChatCompletion(
    'OPEN_AI',
    'gpt-4o',
    [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: prompt },
    ],
    { max_completion_tokens: 4096, temperature: 0.2 }
  );

  const content = response.choices[0]?.message?.content || '[]';
  const cleaned = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
  const parsed2: Array<Omit<SourceField, 'id'>> = JSON.parse(cleaned);

  return parsed2.map((f, i) => ({
    id: `src-ai-${i + 1}`,
    tableName: f.tableName || (isSapEcc ? 'MARA' : 'LEGACY_TABLE'),
    tableDescription: f.tableDescription || (isSapEcc ? 'SAP ECC Source Table' : 'Legacy Source Table'),
    fieldName: f.fieldName || `FIELD_${i + 1}`,
    fieldDescription: f.fieldDescription || '',
    dataType: f.dataType || 'CHAR',
    length: String(f.length || '0'),
    decimal: String(f.decimal || '0'),
  }));
}

async function generateMappingsWithAI(
  parsed: ReturnType<typeof parseXmlTemplate>,
  sourceFields: SourceField[],
  projectDetails: ProjectDetails,
  log: (msg: string) => void,
  historicalMappingContent: string = ''
): Promise<FieldMapping[]> {
  const viewName =
    parsed.viewName ||
    `I_${(projectDetails.objectName || 'OBJECT').toUpperCase().replace(/\s/g, '_')}`;
  const hanaTable = parsed.hanaTable || parsed.objectName || 'MIGRATION_TABLE';

  const targetFieldsSummary = parsed.fields
    .map(
      (f) =>
        `${f.fieldName}|${f.fieldDescription}|${f.dataType}|${f.length}|${f.decimal}|${f.mandatory ? 'Y' : 'N'}|${f.checkTable}`
    )
    .join('\n');

  const sourceFieldsSummary = sourceFields
    .slice(0, parsed.fields.length)
    .map(
      (f) =>
        `${f.fieldName}|${f.fieldDescription}|${f.dataType}|${f.length}|${f.decimal}`
    )
    .join('\n');

  const historicalSection = historicalMappingContent
    ? `\nHistorical mapping reference (use to improve transformation and validation rules):\n${historicalMappingContent.slice(0, 3000)}\n`
    : '';

  const isSapEcc = isSapEccSystem(projectDetails.sourceSystem || '');
  const sapEccMappingContext = isSapEcc
    ? `\nSOURCE SYSTEM CONTEXT: The source system is SAP ECC. The source fields listed above are actual SAP ECC standard table fields. When generating transformation rules:
- Reference the exact SAP ECC source table and field names in transformation rules (e.g., "Read from BKPF-BUKRS", "Map KNA1-KUNNR directly")
- For SAP ECC to S/4HANA migrations, note any field renames or structural changes (e.g., BSEG to ACDOCA in S/4HANA)
- Use SAP-specific validation rules referencing check tables (e.g., "Must exist in T001", "Validate against T006")
- For date fields (DATS), note SAP internal format YYYYMMDD is already compatible
- For currency fields (CURR/CUKY), reference TCURC and TCURR tables for validation
- For organizational fields (BUKRS, WERKS, LGNUM), reference the appropriate SAP configuration tables\n`
    : '';

  const prompt = `You are an SAP S/4HANA data migration expert. Generate field mapping details for the following SAP migration object.

Project: ${projectDetails.projectName}
Object: ${projectDetails.objectName}
Source System: ${projectDetails.sourceSystem || 'Legacy System'}
Process Area: ${projectDetails.processArea}
Target System: S4 HANA
Target View: ${viewName}
Target HANA Table: ${hanaTable}
${sapEccMappingContext}
Target fields (FieldName|Description|DataType|Length|Decimal|Mandatory|CheckTable):
${targetFieldsSummary}

Source fields (SourceTable.FieldName|Description|DataType|Length|Decimal):
${sourceFieldsSummary}
${historicalSection}
For each target field, provide the mapping details as a JSON array. Each element must have:
{
  "targetFieldName": "...",
  "mandatory": "Yes" or "No",
  "migrationRequired": "Yes" or "No",
  "transformationType": one of ["Direct","Lookup","Concatenation","Default","Conditional","Derivation","None"],
  "transformationRule": "Detailed rule description referencing source table.field",
  "validationRule": "Detailed validation rule referencing SAP check tables where applicable"
}

Rules:
- Use "Direct" for simple 1:1 mappings of same data type
- Use "Lookup"when a check table is involved - Use"Conditional" for date/time conversions
- Use "Derivation" for calculated or derived fields
- Use "Default" for system-populated fields (client, timestamps)
- Provide specific, actionable transformation and validation rules
- Return pure JSON array only, no markdown

Return exactly ${parsed.fields.length} elements in the same order as the target fields.`;

  log('Calling OpenAI to generate transformation rules...');

  const mappingSystemPrompt = isSapEcc
    ? `You are an SAP ECC to S/4HANA migration expert with deep knowledge of SAP standard tables, field names, data types, and migration best practices. Always respond with valid JSON only, no markdown code blocks.\n\n${SAP_ECC_TABLE_KNOWLEDGE}`
    : 'You are an SAP S/4HANA data migration expert. Always respond with valid JSON only, no markdown code blocks.';

  const response = await getChatCompletion(
    'OPEN_AI',
    'gpt-4o',
    [
      {
        role: 'system',
        content: mappingSystemPrompt,
      },
      { role: 'user', content: prompt },
    ],
    { max_completion_tokens: 8192, temperature: 0.2 }
  );

  const content = response.choices[0]?.message?.content || '[]';
  const cleaned = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();

  let aiMappings: Array<{
    targetFieldName: string;
    mandatory: 'Yes' | 'No';
    migrationRequired: 'Yes' | 'No';
    transformationType: FieldMapping['target']['transformationType'];
    transformationRule: string;
    validationRule: string;
  }> = [];

  try {
    aiMappings = JSON.parse(cleaned);
  } catch {
    log('AI response parse error — falling back to rule-based generation.');
    return generateMappingsFallback(parsed, sourceFields, projectDetails);
  }

  return parsed.fields.map((tf, idx) => {
    const src = sourceFields[idx] ||
      sourceFields[sourceFields.length - 1] || {
        id: `src-auto-${idx + 1}`,
        tableName: 'LEGACY_TABLE',
        tableDescription: 'Legacy Source Table',
        fieldName: tf.fieldName,
        fieldDescription: tf.fieldDescription,
        dataType: tf.dataType,
        length: tf.length,
        decimal: tf.decimal,
      };

    const aiRow = aiMappings[idx] || {
      mandatory: tf.mandatory ? 'Yes' : 'No',
      migrationRequired: 'Yes',
      transformationType: 'Direct' as const,
      transformationRule: 'Map source field directly to target field.',
      validationRule: 'Validate field length and data type.',
    };

    return {
      id: `mapping-${String(idx + 1).padStart(3, '0')}`,
      seq: idx + 1,
      source: {
        id: src.id || `src-${idx + 1}`,
        tableName: src.tableName,
        tableDescription: src.tableDescription,
        fieldName: src.fieldName,
        fieldDescription: src.fieldDescription,
        dataType: src.dataType,
        length: src.length,
        decimal: src.decimal,
      },
      target: {
        targetViewName: viewName,
        targetFieldName: tf.fieldName,
        targetFieldDescription: tf.fieldDescription,
        targetFieldDataType: tf.dataType,
        targetFieldLength: tf.length,
        targetFieldDecimal: tf.decimal,
        targetHanaTable: hanaTable,
        checkTable: tf.checkTable || '',
        mandatory: aiRow.mandatory,
        migrationRequired: aiRow.migrationRequired,
        transformationType: aiRow.transformationType,
        transformationRule: aiRow.transformationRule,
        validationRule: aiRow.validationRule,
      },
    };
  });
}

const TRANSFORMATION_RULES: Record<
  string,
  {
    type: FieldMapping['target']['transformationType'];
    rule: string;
    validation: string;
  }
> = {
  CHAR: { type: 'Direct', rule: 'Map source field directly to target field. Trim trailing spaces.', validation: 'Check length does not exceed target field length.' },
  NUMC: { type: 'Direct', rule: 'Map numeric string directly. Zero-pad to target length if shorter.', validation: 'Validate all characters are numeric (0-9).' },
  DATS: { type: 'Conditional', rule: 'Convert source date format (DD/MM/YYYY or YYYYMMDD) to SAP internal format YYYYMMDD.', validation: 'Validate date is a valid calendar date. Reject 00000000.' },
  TIMS: { type: 'Direct', rule: 'Map time value in HHMMSS format directly.', validation: 'Validate HHMMSS range: HH 00-23, MM 00-59, SS 00-59.' },
  CURR: { type: 'Derivation', rule: 'Map currency amount. Ensure decimal precision matches CURRENCY field.', validation: 'Validate numeric. Check against TCURC for currency key.' },
  CUKY: { type: 'Lookup', rule: 'Map currency key from source. Lookup in TCURC to validate ISO currency code.', validation: 'Value must exist in table TCURC.' },
  QUAN: { type: 'Derivation', rule: 'Map quantity value. Derive unit of measure from corresponding UNIT field.', validation: 'Validate numeric with correct decimal places per UOM.' },
  UNIT: { type: 'Lookup', rule: 'Map unit of measure from source. Lookup T006 for valid UoM codes.', validation: 'Value must exist in table T006.' },
  LANG: { type: 'Lookup', rule: 'Map language key from source ISO code. Lookup T002 for valid SAP language keys.', validation: 'Value must exist in table T002.' },
  CLNT: { type: 'Default', rule: 'Default to target SAP client number. Do not map from source.', validation: 'Must match target system client.' },
};

function generateMappingsFallback(
  parsed: ReturnType<typeof parseXmlTemplate>,
  sourceFields: SourceField[],
  projectDetails: ProjectDetails
): FieldMapping[] {
  const viewName =
    parsed.viewName ||
    `I_${(projectDetails.objectName || 'OBJECT').toUpperCase().replace(/\s/g, '_')}`;
  const hanaTable = parsed.hanaTable || parsed.objectName || 'MIGRATION_TABLE';

  return parsed.fields.map((tf, idx) => {
    const src = sourceFields[idx] ||
      sourceFields[sourceFields.length - 1] || {
        id: `src-auto-${idx + 1}`,
        tableName: 'LEGACY_TABLE',
        tableDescription: 'Legacy Source Table',
        fieldName: tf.fieldName,
        fieldDescription: tf.fieldDescription,
        dataType: tf.dataType,
        length: tf.length,
        decimal: tf.decimal,
      };

    const ruleSet = TRANSFORMATION_RULES[tf.dataType] || TRANSFORMATION_RULES['CHAR'];
    const isMandatory = tf.mandatory || idx < 2;

    return {
      id: `mapping-${String(idx + 1).padStart(3, '0')}`,
      seq: idx + 1,
      source: {
        id: src.id || `src-${idx + 1}`,
        tableName: src.tableName,
        tableDescription: src.tableDescription,
        fieldName: src.fieldName,
        fieldDescription: src.fieldDescription,
        dataType: src.dataType,
        length: src.length,
        decimal: src.decimal,
      },
      target: {
        targetViewName: viewName,
        targetFieldName: tf.fieldName,
        targetFieldDescription: tf.fieldDescription,
        targetFieldDataType: tf.dataType,
        targetFieldLength: tf.length,
        targetFieldDecimal: tf.decimal,
        targetHanaTable: hanaTable,
        checkTable: tf.checkTable || '',
        mandatory: isMandatory ? 'Yes' : 'No',
        migrationRequired: idx < Math.ceil(parsed.fields.length * 0.75) ? 'Yes' : 'No',
        transformationType: ruleSet.type,
        transformationRule: ruleSet.rule,
        validationRule: ruleSet.validation,
      },
    };
  });
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}