'use client';

import React, { useEffect, useState } from 'react';
import { parseXmlTemplate } from '@/lib/xmlParser';
import type { SourceField } from '@/lib/mappingStore';
import {
  Plus,
  Trash2,
  Table2,
  ArrowRight,
  ArrowLeft,
  Info,
  Wand2,
  CheckCircle2,
} from 'lucide-react';

interface Props {
  xmlContent: string;
  xmlFileName: string;
  initialFields: SourceField[];
  onNext: (fields: SourceField[]) => void;
  onBack: () => void;
}

const DATA_TYPES = ['CHAR', 'NUMC', 'DATS', 'TIMS', 'CURR', 'CUKY', 'QUAN', 'UNIT', 'LANG', 'CLNT', 'INT1', 'INT2', 'INT4', 'FLTP', 'DEC', 'RAW', 'LRAW', 'STRING', 'XSTRING'];

const EMPTY_FIELD = (): SourceField => ({
  id: `src-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
  tableName: '',
  tableDescription: '',
  fieldName: '',
  fieldDescription: '',
  dataType: 'CHAR',
  length: '0',
  decimal: '0',
});

export default function SourceMetadataEditor({ xmlContent, xmlFileName, initialFields, onNext, onBack }: Props) {
  const [fields, setFields] = useState<SourceField[]>(initialFields.length > 0 ? initialFields : []);
  const [autoInferred, setAutoInferred] = useState(false);
  const [mode, setMode] = useState<'manual' | 'auto'>('auto');

  // Reset state whenever a new XML file is uploaded
  useEffect(() => {
    setFields(initialFields.length > 0 ? initialFields : []);
    setAutoInferred(false);
    setMode('auto');
  }, [xmlContent]);

  const handleAutoInfer = () => {
    const parsed = parseXmlTemplate(xmlContent);
    const inferred: SourceField[] = parsed.fields.map((f, i) => ({
      id: `src-inferred-${i + 1}`,
      tableName: 'LEGACY_TABLE',
      tableDescription: 'Legacy Source Table (Inferred)',
      fieldName: f.fieldName,
      fieldDescription: f.fieldDescription,
      dataType: f.dataType,
      length: f.length,
      decimal: f.decimal,
    }));
    setFields(inferred);
    setAutoInferred(true);
    setMode('manual');
  };

  const handleAddRow = () => {
    setFields((prev) => [...prev, EMPTY_FIELD()]);
  };

  const handleRemoveRow = (id: string) => {
    setFields((prev) => prev.filter((f) => f.id !== id));
  };

  const handleChange = (id: string, key: keyof SourceField, value: string) => {
    setFields((prev) =>
      prev.map((f) => (f.id === id ? { ...f, [key]: value } : f))
    );
  };

  const handleProceed = () => {
    // Pass empty array if auto mode (AI will infer during generation)
    onNext(mode === 'auto' && !autoInferred ? [] : fields);
  };

  const parsed = parseXmlTemplate(xmlContent);

  return (
    <div className="space-y-5">
      {/* Mode selector */}
      <div className="card-panel p-5">
        <div className="flex items-center gap-2 mb-4">
          <Table2 size={18} className="text-primary" />
          <h2 className="section-header">Source Metadata</h2>
          <span className="ml-auto text-xs font-medium px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">
            Optional
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
          {/* Auto mode card */}
          <button
            onClick={() => { setMode('auto'); setAutoInferred(false); }}
            className={`text-left p-4 rounded-xl border-2 transition-all duration-150 ${
              mode === 'auto' && !autoInferred ?'border-primary bg-blue-50' :'border-border hover:border-primary/50 hover:bg-muted'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <Wand2 size={16} className={mode === 'auto' && !autoInferred ? 'text-primary' : 'text-muted-foreground'} />
              <span className={`text-sm font-semibold ${mode === 'auto' && !autoInferred ? 'text-primary' : 'text-foreground'}`}>
                AI Infer from XML
              </span>
              {mode === 'auto' && !autoInferred && (
                <span className="ml-auto text-xs font-bold text-primary">SELECTED</span>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              AI will infer the source legacy structure from the XML template during generation. Recommended if you don&apos;t have source system documentation.
            </p>
          </button>

          {/* Manual mode card */}
          <button
            onClick={() => setMode('manual')}
            className={`text-left p-4 rounded-xl border-2 transition-all duration-150 ${
              mode === 'manual' || autoInferred ?'border-primary bg-blue-50' :'border-border hover:border-primary/50 hover:bg-muted'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <Table2 size={16} className={mode === 'manual' || autoInferred ? 'text-primary' : 'text-muted-foreground'} />
              <span className={`text-sm font-semibold ${mode === 'manual' || autoInferred ? 'text-primary' : 'text-foreground'}`}>
                Enter Manually
              </span>
              {(mode === 'manual' || autoInferred) && (
                <span className="ml-auto text-xs font-bold text-primary">SELECTED</span>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              Provide your source system field definitions. You can also use &quot;Pre-fill from XML&quot; to start with target fields and adjust.
            </p>
          </button>
        </div>

        {/* Auto-fill from XML helper */}
        {(mode === 'manual') && (
          <div className="flex items-center gap-3 p-3 rounded-lg border border-border bg-muted mb-4 animate-fadeIn">
            <Info size={14} className="text-accent flex-shrink-0" />
            <p className="text-xs text-muted-foreground flex-1">
              Pre-fill the table with field names inferred from the XML template (from <strong className="text-foreground">{xmlFileName}</strong> — {parsed.fields.length} fields detected), then edit as needed.
            </p>
            <button onClick={handleAutoInfer} className="btn-secondary text-xs py-1.5 px-3 flex-shrink-0">
              <Wand2 size={13} />
              Pre-fill from XML
            </button>
          </div>
        )}

        {autoInferred && (
          <div className="flex items-center gap-2 p-3 rounded-lg border border-green-200 bg-success-bg mb-4 animate-fadeIn">
            <CheckCircle2 size={14} className="text-success" />
            <p className="text-xs text-success font-medium">
              {fields.length} fields pre-filled from XML. Edit table names, descriptions, and data types to match your source system.
            </p>
          </div>
        )}

        {/* Manual table */}
        {(mode === 'manual' || autoInferred) && (
          <div className="animate-fadeIn">
            <div className="overflow-x-auto scrollbar-thin rounded-lg border border-border">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-secondary">
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground w-8">#</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground min-w-[130px]">Table Name</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground min-w-[160px]">Table Description</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground min-w-[120px]">Field Name</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground min-w-[180px]">Field Description</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground min-w-[200px]">
                      Data Type / Length / Decimal
                      <span className="block text-[10px] font-normal text-muted-foreground/70">e.g. CHAR / 10 / 0</span>
                    </th>
                    <th className="px-3 py-2.5 w-10"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {fields.length === 0 && (
                    <tr>
                      <td colSpan={7} className="px-4 py-8 text-center text-muted-foreground">
                        No source fields added yet. Click &quot;Add Row&quot; or use &quot;Pre-fill from XML&quot;.
                      </td>
                    </tr>
                  )}
                  {fields.map((field, idx) => (
                    <tr key={field.id} className="hover:bg-muted/60 transition-colors">
                      <td className="px-3 py-1.5 text-muted-foreground font-tabular">{idx + 1}</td>
                      <td className="px-2 py-1.5">
                        <input
                          className="input-field py-1 text-xs"
                          value={field.tableName}
                          onChange={(e) => handleChange(field.id, 'tableName', e.target.value)}
                          placeholder="EKKO"
                          aria-label="Table name"
                        />
                      </td>
                      <td className="px-2 py-1.5">
                        <input
                          className="input-field py-1 text-xs"
                          value={field.tableDescription}
                          onChange={(e) => handleChange(field.id, 'tableDescription', e.target.value)}
                          placeholder="Purchasing Document Header"
                          aria-label="Table description"
                        />
                      </td>
                      <td className="px-2 py-1.5">
                        <input
                          className="input-field py-1 text-xs font-mono uppercase"
                          value={field.fieldName}
                          onChange={(e) => handleChange(field.id, 'fieldName', e.target.value.toUpperCase())}
                          placeholder="LIFNR"
                          aria-label="Field name"
                        />
                      </td>
                      <td className="px-2 py-1.5">
                        <input
                          className="input-field py-1 text-xs"
                          value={field.fieldDescription}
                          onChange={(e) => handleChange(field.id, 'fieldDescription', e.target.value)}
                          placeholder="Vendor Account Number"
                          aria-label="Field description"
                        />
                      </td>
                      {/* Combined Data Type / Length / Decimal */}
                      <td className="px-2 py-1.5">
                        <div className="flex items-center gap-1">
                          <select
                            className="select-field py-1 text-xs flex-1 min-w-[80px]"
                            value={field.dataType}
                            onChange={(e) => handleChange(field.id, 'dataType', e.target.value)}
                            aria-label="Data type"
                          >
                            {DATA_TYPES.map((dt) => (
                              <option key={`dt-${dt}`} value={dt}>{dt}</option>
                            ))}
                          </select>
                          <span className="text-muted-foreground text-xs">/</span>
                          <input
                            className="input-field py-1 text-xs font-tabular w-14"
                            value={field.length}
                            onChange={(e) => handleChange(field.id, 'length', e.target.value)}
                            placeholder="Len"
                            aria-label="Length"
                          />
                          <span className="text-muted-foreground text-xs">/</span>
                          <input
                            className="input-field py-1 text-xs font-tabular w-14"
                            value={field.decimal}
                            onChange={(e) => handleChange(field.id, 'decimal', e.target.value)}
                            placeholder="Dec"
                            aria-label="Decimal"
                          />
                        </div>
                      </td>
                      <td className="px-2 py-1.5 text-center">
                        <button
                          onClick={() => handleRemoveRow(field.id)}
                          className="p-1 rounded-md text-muted-foreground hover:text-danger hover:bg-danger/10 transition-colors"
                          aria-label={`Remove row ${idx + 1}`}
                        >
                          <Trash2 size={13} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <button
              onClick={handleAddRow}
              className="mt-3 btn-ghost text-xs"
            >
              <Plus size={14} />
              Add Row
            </button>
          </div>
        )}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="btn-secondary">
          <ArrowLeft size={15} />
          Back to Upload
        </button>
        <button onClick={handleProceed} className="btn-primary">
          Continue to Project Details
          <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
}