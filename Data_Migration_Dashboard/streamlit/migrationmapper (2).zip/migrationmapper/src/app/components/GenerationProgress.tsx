'use client';

import React from 'react';
import { Loader2, CheckCircle2 } from 'lucide-react';

interface Props {
  progressLog: string[];
}

export default function GenerationProgress({ progressLog }: Props) {
  const isComplete = progressLog.some((l) => l.startsWith('✓'));

  return (
    <div className="card-panel p-10 max-w-xl mx-auto">
      <div className="flex flex-col items-center text-center mb-8">
        <div
          className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center mb-4"
        >
          {isComplete ? (
            <CheckCircle2 size={28} className="text-white" />
          ) : (
            <Loader2 size={28} className="text-white animate-spin" />
          )}
        </div>
        <h2 className="text-xl font-semibold text-foreground mb-1">
          {isComplete ? 'Generation Complete' : 'Generating Mapping Sheet'}
        </h2>
        <p className="text-sm text-muted-foreground">
          {isComplete
            ? 'All field mappings have been generated successfully.' :'Parsing XML and applying AI-powered mapping rules...'}
        </p>
      </div>

      {/* Progress log */}
      <div className="space-y-2">
        {progressLog.map((log, idx) => {
          const isDone = log.startsWith('✓');
          return (
            <div
              key={`log-${idx + 1}`}
              className="flex items-center gap-3 animate-fadeIn"
              style={{ animationDelay: `${idx * 80}ms` }}
            >
              {isDone ? (
                <CheckCircle2 size={14} className="text-success flex-shrink-0" />
              ) : idx === progressLog.length - 1 && !isComplete ? (
                <Loader2 size={14} className="text-accent flex-shrink-0 animate-spin" />
              ) : (
                <CheckCircle2 size={14} className="text-muted-foreground flex-shrink-0" />
              )}
              <span className={`text-sm ${isDone ? 'text-success font-medium' : 'text-foreground'}`}>
                {log}
              </span>
            </div>
          );
        })}
        {progressLog.length === 0 && (
          <div className="flex items-center gap-3">
            <Loader2 size={14} className="text-accent animate-spin" />
            <span className="text-sm text-muted-foreground">Initialising...</span>
          </div>
        )}
      </div>

      {/* Progress bar */}
      {!isComplete && (
        <div className="mt-6 h-1.5 bg-secondary rounded-full overflow-hidden">
          <div
            className="h-full gradient-primary rounded-full progress-bar-fill"
            style={{
              width: `${Math.min((progressLog.length / 7) * 100, 90)}%`,
            }}
          />
        </div>
      )}
    </div>
  );
}