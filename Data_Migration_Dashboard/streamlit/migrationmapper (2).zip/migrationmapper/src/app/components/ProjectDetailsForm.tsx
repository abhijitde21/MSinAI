'use client';

import React, { useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import type { ProjectDetails } from '@/lib/mappingStore';
import { FolderOpen, ArrowLeft, Sparkles, Upload, User, Building2, CalendarDays, Loader2,  } from 'lucide-react';
import AppImage from '@/components/ui/AppImage';

interface Props {
  onSubmit: (details: ProjectDetails) => void;
  onBack: () => void;
  initialValues: ProjectDetails | null;
}

const PROCESS_AREAS = ['FI – Finance', 'CO – Controlling', 'MM – Materials Management', 'SD – Sales & Distribution', 'PP – Production Planning', 'HR – Human Resources', 'PS – Project System', 'PM – Plant Maintenance', 'QM – Quality Management', 'WM – Warehouse Management', 'RE – Real Estate', 'TR – Treasury'];

const TODAY = new Date().toISOString().slice(0, 10);

export default function ProjectDetailsForm({ onSubmit, onBack, initialValues }: Props) {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ProjectDetails>({
    defaultValues: initialValues || {
      projectName: '',
      processArea: '',
      phase: '',
      objectName: '',
      clientName: '',
      sourceSystem: '',
      dmConsultant: '',
      functionalOwner: '',
      businessOwner: '',
      createdDate: TODAY,
    },
  });

  const [clientLogoDataUrl, setClientLogoDataUrl] = useState<string>(initialValues?.clientLogoDataUrl || '');
  const [partnerLogoDataUrl, setPartnerLogoDataUrl] = useState<string>(initialValues?.partnerLogoDataUrl || '');
  const clientLogoRef = useRef<HTMLInputElement>(null);
  const partnerLogoRef = useRef<HTMLInputElement>(null);

  const handleLogoUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (v: string) => void
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => setter(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const onFormSubmit = (data: ProjectDetails) => {
    onSubmit({
      ...data,
      clientLogoDataUrl,
      partnerLogoDataUrl,
    });
  };

  return (
    <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-5">
      {/* Project Information */}
      <div className="card-panel p-6">
        <div className="flex items-center gap-2 mb-5">
          <FolderOpen size={18} className="text-primary" />
          <h2 className="section-header">Project Information</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {/* Project Name */}
          <div className="xl:col-span-2">
            <label className="label-field" htmlFor="projectName">
              Project Name <span className="text-danger">*</span>
            </label>
            <p className="helper-text mb-1">Full engagement or project name as it will appear on the mapping sheet header.</p>
            <input
              id="projectName"
              className="input-field"
              placeholder="Acme Corp SAP S/4HANA 2023 Go-Live"
              {...register('projectName', { required: 'Project name is required.' })}
            />
            {errors.projectName && <p className="error-text">{errors.projectName.message}</p>}
          </div>

          {/* Process Area */}
          <div>
            <label className="label-field" htmlFor="processArea">
              Process Area <span className="text-danger">*</span>
            </label>
            <p className="helper-text mb-1">SAP functional module for this migration object.</p>
            <div className="relative">
              <select
                id="processArea"
                className="select-field"
                {...register('processArea', { required: 'Process area is required.' })}
              >
                <option value="">Select process area...</option>
                {PROCESS_AREAS.map((pa) => (
                  <option key={`pa-${pa}`} value={pa}>{pa}</option>
                ))}
              </select>
            </div>
            {errors.processArea && <p className="error-text">{errors.processArea.message}</p>}
          </div>

          {/* Object Name */}
          <div>
            <label className="label-field" htmlFor="objectName">
              Migration Object Name <span className="text-danger">*</span>
            </label>
            <p className="helper-text mb-1">As named in SAP Migration Cockpit (e.g. BusinessPartner, Material).</p>
            <input
              id="objectName"
              className="input-field"
              placeholder="BusinessPartner"
              {...register('objectName', { required: 'Object name is required.' })}
            />
            {errors.objectName && <p className="error-text">{errors.objectName.message}</p>}
          </div>

          {/* Source System */}
          <div>
            <label className="label-field" htmlFor="sourceSystem">
              Source System <span className="text-danger">*</span>
            </label>
            <p className="helper-text mb-1">Legacy source system name (e.g. SAP ECC, Oracle, Legacy ERP).</p>
            <input
              id="sourceSystem"
              className="input-field"
              placeholder="SAP ECC 6.0"
              {...register('sourceSystem', { required: 'Source system is required.' })}
            />
            {errors.sourceSystem && <p className="error-text">{errors.sourceSystem.message}</p>}
          </div>

          {/* Created Date */}
          <div>
            <label className="label-field" htmlFor="createdDate">
              <CalendarDays size={13} className="inline mr-1" />
              Created Date
            </label>
            <p className="helper-text mb-1">Auto-populated with today&apos;s date.</p>
            <input
              id="createdDate"
              type="date"
              className="input-field"
              {...register('createdDate')}
            />
          </div>
        </div>
      </div>

      {/* Team / Ownership */}
      <div className="card-panel p-6">
        <div className="flex items-center gap-2 mb-5">
          <User size={18} className="text-primary" />
          <h2 className="section-header">Team & Ownership</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div>
            <label className="label-field" htmlFor="dmConsultant">
              DM Consultant <span className="text-danger">*</span>
            </label>
            <p className="helper-text mb-1">Data Migration consultant responsible for this mapping.</p>
            <input
              id="dmConsultant"
              className="input-field"
              placeholder="Priya Sharma"
              {...register('dmConsultant', { required: 'DM Consultant name is required.' })}
            />
            {errors.dmConsultant && <p className="error-text">{errors.dmConsultant.message}</p>}
          </div>

          <div>
            <label className="label-field" htmlFor="functionalOwner">
              Functional Owner
            </label>
            <p className="helper-text mb-1">SAP functional consultant who owns the business process.</p>
            <input
              id="functionalOwner"
              className="input-field"
              placeholder="Rajesh Nair"
              {...register('functionalOwner')}
            />
          </div>

          <div>
            <label className="label-field" htmlFor="businessOwner">
              Business Owner
            </label>
            <p className="helper-text mb-1">Client-side business owner accountable for data quality.</p>
            <input
              id="businessOwner"
              className="input-field"
              placeholder="Sarah Mitchell"
              {...register('businessOwner')}
            />
          </div>
        </div>
      </div>

      {/* Logos */}
      <div className="card-panel p-6">
        <div className="flex items-center gap-2 mb-5">
          <Building2 size={18} className="text-primary" />
          <h2 className="section-header">Branding Logos</h2>
          <span className="ml-1 text-xs font-medium px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">
            Embedded in Excel export
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Client Logo */}
          <div>
            <label className="label-field">Client Logo</label>
            <p className="helper-text mb-3">PNG or JPEG, recommended 200×60px or wider. Will appear in the export header.</p>
            <input
              ref={clientLogoRef}
              type="file"
              accept="image/png,image/jpeg,image/jpg,image/svg+xml"
              className="hidden"
              onChange={(e) => handleLogoUpload(e, setClientLogoDataUrl)}
              aria-label="Upload client logo"
            />
            {clientLogoDataUrl ? (
              <div className="relative rounded-lg border border-border p-4 bg-muted flex items-center gap-3">
                <AppImage
                  src={clientLogoDataUrl}
                  alt="Uploaded client logo preview"
                  width={120}
                  height={40}
                  className="h-10 w-auto object-contain"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-foreground">Client logo uploaded</p>
                  <button
                    type="button"
                    onClick={() => { setClientLogoDataUrl(''); if (clientLogoRef.current) clientLogoRef.current.value = ''; }}
                    className="text-xs text-danger hover:underline mt-0.5"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => clientLogoRef.current?.click()}
                className="w-full border-2 border-dashed border-border rounded-lg p-5 flex flex-col items-center gap-2 hover:border-primary hover:bg-muted transition-all duration-150"
              >
                <Upload size={20} className="text-muted-foreground" />
                <span className="text-sm font-medium text-muted-foreground">Upload Client Logo</span>
                <span className="text-xs text-muted-foreground">PNG, JPEG or SVG</span>
              </button>
            )}
          </div>

          {/* Partner Logo */}
          <div>
            <label className="label-field">Partner / Consulting Firm Logo</label>
            <p className="helper-text mb-3">Your consulting firm or SI partner logo. Will appear alongside the client logo in the export.</p>
            <input
              ref={partnerLogoRef}
              type="file"
              accept="image/png,image/jpeg,image/jpg,image/svg+xml"
              className="hidden"
              onChange={(e) => handleLogoUpload(e, setPartnerLogoDataUrl)}
              aria-label="Upload partner logo"
            />
            {partnerLogoDataUrl ? (
              <div className="relative rounded-lg border border-border p-4 bg-muted flex items-center gap-3">
                <AppImage
                  src={partnerLogoDataUrl}
                  alt="Uploaded partner logo preview"
                  width={120}
                  height={40}
                  className="h-10 w-auto object-contain"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-foreground">Partner logo uploaded</p>
                  <button
                    type="button"
                    onClick={() => { setPartnerLogoDataUrl(''); if (partnerLogoRef.current) partnerLogoRef.current.value = ''; }}
                    className="text-xs text-danger hover:underline mt-0.5"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => partnerLogoRef.current?.click()}
                className="w-full border-2 border-dashed border-border rounded-lg p-5 flex flex-col items-center gap-2 hover:border-primary hover:bg-muted transition-all duration-150"
              >
                <Upload size={20} className="text-muted-foreground" />
                <span className="text-sm font-medium text-muted-foreground">Upload Partner Logo</span>
                <span className="text-xs text-muted-foreground">PNG, JPEG or SVG</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between">
        <button type="button" onClick={onBack} className="btn-secondary">
          <ArrowLeft size={15} />
          Back to Source Metadata
        </button>
        <button type="submit" className="btn-primary" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 size={15} className="animate-spin" />
              <span>Preparing...</span>
            </>
          ) : (
            <>
              <Sparkles size={15} />
              Generate Mapping Sheet
            </>
          )}
        </button>
      </div>
    </form>
  );
}