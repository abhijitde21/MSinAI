'use client';

import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import {
  Upload,
  FileCode2,
  X,
  CheckCircle2,
  AlertCircle,
  Info,
  ArrowRight,
} from 'lucide-react';

interface XmlUploadZoneProps {
  onUploaded: (content: string, fileName: string) => void;
}

export default function XmlUploadZone({ onUploaded }: XmlUploadZoneProps) {
  const [file, setFile] = useState<File | null>(null);
  const [content, setContent] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [preview, setPreview] = useState<string>('');

  const onDrop = useCallback((acceptedFiles: File[], rejectedFiles: { file: File; errors: { code: string }[] }[]) => {
    setError('');

    if (rejectedFiles.length > 0) {
      const err = rejectedFiles[0].errors[0];
      if (err.code === 'file-too-large') {
        setError('File exceeds 10MB limit. SAP Migration Cockpit XML files are typically under 1MB.');
      } else if (err.code === 'file-invalid-type') {
        setError('Only XML files (.xml) are accepted. Please upload a SAP Migration Cockpit XML template.');
      } else {
        setError('File rejected. Please upload a valid XML file.');
      }
      return;
    }

    const uploaded = acceptedFiles[0];
    if (!uploaded) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (!text.trim().startsWith('<') && !text.trim().startsWith('<?xml')) {
        setError('This file does not appear to be a valid XML file. Please upload a SAP Migration Cockpit XML template.');
        return;
      }
      setFile(uploaded);
      setContent(text);
      setPreview(text.slice(0, 500));
      setError('');
    };
    reader.readAsText(uploaded);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'text/xml': ['.xml'], 'application/xml': ['.xml'] },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024,
  });

  const handleClear = () => {
    setFile(null);
    setContent('');
    setPreview('');
    setError('');
  };

  const handleProceed = () => {
    if (content && file) {
      onUploaded(content, file.name);
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
      {/* Upload area */}
      <div className="xl:col-span-2 space-y-4">
        <div className="card-panel p-5">
          <div className="flex items-center gap-2 mb-4">
            <FileCode2 size={18} className="text-primary" />
            <h2 className="section-header">SAP Migration Cockpit XML Template</h2>
          </div>

          {!file ? (
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-xl p-10 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-200 ${
                isDragActive
                  ? 'xml-dropzone-active border-accent' :'border-border hover:border-primary hover:bg-muted'
              }`}
              role="button"
              aria-label="Upload SAP Migration Cockpit XML file"
            >
              <input {...getInputProps()} />
              <div
                className={`w-14 h-14 rounded-xl flex items-center justify-center mb-4 transition-all duration-200 ${
                  isDragActive ? 'bg-accent/10' : 'bg-primary/8'
                }`}
                style={{ backgroundColor: isDragActive ? 'rgba(14,165,233,0.1)' : 'rgba(30,64,175,0.08)' }}
              >
                <Upload
                  size={26}
                  className={isDragActive ? 'text-accent' : 'text-primary'}
                />
              </div>
              {isDragActive ? (
                <p className="text-base font-semibold text-accent">Drop XML file here</p>
              ) : (
                <>
                  <p className="text-base font-semibold text-foreground mb-1">
                    Drop XML file here, or click to browse
                  </p>
                  <p className="text-sm text-muted-foreground mb-3">
                    Supports SAP Migration Cockpit XML templates (.xml) up to 10MB
                  </p>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/8 text-primary text-xs font-semibold"
                    style={{ backgroundColor: 'rgba(30,64,175,0.08)' }}
                  >
                    <FileCode2 size={12} />
                    .xml files only
                  </div>
                </>
              )}
            </div>
          ) : (
            <div className="rounded-xl border border-border overflow-hidden">
              {/* File info bar */}
              <div className="flex items-center gap-3 px-4 py-3 bg-success-bg border-b border-border">
                <CheckCircle2 size={18} className="text-success flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate">{file.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {(file.size / 1024).toFixed(1)} KB — XML Template
                  </p>
                </div>
                <button
                  onClick={handleClear}
                  className="p-1.5 rounded-md hover:bg-red-100 text-muted-foreground hover:text-danger transition-colors"
                  aria-label="Remove uploaded file"
                >
                  <X size={15} />
                </button>
              </div>
              {/* XML preview */}
              <div className="bg-gray-950 p-4 overflow-x-auto scrollbar-thin">
                <pre className="text-xs text-green-400 font-mono leading-relaxed whitespace-pre-wrap break-all">
                  {preview}
                  {content.length > 500 && (
                    <span className="text-gray-500">
                      {'\n'}... ({content.length - 500} more characters)
                    </span>
                  )}
                </pre>
              </div>
            </div>
          )}

          {error && (
            <div className="mt-3 flex items-start gap-2 p-3 rounded-lg border border-red-200 bg-danger-bg animate-fadeIn">
              <AlertCircle size={15} className="text-danger flex-shrink-0 mt-0.5" />
              <p className="text-sm text-danger">{error}</p>
            </div>
          )}
        </div>

        {/* Proceed button */}
        {file && !error && (
          <div className="flex justify-end animate-fadeIn">
            <button onClick={handleProceed} className="btn-primary">
              Continue to Source Metadata
              <ArrowRight size={16} />
            </button>
          </div>
        )}
      </div>

      {/* Info panel */}
      <div className="space-y-4">
        <div className="card-panel p-5">
          <div className="flex items-center gap-2 mb-3">
            <Info size={15} className="text-accent" />
            <h3 className="text-sm font-semibold text-foreground">About Migration Cockpit XML</h3>
          </div>
          <div className="space-y-3 text-sm text-muted-foreground">
            <p>
              Export your XML template from SAP Migration Cockpit (LTMC/LTMOM) by navigating to your migration object and selecting <strong className="text-foreground">Download Template</strong>.
            </p>
            <p>
              The template defines the target structure including field names, data types, lengths, and mandatory flags for the SAP S/4HANA target system.
            </p>
          </div>
        </div>

        <div className="card-panel p-5">
          <h3 className="text-sm font-semibold text-foreground mb-3">Supported SAP Objects</h3>
          <div className="space-y-1.5">
            {[
              'Business Partner (Customer/Vendor)',
              'Material Master',
              'Chart of Accounts / GL Accounts',
              'Cost Centers & Profit Centers',
              'Open Items (AR/AP)',
              'Fixed Assets',
              'Purchase Orders & Contracts',
              'Sales Orders',
              'Employee Master (HCM)',
              'Custom Migration Objects',
            ].map((obj) => (
              <div key={`obj-${obj.replace(/\s/g, '-')}`} className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
                <span className="text-xs text-muted-foreground">{obj}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="card-panel p-4 border-amber-200" style={{ backgroundColor: 'var(--warning-bg)' }}>
          <div className="flex items-start gap-2">
            <AlertCircle size={14} className="text-warning flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-semibold text-warning mb-1">Demo Mode Active</p>
              <p className="text-xs text-warning">
                AI generation uses a local rules engine. Connect OpenAI API key in environment variables for full AI-powered mapping inference.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}