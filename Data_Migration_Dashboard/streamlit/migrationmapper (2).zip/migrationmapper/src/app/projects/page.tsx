'use client';

import React, { useState, useEffect, useRef } from 'react';
import AppLayout from '@/components/AppLayout';
import { getProjectCatalogue, deleteIterationFromCatalogue, deleteProjectFromCatalogue, loadIterationAsSession, getProjectStatuses, saveProjectStatus, type ProjectCatalogueEntry, type MappingIteration, type StandaloneProject,  } from '@/lib/mappingStore';
import { useRouter } from 'next/navigation';
import { FolderOpen, Play, GitBranch, Download, ChevronDown, ChevronRight, Calendar, FileText, User, Clock, AlertTriangle, Eye, X, CheckCircle2, Circle, AlertCircle, PauseCircle, Building2, Server, Database, Package, Tag, Layers, Plus, Pencil, Trash2, Filter, FileSpreadsheet, RefreshCw,  } from 'lucide-react';
import { generateMappingExcel } from '@/lib/excelExporter';

type MappingStatus = 'In Progress' | 'Completed' | 'On Hold' | 'Review Pending';

const STATUS_OPTIONS: MappingStatus[] = ['In Progress', 'Completed', 'On Hold', 'Review Pending'];

const STATUS_STYLES: Record<MappingStatus, { bg: string; text: string; icon: React.ReactNode }> = {
  'In Progress': {
    bg: 'bg-blue-500/10 text-blue-400 border border-blue-500/20',
    text: 'text-blue-400',
    icon: <Circle size={11} className="text-blue-400" />,
  },
  Completed: {
    bg: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20',
    text: 'text-emerald-400',
    icon: <CheckCircle2 size={11} className="text-emerald-400" />,
  },
  'On Hold': {
    bg: 'bg-amber-500/10 text-amber-400 border border-amber-500/20',
    text: 'text-amber-400',
    icon: <PauseCircle size={11} className="text-amber-400" />,
  },
  'Review Pending': {
    bg: 'bg-purple-500/10 text-purple-400 border border-purple-500/20',
    text: 'text-purple-400',
    icon: <AlertCircle size={11} className="text-purple-400" />,
  },
};

// ── Types ──────────────────────────────────────────────────────────────────────

interface ObjectRow {
  objectName: string;
  processArea: string;
  sourceSystem: string;
  iterations: MappingIteration[];
  latestIteration: MappingIteration;
  entry: ProjectCatalogueEntry;
}

interface ProjectGroup {
  entry: ProjectCatalogueEntry;
  objects: ObjectRow[];
  totalObjects: number;
  statusCounts: Record<MappingStatus, number>;
}

// ── Helpers ────────────────────────────────────────────────────────────────────

function buildProjectGroups(
  catalogue: ProjectCatalogueEntry[],
  statuses: Record<string, MappingStatus>
): ProjectGroup[] {
  return catalogue.map((entry) => {
    const objectMap = new Map<string, MappingIteration[]>();
    for (const iter of entry.iterations) {
      const key = iter.objectName || 'Unknown Object';
      if (!objectMap.has(key)) objectMap.set(key, []);
      objectMap.get(key)!.push(iter);
    }

    const objects: ObjectRow[] = Array.from(objectMap.entries()).map(([objectName, iters]) => ({
      objectName,
      processArea: entry.projectDetails.processArea || 'General',
      sourceSystem: entry.projectDetails.sourceSystem || entry.projectDetails.sourceSystems?.[0] || '—',
      iterations: iters,
      latestIteration: iters[iters.length - 1],
      entry,
    }));

    const statusCounts: Record<MappingStatus, number> = {
      'In Progress': 0,
      Completed: 0,
      'On Hold': 0,
      'Review Pending': 0,
    };
    for (const obj of objects) {
      const key = `${entry.projectId}__${obj.objectName}`;
      const s: MappingStatus = (statuses[key] as MappingStatus) || 'In Progress';
      statusCounts[s]++;
    }

    return { entry, objects, totalObjects: objectMap.size, statusCounts };
  });
}

// ── Versions Modal ─────────────────────────────────────────────────────────────

interface VersionsModalProps {
  objectName: string;
  iterations: MappingIteration[];
  entry: ProjectCatalogueEntry;
  onClose: () => void;
  onLoad: (entry: ProjectCatalogueEntry, iter: MappingIteration) => void;
}

function VersionsModal({ objectName, iterations, entry, onClose, onLoad }: VersionsModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="card-panel w-full max-w-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div>
            <p className="text-sm font-semibold text-foreground">{objectName}</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              {entry.projectDetails.projectName} — {iterations.length} version{iterations.length !== 1 ? 's' : ''}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors"
          >
            <X size={16} />
          </button>
        </div>
        <div className="divide-y divide-border max-h-80 overflow-y-auto">
          {iterations.map((iter, idx) => (
            <div
              key={iter.iterationId}
              className="flex items-center gap-3 px-5 py-3 hover:bg-muted/20 transition-colors group"
            >
              <div className="w-7 h-7 rounded-md bg-secondary flex items-center justify-center flex-shrink-0 text-xs font-bold text-muted-foreground">
                v{idx + 1}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">{iter.objectName}</p>
                <div className="flex items-center gap-3 mt-0.5">
                  <span className="flex items-center gap-1 text-xs text-muted-foreground">
                    <FileText size={10} />
                    {iter.xmlFileName}
                  </span>
                  <span className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar size={10} />
                    {iter.generatedAt}
                  </span>
                  <span className="text-xs text-muted-foreground">{iter.mappings.length} fields</span>
                </div>
              </div>
              <button
                onClick={() => onLoad(entry, iter)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium bg-primary/10 text-primary hover:bg-primary hover:text-white transition-colors opacity-0 group-hover:opacity-100"
              >
                <Eye size={11} />
                Load
              </button>
            </div>
          ))}
        </div>
        <div className="px-5 py-3 border-t border-border flex justify-end">
          <button onClick={onClose} className="btn-secondary text-sm">
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Edit Project Modal ─────────────────────────────────────────────────────────

interface EditProjectModalProps {
  entry: ProjectCatalogueEntry;
  onSave: (projectId: string, updates: { projectName: string; clientName: string; dmConsultant: string }) => void;
  onClose: () => void;
}

function EditProjectModal({ entry, onSave, onClose }: EditProjectModalProps) {
  const pd = entry.projectDetails;
  const [projectName, setProjectName] = useState(pd.projectName || '');
  const [clientName, setClientName] = useState(pd.clientName || '');
  const [dmConsultant, setDmConsultant] = useState(pd.dmConsultant || '');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!projectName.trim()) errs.projectName = 'Project name is required.';
    if (!clientName.trim()) errs.clientName = 'Client name is required.';
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    onSave(entry.projectId, { projectName, clientName, dmConsultant });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="card-panel w-full max-w-md overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Pencil size={14} className="text-primary" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">Edit Project</p>
              <p className="text-xs text-muted-foreground">Update project details</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors">
            <X size={16} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="px-5 py-5 space-y-4">
          <div>
            <label className="label-field">Project Name <span className="text-danger">*</span></label>
            <input className="input-field" value={projectName} onChange={(e) => setProjectName(e.target.value)} placeholder="Project name" />
            {errors.projectName && <p className="error-text">{errors.projectName}</p>}
          </div>
          <div>
            <label className="label-field">Client Name <span className="text-danger">*</span></label>
            <input className="input-field" value={clientName} onChange={(e) => setClientName(e.target.value)} placeholder="Client name" />
            {errors.clientName && <p className="error-text">{errors.clientName}</p>}
          </div>
          <div>
            <label className="label-field">DM Consultant</label>
            <input className="input-field" value={dmConsultant} onChange={(e) => setDmConsultant(e.target.value)} placeholder="Consultant name" />
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={onClose} className="btn-secondary text-sm">Cancel</button>
            <button type="submit" className="btn-primary text-sm">Save Changes</button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ── Edit Object Modal ──────────────────────────────────────────────────────────

interface EditObjectModalProps {
  obj: ObjectRow;
  onSave: (objectName: string, newObjectName: string, newProcessArea: string) => void;
  onClose: () => void;
}

function EditObjectModal({ obj, onSave, onClose }: EditObjectModalProps) {
  const [objectName, setObjectName] = useState(obj.objectName);
  const [processArea, setProcessArea] = useState(obj.processArea);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!objectName.trim()) errs.objectName = 'Object name is required.';
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    onSave(obj.objectName, objectName, processArea);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="card-panel w-full max-w-md overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Pencil size={14} className="text-primary" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">Update Object</p>
              <p className="text-xs text-muted-foreground">Edit object name and process area</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors">
            <X size={16} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="px-5 py-5 space-y-4">
          <div>
            <label className="label-field">Object Name <span className="text-danger">*</span></label>
            <input className="input-field" value={objectName} onChange={(e) => setObjectName(e.target.value)} placeholder="Object name" />
            {errors.objectName && <p className="error-text">{errors.objectName}</p>}
          </div>
          <div>
            <label className="label-field">Process Area</label>
            <input className="input-field" value={processArea} onChange={(e) => setProcessArea(e.target.value)} placeholder="e.g. Finance, HR, Logistics" />
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={onClose} className="btn-secondary text-sm">Cancel</button>
            <button type="submit" className="btn-primary text-sm">Update Object</button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ── Status Badge ───────────────────────────────────────────────────────────────

interface StatusBadgeProps {
  statusKey: string;
  statuses: Record<string, MappingStatus>;
  onStatusChange: (key: string, status: MappingStatus) => void;
}

function StatusBadge({ statusKey, statuses, onStatusChange }: StatusBadgeProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const currentStatus: MappingStatus = (statuses[statusKey] as MappingStatus) || 'In Progress';
  const style = STATUS_STYLES[currentStatus];

  useEffect(() => {
    function handleOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium cursor-pointer hover:opacity-80 transition-opacity ${style.bg}`}
      >
        {style.icon}
        <span>{currentStatus}</span>
        <ChevronDown size={10} className="ml-0.5 opacity-60" />
      </button>
      {open && (
        <div className="absolute left-0 top-full mt-1 z-30 card-panel shadow-dropdown py-1 min-w-[160px]">
          {STATUS_OPTIONS.map((opt) => {
            const s = STATUS_STYLES[opt];
            return (
              <button
                key={opt}
                onClick={() => {
                  onStatusChange(statusKey, opt);
                  setOpen(false);
                }}
                className={`w-full flex items-center gap-2 px-3 py-2 text-xs font-medium hover:bg-muted/30 transition-colors text-left ${opt === currentStatus ? 'bg-muted/20' : ''}`}
              >
                {s.icon}
                <span className={s.text}>{opt}</span>
                {opt === currentStatus && <CheckCircle2 size={10} className="ml-auto text-primary" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── Download Dropdown ──────────────────────────────────────────────────────────

interface DownloadDropdownProps {
  onDownloadExcel: () => void;
  onDownloadCsv: () => void;
}

function DownloadDropdown({ onDownloadExcel, onDownloadCsv }: DownloadDropdownProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        title="Download"
        className="flex items-center gap-1 px-2 py-1.5 rounded-md text-xs font-medium bg-secondary text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors whitespace-nowrap"
      >
        <Download size={10} />
        <span>Download</span>
        <ChevronDown size={9} className="ml-0.5 opacity-60" />
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-1 z-30 card-panel shadow-dropdown py-1 min-w-[160px]">
          <button
            onClick={() => { onDownloadExcel(); setOpen(false); }}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium hover:bg-muted/30 transition-colors text-left text-foreground"
          >
            <FileSpreadsheet size={12} className="text-emerald-400" />
            Download Excel
          </button>
          <button
            onClick={() => { onDownloadCsv(); setOpen(false); }}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium hover:bg-muted/30 transition-colors text-left text-foreground"
          >
            <FileText size={12} className="text-blue-400" />
            Download CSV
          </button>
        </div>
      )}
    </div>
  );
}

// ── CSV Export Helper ──────────────────────────────────────────────────────────

function exportAsCsv(entry: ProjectCatalogueEntry, iter: MappingIteration) {
  const headers = [
    'Seq', 'Source Table', 'Source Field', 'Source Description', 'Source Type/Len/Dec',
    'Target View', 'Target Field', 'Target Description', 'Target Type/Len/Dec',
    'Transformation Type', 'Transformation Rule', 'Mandatory', 'Migration Required',
  ];
  const rows = iter.mappings.map((m) => [
    m.seq,
    m.source.tableName,
    m.source.fieldName,
    m.source.fieldDescription,
    `${m.source.dataType}/${m.source.length}/${m.source.decimal}`,
    m.target.targetViewName,
    m.target.targetFieldName,
    m.target.targetFieldDescription,
    `${m.target.targetFieldDataType}/${m.target.targetFieldLength}/${m.target.targetFieldDecimal}`,
    m.target.transformationType,
    m.target.transformationRule,
    m.target.mandatory,
    m.target.migrationRequired,
  ]);

  const csvContent = [headers, ...rows]
    .map((row) => row.map((cell) => `"${String(cell ?? '').replace(/"/g, '""')}"`).join(','))
    .join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${entry.projectDetails.projectName}_${iter.objectName}_mapping.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ── Main Page ──────────────────────────────────────────────────────────────────

export default function ProjectsPage() {
  return (
    <AppLayout>
      <ProjectsContent />
    </AppLayout>
  );
}

function ProjectsContent() {
  const router = useRouter();
  const [catalogue, setCatalogue] = useState<ProjectCatalogueEntry[]>([]);
  const [statuses, setStatuses] = useState<Record<string, MappingStatus>>({});
  const [expandedProjects, setExpandedProjects] = useState<Set<string>>(new Set());

  // Modals
  const [versionsModal, setVersionsModal] = useState<{
    objectName: string;
    iterations: MappingIteration[];
    entry: ProjectCatalogueEntry;
  } | null>(null);
  const [editProjectModal, setEditProjectModal] = useState<ProjectCatalogueEntry | null>(null);
  const [editObjectModal, setEditObjectModal] = useState<{ obj: ObjectRow; projectId: string } | null>(null);
  const [deleteProjectConfirm, setDeleteProjectConfirm] = useState<string | null>(null);
  const [deleteObjectConfirm, setDeleteObjectConfirm] = useState<{
    projectId: string;
    objectName: string;
    iterationIds: string[];
  } | null>(null);

  // Filters (per project)
  const [filters, setFilters] = useState<Record<string, { processArea: string; status: string; sourceSystem: string }>>({});

  useEffect(() => {
    setCatalogue(getProjectCatalogue());
    setStatuses(getProjectStatuses() as Record<string, MappingStatus>);
  }, []);

  const projectGroups = buildProjectGroups(catalogue, statuses);

  const toggleProject = (projectId: string) => {
    setExpandedProjects((prev) => {
      const next = new Set(prev);
      if (next.has(projectId)) next.delete(projectId);
      else next.add(projectId);
      return next;
    });
  };

  const getFilter = (projectId: string) =>
    filters[projectId] || { processArea: '', status: '', sourceSystem: '' };

  const setFilter = (projectId: string, key: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [projectId]: { ...getFilter(projectId), [key]: value },
    }));
  };

  const resetFilters = (projectId: string) => {
    setFilters((prev) => ({ ...prev, [projectId]: { processArea: '', status: '', sourceSystem: '' } }));
  };

  const filterObjects = (objects: ObjectRow[], projectId: string): ObjectRow[] => {
    const f = getFilter(projectId);
    return objects.filter((obj) => {
      const objStatus = (statuses[`${projectId}__${obj.objectName}`] as MappingStatus) || 'In Progress';
      if (f.processArea && obj.processArea !== f.processArea) return false;
      if (f.status && objStatus !== f.status) return false;
      if (f.sourceSystem && obj.sourceSystem !== f.sourceSystem) return false;
      return true;
    });
  };

  const handleStatusChange = (key: string, status: MappingStatus) => {
    const updated = { ...statuses, [key]: status };
    setStatuses(updated);
    saveProjectStatus(key, status);
  };

  const handleContinueMapping = (entry: ProjectCatalogueEntry, iter: MappingIteration) => {
    loadIterationAsSession(entry, iter);
    router.push('/mapping-preview-export');
  };

  const handleDownloadExcel = (entry: ProjectCatalogueEntry, iter: MappingIteration) => {
    generateMappingExcel({
      projectDetails: entry.projectDetails,
      mappings: iter.mappings,
      xmlFileName: iter.xmlFileName,
      generatedAt: iter.generatedAt,
    });
  };

  const handleDownloadCsv = (entry: ProjectCatalogueEntry, iter: MappingIteration) => {
    exportAsCsv(entry, iter);
  };

  const handleLoadVersion = (entry: ProjectCatalogueEntry, iter: MappingIteration) => {
    loadIterationAsSession(entry, iter);
    setVersionsModal(null);
    router.push('/mapping-preview-export');
  };

  // ── Project Edit/Delete ──────────────────────────────────────────────────────

  const handleEditProjectSave = (
    projectId: string,
    updates: { projectName: string; clientName: string; dmConsultant: string }
  ) => {
    const updated = catalogue.map((entry) => {
      if (entry.projectId !== projectId) return entry;
      return {
        ...entry,
        projectDetails: {
          ...entry.projectDetails,
          projectName: updates.projectName,
          clientName: updates.clientName,
          dmConsultant: updates.dmConsultant,
        },
        updatedAt: new Date().toISOString(),
      };
    });
    // Persist via deleteProjectFromCatalogue + re-save trick — instead update localStorage directly
    if (typeof window !== 'undefined') {
      localStorage.setItem('mm_project_catalogue', JSON.stringify(updated));
    }
    setCatalogue(updated);
    setEditProjectModal(null);
  };

  const handleDeleteProject = (projectId: string) => {
    deleteProjectFromCatalogue(projectId);
    setCatalogue(getProjectCatalogue());
    setDeleteProjectConfirm(null);
  };

  // ── Object Edit/Delete ───────────────────────────────────────────────────────

  const handleEditObjectSave = (
    projectId: string,
    oldObjectName: string,
    newObjectName: string,
    newProcessArea: string
  ) => {
    const updated = catalogue.map((entry) => {
      if (entry.projectId !== projectId) return entry;
      const updatedIterations = entry.iterations.map((iter) => {
        if (iter.objectName !== oldObjectName) return iter;
        return { ...iter, objectName: newObjectName };
      });
      return {
        ...entry,
        projectDetails: { ...entry.projectDetails, processArea: newProcessArea },
        iterations: updatedIterations,
        updatedAt: new Date().toISOString(),
      };
    });
    if (typeof window !== 'undefined') {
      localStorage.setItem('mm_project_catalogue', JSON.stringify(updated));
    }
    setCatalogue(updated);
    setEditObjectModal(null);
  };

  const handleDeleteObject = () => {
    if (!deleteObjectConfirm) return;
    const { projectId, iterationIds } = deleteObjectConfirm;
    let updatedCatalogue = catalogue;
    for (const iterationId of iterationIds) {
      deleteIterationFromCatalogue(projectId, iterationId);
    }
    updatedCatalogue = getProjectCatalogue();
    setCatalogue(updatedCatalogue);
    setDeleteObjectConfirm(null);
  };

  return (
    <div className="min-h-screen px-4 py-6 xl:px-8 2xl:px-12 max-w-screen-2xl">
      {/* Header */}
      <div className="mb-6 flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
            <FolderOpen size={13} />
            <span>Active Projects</span>
          </div>
          <h1 className="page-title">Projects</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Expand a project to view all mapped objects with their versions and status.
          </p>
        </div>
        <button
          onClick={() => router.push('/create-project')}
          className="btn-primary flex items-center gap-2 flex-shrink-0"
        >
          <Plus size={15} />
          New Project
        </button>
      </div>

      {projectGroups.length === 0 ? (
        <div className="card-panel p-12 flex flex-col items-center justify-center text-center max-w-lg mx-auto">
          <div className="w-14 h-14 rounded-xl bg-secondary flex items-center justify-center mx-auto mb-4">
            <FolderOpen size={24} className="text-muted-foreground" />
          </div>
          <h2 className="text-lg font-semibold text-foreground mb-2">No Projects Yet</h2>
          <p className="text-sm text-muted-foreground mb-6">
            Create a project first, then generate mappings from the Mapping Generator.
          </p>
          <div className="flex gap-2">
            <button onClick={() => router.push('/create-project')} className="btn-primary flex items-center gap-2">
              <Plus size={15} />
              Create Project
            </button>
            <button onClick={() => router.push('/')} className="btn-secondary">
              Mapping Generator
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {projectGroups.map((pg) => {
            const isProjectExpanded = expandedProjects.has(pg.entry.projectId);
            const pd = pg.entry.projectDetails;
            const targetSystem = pd.targetSystem || 'S4 HANA';
            const f = getFilter(pg.entry.projectId);
            const filteredObjects = filterObjects(pg.objects, pg.entry.projectId);

            // Unique filter options for this project
            const processAreas = Array.from(new Set(pg.objects.map((o) => o.processArea).filter(Boolean)));
            const sourceSystems = Array.from(
              new Set(pg.objects.map((o) => o.sourceSystem).filter((s) => s && s !== '—'))
            );
            const hasActiveFilters = f.processArea || f.status || f.sourceSystem;

            return (
              <div key={pg.entry.projectId} className="card-panel overflow-hidden">
                {/* ── Project Row ── */}
                <div className="flex items-center gap-2 px-5 py-4 hover:bg-muted/10 transition-colors">
                  <button
                    onClick={() => toggleProject(pg.entry.projectId)}
                    className="flex items-center gap-3 flex-1 min-w-0 text-left"
                  >
                    <div className="flex-shrink-0">
                      {isProjectExpanded ? (
                        <ChevronDown size={16} className="text-primary" />
                      ) : (
                        <ChevronRight size={16} className="text-muted-foreground" />
                      )}
                    </div>

                    <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <FolderOpen size={16} className="text-primary" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-foreground text-sm truncate">{pd.projectName}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {pg.totalObjects} object{pg.totalObjects !== 1 ? 's' : ''}
                      </p>
                    </div>

                    {/* Meta chips */}
                    <div className="hidden md:flex items-center gap-4 flex-shrink-0">
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Building2 size={12} className="flex-shrink-0" />
                        <span className="truncate max-w-[120px]">{pd.clientName || '—'}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Server size={12} className="flex-shrink-0" />
                        <span className="truncate max-w-[100px]">{pd.sourceSystem || '—'}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs font-medium text-primary">
                        <Database size={12} className="flex-shrink-0" />
                        <span>{targetSystem}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs font-medium text-foreground/80 bg-secondary px-2.5 py-1 rounded-full">
                        <Package size={11} />
                        <span>{pg.totalObjects} object{pg.totalObjects !== 1 ? 's' : ''}</span>
                      </div>
                    </div>

                    {/* Status summary chips */}
                    <div className="hidden lg:flex items-center gap-1.5 flex-shrink-0 ml-2">
                      {(Object.entries(pg.statusCounts) as [MappingStatus, number][])
                        .filter(([, count]) => count > 0)
                        .map(([status, count]) => {
                          const s = STATUS_STYLES[status];
                          return (
                            <span
                              key={status}
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${s.bg}`}
                            >
                              {s.icon}
                              {count}
                            </span>
                          );
                        })}
                    </div>

                    {/* Updated */}
                    <div className="hidden xl:flex items-center gap-1.5 text-xs text-muted-foreground flex-shrink-0 ml-2">
                      <Clock size={11} />
                      <span>
                        {new Date(pg.entry.updatedAt).toLocaleDateString('en-GB', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </span>
                    </div>
                  </button>

                  {/* Project-level Edit / Delete actions */}
                  <div className="flex items-center gap-1 flex-shrink-0 ml-2">
                    <button
                      onClick={(e) => { e.stopPropagation(); setEditProjectModal(pg.entry); }}
                      title="Edit Project"
                      className="p-1.5 rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                    >
                      <Pencil size={14} />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); setDeleteProjectConfirm(pg.entry.projectId); }}
                      title="Delete Project"
                      className="p-1.5 rounded-md text-muted-foreground hover:text-danger hover:bg-danger/10 transition-colors"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                {/* ── Project Details Bar (visible when expanded) ── */}
                {isProjectExpanded && (
                  <div className="px-5 py-2.5 bg-muted/10 border-t border-border flex flex-wrap items-center gap-x-6 gap-y-1.5">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Building2 size={12} />
                      <span className="font-medium text-foreground/70">Client:</span>
                      <span>{pd.clientName || '—'}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Server size={12} />
                      <span className="font-medium text-foreground/70">Source:</span>
                      <span>{pd.sourceSystem || '—'}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Database size={12} className="text-primary" />
                      <span className="font-medium text-foreground/70">Target:</span>
                      <span className="text-primary font-medium">{targetSystem}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Package size={12} />
                      <span className="font-medium text-foreground/70">Objects:</span>
                      <span>{pg.totalObjects}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <User size={12} />
                      <span className="font-medium text-foreground/70">DM Consultant:</span>
                      <span>{pd.dmConsultant || '—'}</span>
                    </div>
                    <div className="flex items-center gap-1.5 ml-auto">
                      {(Object.entries(pg.statusCounts) as [MappingStatus, number][])
                        .filter(([, count]) => count > 0)
                        .map(([status, count]) => {
                          const s = STATUS_STYLES[status];
                          return (
                            <span
                              key={status}
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${s.bg}`}
                            >
                              {s.icon}
                              <span>{status}</span>
                              <span className="font-bold ml-0.5">{count}</span>
                            </span>
                          );
                        })}
                    </div>
                  </div>
                )}

                {/* ── Filters Bar ── */}
                {isProjectExpanded && pg.objects.length > 0 && (
                  <div className="px-5 py-3 bg-muted/5 border-t border-border flex flex-wrap items-center gap-3">
                    <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground flex-shrink-0">
                      <Filter size={12} />
                      <span>Filter:</span>
                    </div>

                    {/* Process Area filter */}
                    <select
                      value={f.processArea}
                      onChange={(e) => setFilter(pg.entry.projectId, 'processArea', e.target.value)}
                      className="text-xs bg-secondary border border-border rounded-md px-2.5 py-1.5 text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 min-w-[140px]"
                    >
                      <option value="">All Process Areas</option>
                      {processAreas.map((pa) => (
                        <option key={pa} value={pa}>{pa}</option>
                      ))}
                    </select>

                    {/* Status filter */}
                    <select
                      value={f.status}
                      onChange={(e) => setFilter(pg.entry.projectId, 'status', e.target.value)}
                      className="text-xs bg-secondary border border-border rounded-md px-2.5 py-1.5 text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 min-w-[140px]"
                    >
                      <option value="">All Statuses</option>
                      {STATUS_OPTIONS.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>

                    {/* Source System filter */}
                    <select
                      value={f.sourceSystem}
                      onChange={(e) => setFilter(pg.entry.projectId, 'sourceSystem', e.target.value)}
                      className="text-xs bg-secondary border border-border rounded-md px-2.5 py-1.5 text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 min-w-[140px]"
                    >
                      <option value="">All Source Systems</option>
                      {sourceSystems.map((ss) => (
                        <option key={ss} value={ss}>{ss}</option>
                      ))}
                    </select>

                    {hasActiveFilters && (
                      <button
                        onClick={() => resetFilters(pg.entry.projectId)}
                        className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
                      >
                        <RefreshCw size={11} />
                        Reset
                      </button>
                    )}

                    <span className="ml-auto text-xs text-muted-foreground">
                      {filteredObjects.length} of {pg.objects.length} object{pg.objects.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                )}

                {/* ── Objects Table ── */}
                {isProjectExpanded && pg.objects.length > 0 && (
                  <div className="border-t border-border overflow-x-auto">
                    {/* Table header */}
                    <div className="min-w-[900px] grid grid-cols-[2fr_1.2fr_1fr_80px_140px_220px] gap-2 px-5 py-2.5 bg-muted/20 border-b border-border">
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Object Name</span>
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Process Area</span>
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Source System</span>
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider text-center">Versions</span>
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Status</span>
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Actions</span>
                    </div>

                    {filteredObjects.length === 0 ? (
                      <div className="min-w-[900px] px-5 py-6 text-center text-sm text-muted-foreground">
                        No objects match the selected filters.
                      </div>
                    ) : (
                      filteredObjects.map((obj) => {
                        const objStatusKey = `${pg.entry.projectId}__${obj.objectName}`;

                        return (
                          <div
                            key={obj.objectName}
                            className="min-w-[900px] grid grid-cols-[2fr_1.2fr_1fr_80px_140px_220px] gap-2 items-center px-5 py-3 border-b border-border last:border-b-0 hover:bg-muted/10 transition-colors"
                          >
                            {/* Object Name */}
                            <div className="flex items-center gap-2 min-w-0">
                              <div className="w-6 h-6 rounded bg-primary/10 flex items-center justify-center flex-shrink-0">
                                <Tag size={11} className="text-primary" />
                              </div>
                              <div className="min-w-0">
                                <span className="text-sm font-medium text-foreground truncate block">
                                  {obj.objectName || <span className="text-muted-foreground italic">Unnamed</span>}
                                </span>
                                <span className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                                  <Clock size={9} />
                                  {new Date(obj.latestIteration.generatedAt).toLocaleDateString('en-GB', {
                                    day: '2-digit', month: 'short', year: 'numeric',
                                  })}
                                </span>
                              </div>
                            </div>

                            {/* Process Area */}
                            <div className="flex items-center gap-1 min-w-0">
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium bg-secondary text-muted-foreground border border-border truncate max-w-full">
                                <Layers size={10} className="flex-shrink-0" />
                                <span className="truncate">{obj.processArea}</span>
                              </span>
                            </div>

                            {/* Source System */}
                            <div className="flex items-center gap-1.5 min-w-0">
                              <Server size={11} className="text-muted-foreground flex-shrink-0" />
                              <span className="text-xs text-foreground/70 truncate">{obj.sourceSystem}</span>
                            </div>

                            {/* Versions count */}
                            <div className="flex items-center justify-center">
                              <span className="inline-flex items-center gap-1 text-xs font-semibold text-foreground/80 bg-secondary px-2.5 py-1 rounded-full">
                                <GitBranch size={10} />
                                {obj.iterations.length}
                              </span>
                            </div>

                            {/* Status */}
                            <StatusBadge
                              statusKey={objStatusKey}
                              statuses={statuses}
                              onStatusChange={handleStatusChange}
                            />

                            {/* Actions */}
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <button
                                onClick={() => handleContinueMapping(obj.entry, obj.latestIteration)}
                                title="Continue Mapping"
                                className="flex items-center gap-1 px-2 py-1.5 rounded-md text-xs font-medium bg-primary/10 text-primary hover:bg-primary hover:text-white transition-colors whitespace-nowrap"
                              >
                                <Play size={10} />
                                Continue
                              </button>
                              <button
                                onClick={() =>
                                  setVersionsModal({
                                    objectName: obj.objectName,
                                    iterations: obj.iterations,
                                    entry: obj.entry,
                                  })
                                }
                                title="View All Versions"
                                className="flex items-center gap-1 px-2 py-1.5 rounded-md text-xs font-medium bg-secondary text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors whitespace-nowrap"
                              >
                                <GitBranch size={10} />
                                Versions
                              </button>
                              <button
                                onClick={() => setEditObjectModal({ obj, projectId: pg.entry.projectId })}
                                title="Update Object"
                                className="flex items-center gap-1 px-2 py-1.5 rounded-md text-xs font-medium bg-secondary text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors whitespace-nowrap"
                              >
                                <Pencil size={10} />
                                Update
                              </button>
                              <DownloadDropdown
                                onDownloadExcel={() => handleDownloadExcel(obj.entry, obj.latestIteration)}
                                onDownloadCsv={() => handleDownloadCsv(obj.entry, obj.latestIteration)}
                              />
                              <button
                                onClick={() =>
                                  setDeleteObjectConfirm({
                                    projectId: pg.entry.projectId,
                                    objectName: obj.objectName,
                                    iterationIds: obj.iterations.map((i) => i.iterationId),
                                  })
                                }
                                title="Delete Object"
                                className="flex items-center gap-1 px-2 py-1.5 rounded-md text-xs font-medium bg-secondary text-muted-foreground hover:text-danger hover:bg-danger/10 transition-colors whitespace-nowrap"
                              >
                                <Trash2 size={10} />
                                Delete
                              </button>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                )}

                {/* Empty state for project with no objects */}
                {isProjectExpanded && pg.objects.length === 0 && (
                  <div className="border-t border-border px-5 py-6 flex flex-col items-center gap-2 text-center">
                    <Package size={20} className="text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">No objects mapped yet for this project.</p>
                    <button
                      onClick={() => router.push('/')}
                      className="text-xs text-primary hover:underline flex items-center gap-1"
                    >
                      <Plus size={11} />
                      Generate a mapping
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ── Versions Modal ── */}
      {versionsModal && (
        <VersionsModal
          objectName={versionsModal.objectName}
          iterations={versionsModal.iterations}
          entry={versionsModal.entry}
          onClose={() => setVersionsModal(null)}
          onLoad={handleLoadVersion}
        />
      )}

      {/* ── Edit Project Modal ── */}
      {editProjectModal && (
        <EditProjectModal
          entry={editProjectModal}
          onSave={handleEditProjectSave}
          onClose={() => setEditProjectModal(null)}
        />
      )}

      {/* ── Edit Object Modal ── */}
      {editObjectModal && (
        <EditObjectModal
          obj={editObjectModal.obj}
          onSave={(oldName, newName, newProcessArea) =>
            handleEditObjectSave(editObjectModal.projectId, oldName, newName, newProcessArea)
          }
          onClose={() => setEditObjectModal(null)}
        />
      )}

      {/* ── Delete Project Confirmation ── */}
      {deleteProjectConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="card-panel p-6 max-w-sm w-full">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-danger/10 flex items-center justify-center flex-shrink-0">
                <AlertTriangle size={18} className="text-danger" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">Delete this project?</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  All objects and mapping iterations will be permanently removed.
                </p>
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setDeleteProjectConfirm(null)} className="btn-secondary text-sm">
                Cancel
              </button>
              <button
                onClick={() => handleDeleteProject(deleteProjectConfirm)}
                className="px-4 py-2 rounded-lg text-sm font-medium bg-danger text-white hover:bg-danger/90 transition-colors"
              >
                Delete Project
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Delete Object Confirmation ── */}
      {deleteObjectConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="card-panel p-6 max-w-sm w-full">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-danger/10 flex items-center justify-center flex-shrink-0">
                <AlertTriangle size={18} className="text-danger" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">Delete object?</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  <span className="font-medium text-foreground">{deleteObjectConfirm.objectName}</span> and all its versions will be permanently removed.
                </p>
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setDeleteObjectConfirm(null)} className="btn-secondary text-sm">
                Cancel
              </button>
              <button
                onClick={handleDeleteObject}
                className="px-4 py-2 rounded-lg text-sm font-medium bg-danger text-white hover:bg-danger/90 transition-colors"
              >
                Delete Object
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
