'use client';

import React, { useState, useEffect } from 'react';
import AppLayout from '@/components/AppLayout';
import {
  getStandaloneProjects,
  createStandaloneProject,
  updateStandaloneProject,
  deleteStandaloneProject,
  type StandaloneProject,
} from '@/lib/mappingStore';
import { useRouter } from 'next/navigation';
import { FolderOpen, Plus, Pencil, Trash2, X, Building2, Server, Database, Calendar, ChevronDown, CheckCircle2, AlertTriangle, Layers,  } from 'lucide-react';

const PHASES = ['1 – Prepare', '2 – Explore', '3 – Realize', '4 – Deploy', '5 – Run'];
const TODAY = new Date().toISOString().slice(0, 10);

// ── Create / Edit Project Modal ────────────────────────────────────────────────

interface ProjectFormData {
  projectName: string;
  clientName: string;
  sourceSystems: string[];
  phase: string;
  createdDate: string;
}

interface ProjectModalProps {
  initial?: StandaloneProject | null;
  onSave: (data: ProjectFormData) => void;
  onClose: () => void;
}

function ProjectModal({ initial, onSave, onClose }: ProjectModalProps) {
  const [form, setForm] = useState<ProjectFormData>({
    projectName: initial?.projectName || '',
    clientName: initial?.clientName || '',
    sourceSystems: initial?.sourceSystems?.length ? initial.sourceSystems : [''],
    phase: initial?.phase || '',
    createdDate: initial?.createdDate || TODAY,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.projectName.trim()) e.projectName = 'Project name is required.';
    if (!form.clientName.trim()) e.clientName = 'Client name is required.';
    if (!form.phase) e.phase = 'Phase is required.';
    const validSystems = form.sourceSystems.filter((s) => s.trim());
    if (validSystems.length === 0) e.sourceSystems = 'At least one source system is required.';
    return e;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    onSave({ ...form, sourceSystems: form.sourceSystems.filter((s) => s.trim()) });
  };

  const addSourceSystem = () => setForm((f) => ({ ...f, sourceSystems: [...f.sourceSystems, ''] }));
  const removeSourceSystem = (idx: number) =>
    setForm((f) => ({ ...f, sourceSystems: f.sourceSystems.filter((_, i) => i !== idx) }));
  const updateSourceSystem = (idx: number, val: string) =>
    setForm((f) => {
      const arr = [...f.sourceSystems];
      arr[idx] = val;
      return { ...f, sourceSystems: arr };
    });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="card-panel w-full max-w-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <FolderOpen size={16} className="text-primary" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">
                {initial ? 'Edit Project' : 'Create New Project'}
              </p>
              <p className="text-xs text-muted-foreground">Target system is always S4 HANA</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {/* Project & Client */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="label-field">Project Name <span className="text-danger">*</span></label>
              <input
                className="input-field"
                placeholder="Acme Corp SAP S/4HANA Migration"
                value={form.projectName}
                onChange={(e) => setForm((f) => ({ ...f, projectName: e.target.value }))}
              />
              {errors.projectName && <p className="error-text">{errors.projectName}</p>}
            </div>
            <div>
              <label className="label-field">Client Name <span className="text-danger">*</span></label>
              <input
                className="input-field"
                placeholder="Acme Corporation"
                value={form.clientName}
                onChange={(e) => setForm((f) => ({ ...f, clientName: e.target.value }))}
              />
              {errors.clientName && <p className="error-text">{errors.clientName}</p>}
            </div>
          </div>

          {/* Source Systems */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="label-field mb-0">
                Source Systems <span className="text-danger">*</span>
              </label>
              <button
                type="button"
                onClick={addSourceSystem}
                className="flex items-center gap-1 text-xs font-medium text-primary hover:text-primary/80 transition-colors"
              >
                <Plus size={12} />
                Add Source System
              </button>
            </div>
            <p className="helper-text mb-2">Add all legacy source systems involved in this migration project.</p>
            <div className="space-y-2">
              {form.sourceSystems.map((sys, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded bg-secondary flex items-center justify-center flex-shrink-0 text-xs font-bold text-muted-foreground">
                    {idx + 1}
                  </div>
                  <input
                    className="input-field flex-1"
                    placeholder={`e.g. SAP ECC 6.0, Oracle EBS, Legacy ERP`}
                    value={sys}
                    onChange={(e) => updateSourceSystem(idx, e.target.value)}
                  />
                  {form.sourceSystems.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeSourceSystem(idx)}
                      className="p-1.5 rounded-md text-muted-foreground hover:text-danger hover:bg-danger/10 transition-colors flex-shrink-0"
                    >
                      <X size={14} />
                    </button>
                  )}
                </div>
              ))}
            </div>
            {errors.sourceSystems && <p className="error-text mt-1">{errors.sourceSystems}</p>}
          </div>

          {/* Target System — fixed */}
          <div>
            <label className="label-field">Target System</label>
            <div className="input-field bg-muted/30 flex items-center gap-2 cursor-not-allowed">
              <Database size={14} className="text-primary flex-shrink-0" />
              <span className="text-foreground font-medium">S4 HANA</span>
              <span className="ml-auto text-xs text-muted-foreground bg-secondary px-2 py-0.5 rounded-full">Fixed</span>
            </div>
          </div>

          {/* Phase & Date */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="label-field">Migration Phase <span className="text-danger">*</span></label>
              <select
                className="select-field"
                value={form.phase}
                onChange={(e) => setForm((f) => ({ ...f, phase: e.target.value }))}
              >
                <option value="">Select phase...</option>
                {PHASES.map((ph) => <option key={ph} value={ph}>{ph}</option>)}
              </select>
              {errors.phase && <p className="error-text">{errors.phase}</p>}
            </div>
            <div>
              <label className="label-field">Created Date</label>
              <input
                type="date"
                className="input-field"
                value={form.createdDate}
                onChange={(e) => setForm((f) => ({ ...f, createdDate: e.target.value }))}
              />
            </div>
          </div>
        </form>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-border flex justify-end gap-2 flex-shrink-0">
          <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
          <button
            type="submit"
            form=""
            onClick={handleSubmit}
            className="btn-primary"
          >
            {initial ? 'Save Changes' : 'Create Project'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Delete Confirm Modal ───────────────────────────────────────────────────────

function DeleteConfirmModal({ projectName, onConfirm, onCancel }: { projectName: string; onConfirm: () => void; onCancel: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="card-panel p-6 max-w-sm w-full">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-danger/10 flex items-center justify-center flex-shrink-0">
            <AlertTriangle size={18} className="text-danger" />
          </div>
          <div>
            <p className="text-sm font-semibold text-foreground">Delete Project?</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              &ldquo;{projectName}&rdquo; will be permanently removed.
            </p>
          </div>
        </div>
        <div className="flex gap-2 justify-end">
          <button onClick={onCancel} className="btn-secondary text-sm">Cancel</button>
          <button
            onClick={onConfirm}
            className="px-4 py-2 rounded-lg text-sm font-medium bg-danger text-white hover:bg-danger/90 transition-colors"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────

export default function CreateProjectPage() {
  return (
    <AppLayout>
      <CreateProjectContent />
    </AppLayout>
  );
}

function CreateProjectContent() {
  const router = useRouter();
  const [projects, setProjects] = useState<StandaloneProject[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editProject, setEditProject] = useState<StandaloneProject | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<StandaloneProject | null>(null);
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    setProjects(getStandaloneProjects());
  }, []);

  const refresh = () => setProjects(getStandaloneProjects());

  const handleCreate = (data: Parameters<typeof createStandaloneProject>[0]) => {
    createStandaloneProject(data);
    refresh();
    setShowModal(false);
  };

  const handleEdit = (data: { projectName: string; clientName: string; sourceSystems: string[]; phase: string; createdDate: string }) => {
    if (!editProject) return;
    updateStandaloneProject(editProject.projectId, {
      ...data,
      targetSystem: 'S4 HANA',
    });
    refresh();
    setEditProject(null);
  };

  const handleDelete = () => {
    if (!deleteTarget) return;
    deleteStandaloneProject(deleteTarget.projectId);
    refresh();
    setDeleteTarget(null);
  };

  const toggleExpand = (id: string) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="min-h-screen px-4 py-6 xl:px-8 2xl:px-12 max-w-screen-2xl">
      {/* Header */}
      <div className="mb-6 flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
            <FolderOpen size={13} />
            <span>Project Management</span>
          </div>
          <h1 className="page-title">Create Project</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Create projects upfront with multiple source systems. Mappings generated in the Mapping Generator will be assigned to a selected project.
          </p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="btn-primary flex items-center gap-2 flex-shrink-0"
        >
          <Plus size={15} />
          New Project
        </button>
      </div>

      {/* Target System Info Banner */}
      <div className="mb-5 flex items-center gap-3 p-3.5 rounded-xl border border-primary/20 bg-primary/5">
        <Database size={16} className="text-primary flex-shrink-0" />
        <p className="text-sm text-foreground/80">
          <span className="font-semibold text-primary">Target System</span> is always{' '}
          <span className="font-semibold">S4 HANA</span> for all projects in this tool.
        </p>
      </div>

      {/* Projects List */}
      {projects.length === 0 ? (
        <div className="card-panel p-12 flex flex-col items-center justify-center text-center max-w-lg mx-auto">
          <div className="w-14 h-14 rounded-xl bg-secondary flex items-center justify-center mx-auto mb-4">
            <FolderOpen size={24} className="text-muted-foreground" />
          </div>
          <h2 className="text-lg font-semibold text-foreground mb-2">No Projects Yet</h2>
          <p className="text-sm text-muted-foreground mb-6">
            Create your first project to start organising your migration mappings.
          </p>
          <button onClick={() => setShowModal(true)} className="btn-primary flex items-center gap-2">
            <Plus size={15} />
            Create First Project
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {projects.map((proj) => {
            const isExpanded = expandedIds.has(proj.projectId);
            return (
              <div key={proj.projectId} className="card-panel overflow-hidden">
                {/* Project Row */}
                <div className="flex items-center gap-3 px-5 py-4">
                  <button
                    onClick={() => toggleExpand(proj.projectId)}
                    className="flex-shrink-0 p-0.5"
                  >
                    {isExpanded ? (
                      <ChevronDown size={16} className="text-primary" />
                    ) : (
                      <ChevronDown size={16} className="text-muted-foreground -rotate-90 transition-transform" />
                    )}
                  </button>

                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <FolderOpen size={16} className="text-primary" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-foreground text-sm truncate">{proj.projectName}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {proj.sourceSystems.length} source system{proj.sourceSystems.length !== 1 ? 's' : ''} · {proj.phase || 'No phase'}
                    </p>
                  </div>

                  {/* Meta */}
                  <div className="hidden md:flex items-center gap-4 flex-shrink-0">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Building2 size={12} />
                      <span className="truncate max-w-[120px]">{proj.clientName}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Database size={12} className="text-primary" />
                      <span className="text-primary font-medium">S4 HANA</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <button
                      onClick={() => router.push('/')}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium bg-primary/10 text-primary hover:bg-primary hover:text-white transition-colors"
                      title="Generate Mapping for this Project"
                    >
                      <Layers size={11} />
                      Map Objects
                    </button>
                    <button
                      onClick={() => setEditProject(proj)}
                      className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors"
                      title="Edit Project"
                    >
                      <Pencil size={14} />
                    </button>
                    <button
                      onClick={() => setDeleteTarget(proj)}
                      className="p-1.5 rounded-md text-muted-foreground hover:text-danger hover:bg-danger/10 transition-colors"
                      title="Delete Project"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="border-t border-border px-5 py-4 bg-muted/5">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Source Systems */}
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
                          <Server size={11} />
                          Source Systems
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          {proj.sourceSystems.map((sys, i) => (
                            <span
                              key={i}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-secondary text-foreground/80 border border-border"
                            >
                              <Server size={10} className="text-muted-foreground" />
                              {sys}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Target System */}
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
                          <Database size={11} />
                          Target System
                        </p>
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary border border-primary/20">
                          <CheckCircle2 size={10} />
                          S4 HANA
                        </span>
                      </div>

                      {/* removed Team section */}

                      {/* Phase & Date */}
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
                          <Calendar size={11} />
                          Timeline
                        </p>
                        <div className="space-y-1">
                          <p className="text-xs text-foreground/80">
                            <span className="text-muted-foreground">Phase:</span> {proj.phase || '—'}
                          </p>
                          <p className="text-xs text-foreground/80">
                            <span className="text-muted-foreground">Created:</span> {proj.createdDate}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Create Modal */}
      {showModal && (
        <ProjectModal
          onSave={(data) => handleCreate({ ...data, targetSystem: 'S4 HANA' })}
          onClose={() => setShowModal(false)}
        />
      )}

      {/* Edit Modal */}
      {editProject && (
        <ProjectModal
          initial={editProject}
          onSave={handleEdit}
          onClose={() => setEditProject(null)}
        />
      )}

      {/* Delete Confirm */}
      {deleteTarget && (
        <DeleteConfirmModal
          projectName={deleteTarget.projectName}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  );
}
