'use client';

import React, { useState, useEffect } from 'react';
import AppLayout from '@/components/AppLayout';
import {
  getCrossReferenceRows,
  saveCrossReferenceRows,
  type CrossReferenceRow,
} from '@/lib/mappingStore';
import {
  GitCompare,
  Plus,
  Trash2,
  Save,
  Download,
  Upload,
  AlertTriangle,
} from 'lucide-react';
import toast from 'react-hot-toast';

export default function CrossReferencePage() {
  return (
    <AppLayout>
      <CrossReferenceContent />
    </AppLayout>
  );
}

const EMPTY_ROW = (): CrossReferenceRow => ({
  id: `xref-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
  sourceSystem: '',
  fieldName: '',
  fieldDescription: '',
  parameter1: '',
  parameter1Desc: '',
  parameter2: '',
  parameter2Desc: '',
  parameter3: '',
  parameter3Desc: '',
  sourceValue: '',
  sourceValueDescription: '',
  targetValue: '',
  targetValueDesc: '',
});

const COLUMNS: { key: keyof Omit<CrossReferenceRow, 'id'>; label: string; width: number }[] = [
  { key: 'sourceSystem', label: 'Source System', width: 120 },
  { key: 'fieldName', label: 'Field Name', width: 120 },
  { key: 'fieldDescription', label: 'Field Description', width: 160 },
  { key: 'parameter1', label: 'Parameter1', width: 110 },
  { key: 'parameter1Desc', label: 'Parameter1_Desc', width: 140 },
  { key: 'parameter2', label: 'Parameter2', width: 110 },
  { key: 'parameter2Desc', label: 'Parameter2_Desc', width: 140 },
  { key: 'parameter3', label: 'Parameter3', width: 110 },
  { key: 'parameter3Desc', label: 'Parameter3_Desc', width: 140 },
  { key: 'sourceValue', label: 'Source_Value', width: 120 },
  { key: 'sourceValueDescription', label: 'Source_Value_Description', width: 180 },
  { key: 'targetValue', label: 'Target_Value', width: 120 },
  { key: 'targetValueDesc', label: 'Target_Value_Desc', width: 160 },
];

function CrossReferenceContent() {
  const [rows, setRows] = useState<CrossReferenceRow[]>([]);
  const [hasChanges, setHasChanges] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  useEffect(() => {
    const saved = getCrossReferenceRows();
    setRows(saved.length > 0 ? saved : [EMPTY_ROW()]);
  }, []);

  const updateCell = (id: string, key: keyof Omit<CrossReferenceRow, 'id'>, value: string) => {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, [key]: value } : r)));
    setHasChanges(true);
  };

  const addRow = () => {
    setRows((prev) => [...prev, EMPTY_ROW()]);
    setHasChanges(true);
  };

  const deleteRow = (id: string) => {
    setRows((prev) => prev.filter((r) => r.id !== id));
    setDeleteConfirm(null);
    setHasChanges(true);
  };

  const handleSave = () => {
    saveCrossReferenceRows(rows);
    setHasChanges(false);
    toast.success('Cross reference data saved successfully.');
  };

  const handleExportCSV = () => {
    const headers = COLUMNS.map((c) => c.label).join(',');
    const csvRows = rows.map((r) =>
      COLUMNS.map((c) => `"${(r[c.key] || '').replace(/"/g, '""')}"`).join(',')
    );
    const csv = [headers, ...csvRows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'cross_reference.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const text = ev.target?.result as string;
        const lines = text.split('\n').filter(Boolean);
        const dataLines = lines.slice(1); // skip header
        const imported: CrossReferenceRow[] = dataLines.map((line) => {
          const vals = line.split(',').map((v) => v.replace(/^"|"$/g, '').replace(/""/g, '"'));
          const row = EMPTY_ROW();
          COLUMNS.forEach((col, i) => {
            (row as Record<string, string>)[col.key] = vals[i] || '';
          });
          return row;
        });
        setRows(imported);
        setHasChanges(true);
        toast.success(`Imported ${imported.length} rows from CSV.`);
      } catch {
        toast.error('Failed to parse CSV file.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="min-h-screen px-4 py-6 xl:px-8 2xl:px-12 max-w-screen-2xl">
      {/* Header */}
      <div className="flex items-start justify-between mb-6 gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
            <GitCompare size={13} />
            <span>Value Mapping</span>
          </div>
          <h1 className="page-title">Cross Reference</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manually manage source-to-target value mappings used during data migration.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <label className="btn-secondary text-sm cursor-pointer flex items-center gap-1.5">
            <Upload size={14} />
            Import CSV
            <input type="file" accept=".csv" className="hidden" onChange={handleImportCSV} />
          </label>
          <button onClick={handleExportCSV} className="btn-secondary text-sm flex items-center gap-1.5">
            <Download size={14} />
            Export CSV
          </button>
          <button
            onClick={handleSave}
            disabled={!hasChanges}
            className="btn-primary text-sm flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Save size={14} />
            Save Changes
            {hasChanges && <span className="w-2 h-2 rounded-full bg-amber-400 ml-0.5" />}
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="flex items-center gap-4 mb-4 text-xs text-muted-foreground">
        <span>{rows.length} row{rows.length !== 1 ? 's' : ''}</span>
        {hasChanges && <span className="text-amber-500 font-medium">• Unsaved changes</span>}
      </div>

      {/* Table */}
      <div className="card-panel overflow-hidden">
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-secondary border-b border-border">
                <th className="px-3 py-3 text-left font-semibold text-muted-foreground w-10 sticky left-0 bg-secondary z-10">#</th>
                {COLUMNS.map((col) => (
                  <th
                    key={col.key}
                    className="px-3 py-3 text-left font-semibold text-muted-foreground whitespace-nowrap"
                    style={{ minWidth: col.width }}
                  >
                    {col.label}
                  </th>
                ))}
                <th className="px-3 py-3 text-center font-semibold text-muted-foreground w-12">Del</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {rows.map((row, idx) => (
                <tr key={row.id} className="hover:bg-muted/30 transition-colors group">
                  <td className="px-3 py-2 text-muted-foreground font-tabular sticky left-0 bg-card group-hover:bg-muted/30 z-10">
                    {idx + 1}
                  </td>
                  {COLUMNS.map((col) => (
                    <td key={col.key} className="px-1.5 py-1.5">
                      <input
                        type="text"
                        value={row[col.key] || ''}
                        onChange={(e) => updateCell(row.id, col.key, e.target.value)}
                        className="w-full px-2 py-1 text-xs rounded border border-transparent bg-transparent hover:border-border focus:border-primary focus:bg-card focus:outline-none transition-colors"
                        style={{ minWidth: col.width - 12 }}
                        placeholder="—"
                      />
                    </td>
                  ))}
                  <td className="px-3 py-2 text-center">
                    <button
                      onClick={() => setDeleteConfirm(row.id)}
                      className="p-1.5 rounded-md text-muted-foreground hover:text-danger hover:bg-danger/10 transition-colors opacity-0 group-hover:opacity-100"
                      title="Delete row"
                    >
                      <Trash2 size={13} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Add row button */}
        <div className="px-4 py-3 border-t border-border">
          <button
            onClick={addRow}
            className="flex items-center gap-2 text-xs font-medium text-primary hover:text-primary/80 transition-colors"
          >
            <Plus size={14} />
            Add Row
          </button>
        </div>
      </div>

      {/* Delete confirm modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="card-panel p-6 max-w-sm w-full animate-fadeScale">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-danger/10 flex items-center justify-center flex-shrink-0">
                <AlertTriangle size={18} className="text-danger" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">Delete Row?</p>
                <p className="text-xs text-muted-foreground mt-0.5">This action cannot be undone.</p>
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setDeleteConfirm(null)} className="btn-secondary text-sm">Cancel</button>
              <button
                onClick={() => deleteRow(deleteConfirm)}
                className="px-4 py-2 rounded-lg text-sm font-medium bg-danger text-white hover:bg-danger/90 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
