'use client';

import React, { useState, useEffect } from 'react';
import AppLayout from '@/components/AppLayout';
import {
  getProjectCatalogue,
  deleteProjectFromCatalogue,
  deleteIterationFromCatalogue,
  loadIterationAsSession,
  type ProjectCatalogueEntry,
  type MappingIteration,
} from '@/lib/mappingStore';
import { useRouter } from 'next/navigation';
import {
  History,
  FolderOpen,
  ChevronDown,
  ChevronRight,
  Trash2,
  Eye,
  Calendar,
  FileText,
  Layers,
  AlertTriangle,
} from 'lucide-react';

export default function MappingHistoryPage() {
  return (
    <AppLayout>
      <MappingHistoryContent />
    </AppLayout>
  );
}

function MappingHistoryContent() {
  const router = useRouter();
  const [catalogue, setCatalogue] = useState<ProjectCatalogueEntry[]>([]);
  const [expandedProjects, setExpandedProjects] = useState<Set<string>>(new Set());
  const [deleteConfirm, setDeleteConfirm] = useState<{ type: 'project' | 'iteration'; projectId: string; iterationId?: string } | null>(null);

  useEffect(() => {
    setCatalogue(getProjectCatalogue());
  }, []);

  const toggleProject = (projectId: string) => {
    setExpandedProjects((prev) => {
      const next = new Set(prev);
      if (next.has(projectId)) next.delete(projectId);
      else next.add(projectId);
      return next;
    });
  };

  const handleLoadIteration = (entry: ProjectCatalogueEntry, iteration: MappingIteration) => {
    loadIterationAsSession(entry, iteration);
    router.push('/mapping-preview-export');
  };

  const handleDeleteProject = (projectId: string) => {
    deleteProjectFromCatalogue(projectId);
    setCatalogue(getProjectCatalogue());
    setDeleteConfirm(null);
  };

  const handleDeleteIteration = (projectId: string, iterationId: string) => {
    deleteIterationFromCatalogue(projectId, iterationId);
    setCatalogue(getProjectCatalogue());
    setDeleteConfirm(null);
  };

  return (
    <div className="min-h-screen px-4 py-6 xl:px-8 2xl:px-12 max-w-screen-2xl">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
          <History size={13} />
          <span>Saved Mappings</span>
        </div>
        <h1 className="page-title">Mapping History</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Browse all saved mapping projects and their iterations. Load any iteration to review or export.
        </p>
      </div>

      {catalogue.length === 0 ? (
        <div className="card-panel p-12 flex flex-col items-center justify-center text-center max-w-lg mx-auto">
          <div className="w-14 h-14 rounded-xl bg-secondary flex items-center justify-center mx-auto mb-4">
            <History size={24} className="text-muted-foreground" />
          </div>
          <h2 className="text-lg font-semibold text-foreground mb-2">No Mapping History</h2>
          <p className="text-sm text-muted-foreground mb-6">
            No mappings have been saved yet. Generate a mapping from the Mapping Generator to start building your catalogue.
          </p>
          <button onClick={() => router.push('/')} className="btn-primary">
            Go to Mapping Generator
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {catalogue.map((entry) => {
            const isExpanded = expandedProjects.has(entry.projectId);
            return (
              <div key={entry.projectId} className="card-panel overflow-hidden">
                {/* Project header row */}
                <div
                  className="flex items-center gap-3 px-5 py-4 cursor-pointer hover:bg-muted/30 transition-colors select-none"
                  onClick={() => toggleProject(entry.projectId)}
                >
                  <div className="flex-shrink-0 text-muted-foreground">
                    {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                  </div>
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <FolderOpen size={16} className="text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground truncate">
                      {entry.projectDetails.projectName}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {entry.projectDetails.clientName} · {entry.projectDetails.processArea} · {entry.projectDetails.phase}
                    </p>
                  </div>
                  <div className="flex items-center gap-4 flex-shrink-0">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Layers size={12} />
                      <span>{entry.iterations.length} iteration{entry.iterations.length !== 1 ? 's' : ''}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Calendar size={12} />
                      <span>{new Date(entry.updatedAt).toLocaleDateString()}</span>
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); setDeleteConfirm({ type: 'project', projectId: entry.projectId }); }}
                      className="p-1.5 rounded-md text-muted-foreground hover:text-danger hover:bg-danger/10 transition-colors"
                      title="Delete project"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                {/* Iterations list */}
                {isExpanded && (
                  <div className="border-t border-border">
                    {entry.iterations.length === 0 ? (
                      <p className="px-5 py-4 text-sm text-muted-foreground italic">No iterations in this project.</p>
                    ) : (
                      <div className="divide-y divide-border">
                        {entry.iterations.map((iter, idx) => (
                          <div key={iter.iterationId} className="flex items-center gap-3 px-5 py-3 hover:bg-muted/20 transition-colors group">
                            <div className="w-7 h-7 rounded-md bg-secondary flex items-center justify-center flex-shrink-0 text-xs font-bold text-muted-foreground">
                              {idx + 1}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-foreground truncate">
                                {iter.objectName}
                              </p>
                              <div className="flex items-center gap-3 mt-0.5">
                                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                                  <FileText size={11} />
                                  {iter.xmlFileName}
                                </span>
                                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                                  <Calendar size={11} />
                                  {iter.generatedAt}
                                </span>
                                <span className="text-xs text-muted-foreground">
                                  {iter.mappings.length} fields
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button
                                onClick={() => handleLoadIteration(entry, iter)}
                                className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium bg-primary/10 text-primary hover:bg-primary hover:text-white transition-colors"
                              >
                                <Eye size={12} />
                                Load & View
                              </button>
                              <button
                                onClick={() => setDeleteConfirm({ type: 'iteration', projectId: entry.projectId, iterationId: iter.iterationId })}
                                className="p-1.5 rounded-md text-muted-foreground hover:text-danger hover:bg-danger/10 transition-colors"
                                title="Delete iteration"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Delete confirmation modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="card-panel p-6 max-w-sm w-full animate-fadeScale">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-danger/10 flex items-center justify-center flex-shrink-0">
                <AlertTriangle size={18} className="text-danger" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">
                  Delete {deleteConfirm.type === 'project' ? 'Project' : 'Iteration'}?
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  This action cannot be undone.
                </p>
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setDeleteConfirm(null)} className="btn-secondary text-sm">
                Cancel
              </button>
              <button
                onClick={() => {
                  if (deleteConfirm.type === 'project') {
                    handleDeleteProject(deleteConfirm.projectId);
                  } else if (deleteConfirm.iterationId) {
                    handleDeleteIteration(deleteConfirm.projectId, deleteConfirm.iterationId);
                  }
                }}
                className="px-4 py-2 rounded-lg text-sm font-medium bg-danger text-white hover:bg-danger/90 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
