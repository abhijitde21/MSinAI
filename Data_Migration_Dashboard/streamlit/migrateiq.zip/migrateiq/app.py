"""
MigrateIQ — main Streamlit entry point.

Run with:
    streamlit run app.py
"""
from __future__ import annotations

import streamlit as st

from config.settings import configure_logging, settings
from database.db import init_db
from database.seed import seed_if_empty
from ui.theme import THEME_CSS

# Pages
from ui.pages import (
    all_defects,
    configuration,
    lineage,
    object_detail,
    overview,
    reconciliation,
)

from backend.services.config_service import list_objects

# ─────────────────────────────────────────────────────────────
# One-time setup
# ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="MigrateIQ — Data Migration Reconciliation",
    page_icon="🔄",
    layout="wide",
    initial_sidebar_state="expanded",
)

configure_logging()
init_db()
seed_if_empty()

st.markdown(THEME_CSS, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────
# Navigation state
# ─────────────────────────────────────────────────────────────
if "target_page" not in st.session_state:
    st.session_state["target_page"] = "overview"
if "selected_object" not in st.session_state:
    st.session_state["selected_object"] = None


# ─────────────────────────────────────────────────────────────
# Top bar
# ─────────────────────────────────────────────────────────────
top_l, top_r = st.columns([6, 2])
with top_l:
    st.markdown(
        """
        <div style="display:flex;align-items:center;gap:10px;
                    padding:4px 0 10px 0">
          <div style="font-size:18px;font-weight:800;color:var(--cyan);
                      letter-spacing:0.4px">MigrateIQ</div>
          <div style="color:var(--muted);font-size:11px">
            Data Migration Reconciliation Platform
          </div>
          <div style="background:rgba(0,212,170,0.12);color:var(--cyan);
                      border:1px solid rgba(0,212,170,0.3);padding:2px 10px;
                      border-radius:20px;font-size:10px;font-weight:700">
            SAP S/4HANA · Wave 1
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
with top_r:
    llm_chip = (
        f"🧠 <b>LLM:</b> Groq · <code>{settings.groq_model}</code>"
        if settings.llm_enabled
        else "🧠 <b>LLM:</b> <span style='color:var(--amber)'>disabled</span> "
             "(set <code>GROQ_API_KEY</code> in <code>.env</code>)"
    )
    st.markdown(
        f'<div style="font-size:11px;color:var(--muted);'
        f'padding:8px 0;text-align:right">{llm_chip}</div>',
        unsafe_allow_html=True,
    )


# ─────────────────────────────────────────────────────────────
# Sidebar navigation
# ─────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(
        "<div style='font-size:10px;color:var(--muted);"
        "letter-spacing:1.2px;padding:4px 0'>PLATFORM</div>",
        unsafe_allow_html=True,
    )
    if st.button("🏠  Overview", use_container_width=True,
                 key="nav_overview",
                 type=("primary" if st.session_state["target_page"] == "overview"
                       else "secondary")):
        st.session_state["target_page"] = "overview"
        st.session_state["selected_object"] = None
        st.rerun()

    if st.button("⚙️  Configuration", use_container_width=True,
                 key="nav_config",
                 type=("primary" if st.session_state["target_page"] == "configuration"
                       else "secondary")):
        st.session_state["target_page"] = "configuration"
        st.rerun()

    st.markdown(
        "<div style='font-size:10px;color:var(--muted);"
        "letter-spacing:1.2px;padding:12px 0 4px 0'>DATA OBJECTS</div>",
        unsafe_allow_html=True,
    )

    for obj in list_objects():
        is_active = (
            st.session_state["target_page"] in ("object", "reconciliation")
            and st.session_state["selected_object"] == obj["code"]
        )
        if st.button(
            f"📦  {obj['label']}",
            key=f"nav_obj_{obj['code']}",
            use_container_width=True,
            type=("primary" if is_active and st.session_state["target_page"] == "object"
                  else "secondary"),
        ):
            st.session_state["selected_object"] = obj["code"]
            st.session_state["target_page"] = "object"
            st.rerun()
        if st.session_state["selected_object"] == obj["code"]:
            recon_active = st.session_state["target_page"] == "reconciliation"
            if st.button(
                "   └ Reconciliation",
                key=f"nav_recon_{obj['code']}",
                use_container_width=True,
                type=("primary" if recon_active else "secondary"),
            ):
                st.session_state["target_page"] = "reconciliation"
                st.rerun()

    st.markdown(
        "<div style='font-size:10px;color:var(--muted);"
        "letter-spacing:1.2px;padding:12px 0 4px 0'>PLATFORM</div>",
        unsafe_allow_html=True,
    )
    if st.button("🛑  All Defects", use_container_width=True,
                 key="nav_defects",
                 type=("primary" if st.session_state["target_page"] == "defects"
                       else "secondary")):
        st.session_state["target_page"] = "defects"
        st.rerun()
    if st.button("🔗  Lineage", use_container_width=True,
                 key="nav_lineage",
                 type=("primary" if st.session_state["target_page"] == "lineage"
                       else "secondary")):
        st.session_state["target_page"] = "lineage"
        st.rerun()

    st.markdown("<hr>", unsafe_allow_html=True)
    st.caption(
        f"SQLite: `{settings.app_db_url.split('///')[-1]}`  \n"
        f"Model: `{settings.groq_model}`"
    )


# ─────────────────────────────────────────────────────────────
# Page router
# ─────────────────────────────────────────────────────────────
target = st.session_state["target_page"]

if target == "overview":
    overview.render()
elif target == "configuration":
    configuration.render()
elif target == "object":
    object_detail.render()
elif target == "reconciliation":
    reconciliation.render()
elif target == "defects":
    all_defects.render()
elif target == "lineage":
    lineage.render()
else:
    overview.render()
