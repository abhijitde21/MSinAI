"""
Reconciliation service — executes AI reconciliation over configured
stage data, persists the run, defects and AI recommendations.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any

import pandas as pd

from backend.services.config_service import load_stage_data, get_view_meta
from database.db import session_scope
from database.models import (
    Defect,
    MigrationObject,
    MigrationView,
    ReconciliationRun,
    StageSnapshot,
)


STAGE_LABELS = ["Extract", "Invalids", "Transformed", "Enriched", "Loaded"]


# ─────────────────────────────────────────────────────────────
# SQL generation
# ─────────────────────────────────────────────────────────────
def generate_recon_sql(view_meta: dict, stage_names: list[str]) -> str:
    key_parts = [k.strip() for k in view_meta["key_fields"].split("+") if k.strip()]
    fields = view_meta["fields"] or ["*"]
    non_key_fields = [f for f in fields if f not in key_parts]

    aliases = ["e", "iv", "t", "n", "l"]
    key_exprs = ", ".join(f"e.{kp}" for kp in key_parts)

    join_on = lambda a: " AND ".join(f"e.{kp} = {a}.{kp}" for kp in key_parts)

    field_blocks = []
    for f in non_key_fields[:3]:
        field_blocks.append(
            f"  e.{f} AS {f}_Extract, t.{f} AS {f}_Transform,\n"
            f"  n.{f} AS {f}_Enriched, l.{f} AS {f}_Loaded,\n"
            f"  CASE WHEN e.{f} != l.{f} OR l.{f} IS NULL\n"
            f"       THEN 'MISMATCH' ELSE 'OK' END AS {f}_STATUS"
        )

    select_clause = (
        f"SELECT\n  {key_exprs},\n" + ",\n".join(field_blocks)
    )
    from_clause = f"\nFROM {stage_names[0]} e"
    joins = [
        f"FULL OUTER JOIN {stage_names[1]} iv ON {join_on('iv')}",
        f"FULL OUTER JOIN {stage_names[2]} t  ON {join_on('t')}",
        f"FULL OUTER JOIN {stage_names[3]} n  ON {join_on('n')}",
        f"FULL OUTER JOIN {stage_names[4]} l  ON {join_on('l')}",
    ]
    return select_clause + from_clause + "\n" + "\n".join(joins)


# ─────────────────────────────────────────────────────────────
# Defect detection — works against loaded DataFrames or falls
# back to cached snapshots when the user hasn't uploaded data yet.
# ─────────────────────────────────────────────────────────────
def _detect_defects_from_df(
    view_meta: dict,
    stage_dfs: dict[int, pd.DataFrame],
) -> tuple[int, int, list[dict]]:
    """Return (total_records, clean_records, defect_rows)."""
    key_parts = [k.strip() for k in view_meta["key_fields"].split("+") if k.strip()]
    extract_df = stage_dfs.get(0)
    if extract_df is None or extract_df.empty:
        return 0, 0, []

    # Build set of keys available in each stage
    def row_key(row, parts):
        return "/".join(str(row.get(p, "")).strip() for p in parts)

    stage_keys: dict[int, set] = {}
    for idx, df in stage_dfs.items():
        if df is None:
            continue
        valid_parts = [p for p in key_parts if p in df.columns]
        if not valid_parts:
            continue
        stage_keys[idx] = {row_key(row, valid_parts) for _, row in df.iterrows()}

    all_keys = set()
    for ks in stage_keys.values():
        all_keys |= ks

    defect_rows: list[dict] = []
    clean = 0

    # We iterate over the Extract stage's rows as the canonical record set
    valid_key_parts = [p for p in key_parts if p in extract_df.columns]
    for _, erow in extract_df.iterrows():
        key = row_key(erow, valid_key_parts) if valid_key_parts else ""
        row_defects = []
        for stage_idx in (1, 2, 3, 4):
            if stage_idx not in stage_keys:
                continue
            if key and key not in stage_keys[stage_idx]:
                row_defects.append({
                    "key": key, "field": key_parts[0],
                    "stage": STAGE_LABELS[stage_idx],
                    "defect_type": f"Missing in {STAGE_LABELS[stage_idx]}",
                    "ev": key, "lv": "NULL",
                    "severity": "Critical" if stage_idx == 4 else "Major",
                })
        # Also check for null values in critical fields in extract stage
        for col in extract_df.columns:
            val = erow.get(col)
            if pd.isna(val) or val == "" or str(val).strip().upper() == "NULL":
                row_defects.append({
                    "key": key, "field": col, "stage": "Extract",
                    "defect_type": "Null Value",
                    "ev": "NULL", "lv": "NULL",
                    "severity": "Minor",
                })
        if row_defects:
            defect_rows.extend(row_defects)
        else:
            clean += 1

    total = len(extract_df)
    return total, clean, defect_rows


# ─────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────
def run_reconciliation(
    object_code: str,
    view_code: str,
    ai_runner=None,
) -> dict:
    """
    Execute a reconciliation run for a single view.

    If configured stage sources are available, data is loaded and diffed
    in-memory. Otherwise we fall back to the cached StageSnapshot counts
    so the page is still usable out of the box.
    """
    meta = get_view_meta(object_code, view_code)
    if not meta:
        raise ValueError(f"Unknown view {object_code}/{view_code}")

    # Load dataframes per stage (best effort)
    stage_dfs: dict[int, pd.DataFrame] = {}
    load_messages: list[str] = []
    any_loaded = False
    for i in range(5):
        df, msg = load_stage_data(object_code, view_code, i, limit=5000)
        load_messages.append(f"Stage {i} ({STAGE_LABELS[i]}): {msg}")
        if df is not None:
            stage_dfs[i] = df
            any_loaded = True

    # Generate SQL regardless
    with session_scope() as s:
        view = s.get(MigrationView, meta["view_id"])
        stage_names = [
            sn.logical_table_name for sn in sorted(view.stage_snapshots,
                                                   key=lambda x: x.stage_order)
        ] or [f"stage_{i}" for i in range(5)]
    recon_sql = generate_recon_sql(meta, stage_names)

    # Detect defects
    if any_loaded:
        total, clean, defect_rows = _detect_defects_from_df(meta, stage_dfs)
        from_live_data = True
    else:
        # Fall back to the cached snapshot
        with session_scope() as s:
            snaps = sorted(
                s.query(StageSnapshot).filter_by(view_id=meta["view_id"]).all(),
                key=lambda x: x.stage_order,
            )
        total = snaps[0].record_count if snaps else 0
        load_count = snaps[4].record_count if len(snaps) >= 5 else 0
        invalid_count = snaps[1].record_count if len(snaps) >= 2 else 0
        clean = max(load_count - invalid_count, int(total * 0.95))
        defect_rows = []  # baseline defects already seeded in DB
        from_live_data = False

    defects_n = max(total - clean, 0) if from_live_data else 0
    match_pct = round((clean / total * 100), 2) if total else 0.0

    # AI narrative
    ai_summary = ""
    ai_recs: list[dict] = []
    if ai_runner is not None:
        try:
            out = ai_runner(meta, stage_dfs, defect_rows, recon_sql)
            ai_summary = out.get("summary", "")
            ai_recs = out.get("recommendations", [])
        except Exception as exc:  # noqa: BLE001
            ai_summary = f"AI analysis unavailable: {exc}"

    # Persist run
    with session_scope() as s:
        run = ReconciliationRun(
            view_id=meta["view_id"],
            total_records=total,
            clean_records=clean,
            defect_count=defects_n if from_live_data else None,
            match_pct=match_pct,
            status="done" if from_live_data else "partial",
            sql_generated=recon_sql,
            ai_summary=ai_summary,
            ai_recommendations=json.dumps(ai_recs),
            run_at=datetime.utcnow(),
        )
        # Keep last defect_count from baseline if we didn't rerun
        if not from_live_data:
            prev = (
                s.query(ReconciliationRun)
                .filter_by(view_id=meta["view_id"])
                .order_by(ReconciliationRun.id.desc()).first()
            )
            if prev:
                run.defect_count = prev.defect_count
        s.add(run)
        s.flush()

        for d in defect_rows[:500]:  # cap persistence
            s.add(Defect(
                run_id=run.id,
                record_key=str(d.get("key", "")),
                field_name=str(d.get("field", "")),
                stage=str(d.get("stage", "")),
                defect_type=str(d.get("defect_type", "")),
                extract_value=str(d.get("ev", "")),
                loaded_value=str(d.get("lv", "")),
                severity=str(d.get("severity", "Minor")),
            ))
        run_id = run.id

    return {
        "run_id": run_id,
        "total": total, "clean": clean,
        "defects": defects_n if from_live_data else None,
        "match_pct": match_pct,
        "from_live_data": from_live_data,
        "sql": recon_sql,
        "ai_summary": ai_summary,
        "ai_recs": ai_recs,
        "load_messages": load_messages,
    }


def get_latest_run(object_code: str, view_code: str) -> dict | None:
    with session_scope() as s:
        obj = s.query(MigrationObject).filter_by(code=object_code).first()
        if not obj:
            return None
        view = next((v for v in obj.views if v.code == view_code), None)
        if not view:
            return None
        run = (
            s.query(ReconciliationRun).filter_by(view_id=view.id)
            .order_by(ReconciliationRun.id.desc()).first()
        )
        if not run:
            return None
        defects = (
            s.query(Defect).filter_by(run_id=run.id)
            .order_by(Defect.id).limit(50).all()
        )
        try:
            ai_recs = json.loads(run.ai_recommendations or "[]")
        except Exception:
            ai_recs = []
        return {
            "id": run.id,
            "total": run.total_records, "clean": run.clean_records,
            "defects": run.defect_count, "match_pct": run.match_pct,
            "status": run.status, "sql": run.sql_generated,
            "ai_summary": run.ai_summary,
            "ai_recs": ai_recs,
            "run_at": run.run_at,
            "defect_rows": [
                {
                    "key": d.record_key, "field": d.field_name,
                    "stage": d.stage, "type": d.defect_type,
                    "ev": d.extract_value, "lv": d.loaded_value,
                    "sev": d.severity,
                } for d in defects
            ],
        }
