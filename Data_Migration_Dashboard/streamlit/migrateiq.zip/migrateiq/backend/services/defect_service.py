"""
Defect service — cross-object defect aggregation for the All Defects page.
"""
from __future__ import annotations

from database.db import session_scope
from database.models import (
    Defect,
    MigrationObject,
    MigrationView,
    ReconciliationRun,
)


def all_defects(object_filter: str = "", severity_filter: str = "") -> list[dict]:
    """Return defects across the latest run per view, with optional filters."""
    with session_scope() as s:
        out: list[dict] = []
        objects = s.query(MigrationObject).all()
        for o in objects:
            if object_filter and o.label != object_filter:
                continue
            for v in o.views:
                run = (
                    s.query(ReconciliationRun).filter_by(view_id=v.id)
                    .order_by(ReconciliationRun.id.desc()).first()
                )
                if not run:
                    continue
                q = s.query(Defect).filter_by(run_id=run.id)
                for d in q.all():
                    if severity_filter and d.severity != severity_filter:
                        continue
                    out.append({
                        "object": o.label,
                        "view": v.label,
                        "key": d.record_key,
                        "field": d.field_name,
                        "stage": d.stage,
                        "defect_type": d.defect_type,
                        "ev": d.extract_value,
                        "lv": d.loaded_value,
                        "severity": d.severity,
                        "run_id": run.id,
                    })
        return out


def defect_counts() -> dict:
    rows = all_defects()
    by_sev = {"Critical": 0, "Major": 0, "Minor": 0}
    for r in rows:
        if r["severity"] in by_sev:
            by_sev[r["severity"]] += 1
    return {"total": len(rows), **by_sev}
