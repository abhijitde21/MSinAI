"""
Migration service — read-side aggregations used by Overview,
Object Detail, and Lineage pages.
"""
from __future__ import annotations

from database.db import session_scope
from database.models import (
    Defect,
    MigrationObject,
    MigrationView,
    ReconciliationRun,
    StageSnapshot,
)


def overview_kpis() -> dict:
    with session_scope() as s:
        snaps = s.query(StageSnapshot).all()
        by_view: dict[int, dict[int, StageSnapshot]] = {}
        for sn in snaps:
            by_view.setdefault(sn.view_id, {})[sn.stage_order] = sn

        total_extract = sum(
            v[0].record_count for v in by_view.values() if 0 in v
        )
        total_load = sum(
            v[4].record_count for v in by_view.values() if 4 in v
        )
        objects = s.query(MigrationObject).all()
        total_defects = 0
        readiness_values = []
        for o in objects:
            readiness_values.append(o.readiness or 0)
            for v in o.views:
                run = (
                    s.query(ReconciliationRun)
                    .filter_by(view_id=v.id)
                    .order_by(ReconciliationRun.id.desc())
                    .first()
                )
                if run:
                    total_defects += run.defect_count or 0
        avg_ready = (
            round(sum(readiness_values) / len(readiness_values))
            if readiness_values else 0
        )
        return {
            "object_count": len(objects),
            "total_extracted": total_extract,
            "total_loaded": total_load,
            "total_defects": total_defects,
            "avg_readiness": avg_ready,
        }


def overview_object_summary() -> list[dict]:
    with session_scope() as s:
        out = []
        objects = s.query(MigrationObject).order_by(MigrationObject.id).all()
        for o in objects:
            views = o.views
            ext = 0
            lod = 0
            recon_done = 0
            defects = 0
            for v in views:
                snaps = {
                    sn.stage_order: sn for sn in
                    s.query(StageSnapshot).filter_by(view_id=v.id).all()
                }
                if 0 in snaps:
                    ext += snaps[0].record_count
                if 4 in snaps:
                    lod += snaps[4].record_count
                run = (
                    s.query(ReconciliationRun).filter_by(view_id=v.id)
                    .order_by(ReconciliationRun.id.desc()).first()
                )
                if run:
                    defects += run.defect_count or 0
                    if run.status == "done":
                        recon_done += 1
            load_pct = round((lod / ext * 100), 1) if ext else 0.0
            out.append({
                "code": o.code, "label": o.label, "sap": o.sap_tables,
                "color_hex": o.color_hex,
                "view_count": len(views),
                "extracted": ext, "loaded": lod, "load_pct": load_pct,
                "defects": defects, "recon_done": recon_done,
                "readiness": o.readiness or 0,
            })
        return out


def get_object_detail(object_code: str) -> dict | None:
    with session_scope() as s:
        obj = s.query(MigrationObject).filter_by(code=object_code).first()
        if not obj:
            return None
        views_out = []
        for v in obj.views:
            snaps = sorted(
                s.query(StageSnapshot).filter_by(view_id=v.id).all(),
                key=lambda x: x.stage_order,
            )
            run = (
                s.query(ReconciliationRun).filter_by(view_id=v.id)
                .order_by(ReconciliationRun.id.desc()).first()
            )
            views_out.append({
                "id": v.id, "code": v.code, "label": v.label,
                "sap_table": v.sap_table, "key_fields": v.key_fields,
                "color_hex": v.color_hex,
                "fields": [f for f in (v.field_list or "").split(",") if f],
                "stages": [
                    {
                        "order": sn.stage_order,
                        "label": sn.stage_label,
                        "logical_name": sn.logical_table_name,
                        "count": sn.record_count,
                        "status": sn.status,
                    } for sn in snaps
                ],
                "recon": None if not run else {
                    "id": run.id,
                    "total": run.total_records,
                    "clean": run.clean_records,
                    "defects": run.defect_count,
                    "match_pct": run.match_pct,
                    "status": run.status,
                },
            })
        return {
            "id": obj.id, "code": obj.code, "label": obj.label,
            "sap": obj.sap_tables, "color_hex": obj.color_hex,
            "readiness": obj.readiness or 0,
            "views": views_out,
        }


def lineage_rows() -> list[dict]:
    """Return cross-object lineage counts for the lineage visualization."""
    with session_scope() as s:
        rows = []
        objects = s.query(MigrationObject).order_by(MigrationObject.id).all()
        for o in objects:
            views = o.views
            agg = [0] * 5
            for v in views:
                for sn in s.query(StageSnapshot).filter_by(view_id=v.id).all():
                    agg[sn.stage_order] += sn.record_count
            run_count = 0
            run_defects = 0
            run_ready = o.readiness or 0
            for v in views:
                run = (
                    s.query(ReconciliationRun).filter_by(view_id=v.id)
                    .order_by(ReconciliationRun.id.desc()).first()
                )
                if run:
                    run_count += 1
                    run_defects += run.defect_count or 0
            rows.append({
                "code": o.code, "label": o.label, "color": o.color_hex,
                "view_count": len(views),
                "stage_counts": agg,
                "recon_done": run_count, "recon_defects": run_defects,
                "readiness": run_ready,
            })
        return rows
