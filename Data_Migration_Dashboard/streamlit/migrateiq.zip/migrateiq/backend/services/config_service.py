"""
Config service — CRUD for stage_configs + connection/file testing.

Supports the new Configuration page. Each migration view has exactly
5 stage configs (Extract, Invalids, Transformed, Enriched, Loaded).
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

from config.settings import UPLOADS_DIR
from database.db import session_scope
from database.models import MigrationObject, MigrationView, StageConfig
from backend.data_loaders.db_loader import test_connection, load_table
from backend.data_loaders.file_loader import test_file, load_file


def list_objects() -> list[dict]:
    with session_scope() as s:
        objs = s.query(MigrationObject).order_by(MigrationObject.id).all()
        return [
            {"id": o.id, "code": o.code, "label": o.label,
             "sap_tables": o.sap_tables, "color_hex": o.color_hex,
             "readiness": o.readiness,
             "view_count": len(o.views)}
            for o in objs
        ]


def list_views(object_code: str) -> list[dict]:
    with session_scope() as s:
        obj = s.query(MigrationObject).filter_by(code=object_code).first()
        if not obj:
            return []
        return [
            {"id": v.id, "code": v.code, "label": v.label,
             "sap_table": v.sap_table, "key_fields": v.key_fields,
             "field_list": v.field_list, "color_hex": v.color_hex}
            for v in obj.views
        ]


def get_stage_configs(object_code: str, view_code: str) -> list[dict]:
    with session_scope() as s:
        obj = s.query(MigrationObject).filter_by(code=object_code).first()
        if not obj:
            return []
        view = next((v for v in obj.views if v.code == view_code), None)
        if not view:
            return []
        return [
            {
                "id": c.id, "stage_order": c.stage_order,
                "stage_label": c.stage_label,
                "logical_table_name": c.logical_table_name,
                "source_type": c.source_type,
                "db_type": c.db_type, "db_host": c.db_host,
                "db_port": c.db_port, "db_name": c.db_name,
                "db_user": c.db_user, "db_password": c.db_password,
                "db_table": c.db_table,
                "file_path": c.file_path, "file_format": c.file_format,
                "file_sheet": c.file_sheet,
                "is_configured": c.is_configured,
                "test_status": c.test_status,
                "test_message": c.test_message,
                "last_tested_at": c.last_tested_at,
            }
            for c in view.stage_configs
        ]


def save_stage_config(config_id: int, payload: dict[str, Any]) -> dict:
    with session_scope() as s:
        cfg = s.get(StageConfig, config_id)
        if not cfg:
            raise ValueError(f"StageConfig {config_id} not found")

        cfg.source_type = payload.get("source_type", cfg.source_type)
        cfg.db_type = payload.get("db_type", cfg.db_type)
        cfg.db_host = payload.get("db_host", cfg.db_host)
        cfg.db_port = int(payload.get("db_port") or cfg.db_port or 3306)
        cfg.db_name = payload.get("db_name", cfg.db_name)
        cfg.db_user = payload.get("db_user", cfg.db_user)
        cfg.db_password = payload.get("db_password", cfg.db_password)
        cfg.db_table = payload.get("db_table", cfg.db_table)
        cfg.file_path = payload.get("file_path", cfg.file_path)
        cfg.file_format = payload.get("file_format", cfg.file_format)
        cfg.file_sheet = payload.get("file_sheet", cfg.file_sheet)
        cfg.is_configured = _is_configured(cfg)
        cfg.updated_at = datetime.utcnow()

        return {"id": cfg.id, "is_configured": cfg.is_configured}


def _is_configured(cfg: StageConfig) -> bool:
    if cfg.source_type == "database":
        return bool(cfg.db_type and cfg.db_name and cfg.db_table)
    if cfg.source_type == "file":
        return bool(cfg.file_path and cfg.file_format)
    return False


def save_uploaded_file(uploaded_bytes: bytes, original_name: str,
                       object_code: str, view_code: str, stage_order: int) -> str:
    """Persist an uploaded file under data/uploads/ and return its path."""
    sub = UPLOADS_DIR / object_code / view_code
    sub.mkdir(parents=True, exist_ok=True)
    safe_name = Path(original_name).name
    out_path = sub / f"stage{stage_order}_{safe_name}"
    out_path.write_bytes(uploaded_bytes)
    return str(out_path)


def test_stage_config(config_id: int) -> dict:
    """Run a live test of the configured source and persist the result."""
    with session_scope() as s:
        cfg = s.get(StageConfig, config_id)
        if not cfg:
            raise ValueError(f"StageConfig {config_id} not found")

        if cfg.source_type == "database":
            ok, msg = test_connection(
                cfg.db_type, cfg.db_host, cfg.db_port, cfg.db_name,
                cfg.db_user, cfg.db_password, cfg.db_table,
            )
        elif cfg.source_type == "file":
            ok, msg = test_file(cfg.file_path, cfg.file_format, cfg.file_sheet)
        else:
            ok, msg = False, "Source type not configured."

        cfg.test_status = "ok" if ok else "failed"
        cfg.test_message = msg
        cfg.last_tested_at = datetime.utcnow()
        return {"ok": ok, "message": msg}


def load_stage_data(object_code: str, view_code: str, stage_order: int,
                    limit: int | None = 200):
    """
    Return a DataFrame for the given (object, view, stage) using whatever
    source is configured. Returns (DataFrame | None, message).
    """
    with session_scope() as s:
        obj = s.query(MigrationObject).filter_by(code=object_code).first()
        if not obj:
            return None, f"Unknown object {object_code}"
        view = next((v for v in obj.views if v.code == view_code), None)
        if not view:
            return None, f"Unknown view {view_code}"
        cfg = next((c for c in view.stage_configs if c.stage_order == stage_order), None)
        if not cfg:
            return None, f"No config for stage {stage_order}"

        try:
            if cfg.source_type == "file":
                df = load_file(cfg.file_path, cfg.file_format, cfg.file_sheet)
                if limit:
                    df = df.head(limit)
                return df, f"Loaded {len(df)} rows from file"
            if cfg.source_type == "database":
                df = load_table(
                    cfg.db_type, cfg.db_host, cfg.db_port, cfg.db_name,
                    cfg.db_user, cfg.db_password, cfg.db_table, limit,
                )
                return df, f"Loaded {len(df)} rows from DB"
            return None, "Not configured"
        except Exception as exc:  # noqa: BLE001
            return None, f"Load error: {exc}"


def get_view_meta(object_code: str, view_code: str) -> dict | None:
    with session_scope() as s:
        obj = s.query(MigrationObject).filter_by(code=object_code).first()
        if not obj:
            return None
        view = next((v for v in obj.views if v.code == view_code), None)
        if not view:
            return None
        return {
            "view_id": view.id,
            "object_id": obj.id,
            "object_code": obj.code,
            "object_label": obj.label,
            "view_code": view.code,
            "view_label": view.label,
            "sap_table": view.sap_table,
            "key_fields": view.key_fields,
            "fields": [f for f in (view.field_list or "").split(",") if f],
            "color_hex": view.color_hex,
        }
