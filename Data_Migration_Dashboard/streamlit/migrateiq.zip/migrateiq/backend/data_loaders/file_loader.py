"""
Load data from uploaded files (CSV or Excel).
"""
from __future__ import annotations

from pathlib import Path
from typing import Tuple

import pandas as pd


class FileLoadError(Exception):
    pass


def load_file(path: str, file_format: str, sheet: str = "") -> pd.DataFrame:
    """
    Load a CSV or XLSX file and return a dataframe.

    Raises FileLoadError on any issue.
    """
    if not path:
        raise FileLoadError("No file path configured.")
    fp = Path(path)
    if not fp.exists():
        raise FileLoadError(f"File not found: {path}")

    fmt = (file_format or "").lower()
    try:
        if fmt == "csv":
            return pd.read_csv(fp)
        if fmt in ("xlsx", "xls", "excel"):
            sheet_name = sheet if sheet else 0
            return pd.read_excel(fp, sheet_name=sheet_name)
        raise FileLoadError(f"Unsupported file format: {file_format}")
    except FileLoadError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise FileLoadError(f"Failed to read file: {exc}") from exc


def test_file(path: str, file_format: str, sheet: str = "") -> Tuple[bool, str]:
    """Best-effort smoke test: try to read first few rows."""
    try:
        fp = Path(path)
        if not fp.exists():
            return False, f"File not found: {path}"
        fmt = (file_format or "").lower()
        if fmt == "csv":
            df = pd.read_csv(fp, nrows=5)
        elif fmt in ("xlsx", "xls", "excel"):
            sn = sheet if sheet else 0
            df = pd.read_excel(fp, sheet_name=sn, nrows=5)
        else:
            return False, f"Unsupported format: {file_format}"
        return True, f"OK — {len(df.columns)} columns detected"
    except Exception as exc:  # noqa: BLE001
        return False, f"Read error: {exc}"
