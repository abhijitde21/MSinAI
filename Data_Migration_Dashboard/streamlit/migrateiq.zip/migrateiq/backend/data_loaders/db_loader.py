"""
Load data from external databases (SQLite / MySQL) that users configure
on the Configuration page for individual migration stage tables.
"""
from __future__ import annotations

from typing import Tuple
from urllib.parse import quote_plus

import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError


class DBLoadError(Exception):
    pass


def build_connection_url(db_type: str, host: str, port: int, name: str,
                         user: str, password: str) -> str:
    """Compose SQLAlchemy URL from config fields."""
    db_type = (db_type or "sqlite").lower()
    if db_type == "sqlite":
        # For sqlite, `name` is treated as a filesystem path.
        return f"sqlite:///{name}"
    if db_type == "mysql":
        pw = quote_plus(password or "")
        return f"mysql+pymysql://{user}:{pw}@{host}:{port or 3306}/{name}"
    raise DBLoadError(f"Unsupported database type: {db_type}")


def test_connection(db_type: str, host: str, port: int, name: str,
                    user: str, password: str, table: str = "") -> Tuple[bool, str]:
    """Attempt a simple SELECT to validate the configuration."""
    try:
        url = build_connection_url(db_type, host, port, name, user, password)
        eng = create_engine(url, connect_args={"connect_timeout": 5} if db_type == "mysql" else {})
        with eng.connect() as conn:
            if table:
                res = conn.execute(text(f"SELECT COUNT(*) FROM {table}"))
                n = res.scalar_one()
                return True, f"OK — {n:,} rows in `{table}`"
            conn.execute(text("SELECT 1"))
            return True, "Connection OK"
    except SQLAlchemyError as exc:
        return False, f"Connection failed: {exc.__class__.__name__}: {str(exc)[:140]}"
    except Exception as exc:  # noqa: BLE001
        return False, f"Error: {exc}"


def load_table(db_type: str, host: str, port: int, name: str, user: str,
               password: str, table: str, limit: int | None = None) -> pd.DataFrame:
    """Load a full table (or up to `limit` rows) into a DataFrame."""
    if not table:
        raise DBLoadError("Table name is required.")
    # Basic guard against injection — allow alphanum, underscore, dot, dash
    import re
    if not re.match(r'^[\w][\w.\-]*$', table):
        raise DBLoadError(f"Invalid table name: {table}")
    try:
        url = build_connection_url(db_type, host, port, name, user, password)
        eng = create_engine(url)
        q = f"SELECT * FROM {table}"
        if limit:
            q += f" LIMIT {int(limit)}"
        return pd.read_sql(q, eng)
    except SQLAlchemyError as exc:
        raise DBLoadError(f"Query failed: {exc}") from exc
    except Exception as exc:  # noqa: BLE001
        raise DBLoadError(f"Load error: {exc}") from exc
