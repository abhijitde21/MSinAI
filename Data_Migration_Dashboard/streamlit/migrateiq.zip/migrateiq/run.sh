#!/usr/bin/env bash
# MigrateIQ — quick start script
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Create venv if missing
if [ ! -d ".venv" ]; then
    echo "🔧 Creating virtual environment..."
    python3 -m venv .venv
fi

# Activate
source .venv/bin/activate

# Install / upgrade deps
echo "📦 Installing dependencies..."
pip install -r requirements.txt -q

# Copy .env if missing
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "📝 Created .env from .env.example — edit it to add your GROQ_API_KEY"
fi

echo "🚀 Starting MigrateIQ on http://localhost:8501"
streamlit run app.py
