"""
SQLAlchemy ORM models for the MigrateIQ platform database.

Schema overview:
- migration_objects   : top-level SAP objects (Material Master, Vendor Master, ...)
- migration_views     : views inside each object (General Data, Plant Data, ...)
- stage_configs       : per (view, stage) config — where to pull data from
- stage_snapshots     : aggregated counts and status for each stage (cached)
- reconciliation_runs : results of an AI reconciliation run per view
- defects             : individual defect records detected during recon
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


# ─────────────────────────────────────────────────────────────
# Migration Objects & Views
# ─────────────────────────────────────────────────────────────
class MigrationObject(Base):
    __tablename__ = "migration_objects"

    id = Column(Integer, primary_key=True)
    code = Column(String(16), unique=True, nullable=False)  # mm, vm, cm, gl
    label = Column(String(128), nullable=False)
    sap_tables = Column(String(256), nullable=False)
    color_hex = Column(String(8), default="#00d4aa")
    readiness = Column(Integer, default=0)
    go_live_date = Column(String(32), default="Jun 30, 2025")
    created_at = Column(DateTime, default=datetime.utcnow)

    views = relationship(
        "MigrationView",
        back_populates="obj",
        cascade="all, delete-orphan",
        order_by="MigrationView.sort_order",
    )


class MigrationView(Base):
    __tablename__ = "migration_views"

    id = Column(Integer, primary_key=True)
    object_id = Column(Integer, ForeignKey("migration_objects.id"), nullable=False)
    code = Column(String(32), nullable=False)           # general, plant, storage, ...
    label = Column(String(128), nullable=False)
    sap_table = Column(String(64), nullable=False)      # MARA, MARC, ...
    key_fields = Column(String(128), nullable=False)    # MATNR / MATNR+WERKS ...
    field_list = Column(Text, default="")               # comma-separated
    color_hex = Column(String(8), default="#00d4aa")
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (UniqueConstraint("object_id", "code", name="uq_view_code"),)

    obj = relationship("MigrationObject", back_populates="views")
    stage_configs = relationship(
        "StageConfig",
        back_populates="view",
        cascade="all, delete-orphan",
        order_by="StageConfig.stage_order",
    )
    stage_snapshots = relationship(
        "StageSnapshot",
        back_populates="view",
        cascade="all, delete-orphan",
        order_by="StageSnapshot.stage_order",
    )
    recon_runs = relationship(
        "ReconciliationRun",
        back_populates="view",
        cascade="all, delete-orphan",
    )


# ─────────────────────────────────────────────────────────────
# Stage Configuration (the NEW page's backing store)
# ─────────────────────────────────────────────────────────────
# Each view has 5 stages: Extract, Invalids, Transformed, Enriched, Loaded.
# For each stage we store where the actual data comes from — either an
# external database table or an uploaded file.
class StageConfig(Base):
    __tablename__ = "stage_configs"

    id = Column(Integer, primary_key=True)
    view_id = Column(Integer, ForeignKey("migration_views.id"), nullable=False)
    stage_order = Column(Integer, nullable=False)    # 0..4
    stage_label = Column(String(32), nullable=False) # Extract / Invalids / ...
    logical_table_name = Column(String(64), nullable=False)  # MM_GEN_EXT ...

    # Source configuration
    source_type = Column(String(16), default="none")  # none | database | file
    # DB connection fields (when source_type='database')
    db_type = Column(String(16), default="sqlite")    # sqlite | mysql
    db_host = Column(String(128), default="")
    db_port = Column(Integer, default=3306)
    db_name = Column(String(128), default="")
    db_user = Column(String(128), default="")
    db_password = Column(String(256), default="")
    db_table = Column(String(128), default="")
    # File fields (when source_type='file')
    file_path = Column(String(512), default="")
    file_format = Column(String(16), default="csv")   # csv | xlsx
    file_sheet = Column(String(64), default="")       # only for xlsx

    is_configured = Column(Boolean, default=False)
    last_tested_at = Column(DateTime, nullable=True)
    test_status = Column(String(32), default="untested")  # untested | ok | failed
    test_message = Column(Text, default="")
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("view_id", "stage_order", name="uq_stage_order"),
    )

    view = relationship("MigrationView", back_populates="stage_configs")


# ─────────────────────────────────────────────────────────────
# Stage Snapshots (cached counts)
# ─────────────────────────────────────────────────────────────
class StageSnapshot(Base):
    __tablename__ = "stage_snapshots"

    id = Column(Integer, primary_key=True)
    view_id = Column(Integer, ForeignKey("migration_views.id"), nullable=False)
    stage_order = Column(Integer, nullable=False)
    stage_label = Column(String(32), nullable=False)
    logical_table_name = Column(String(64), nullable=False)
    record_count = Column(Integer, default=0)
    status = Column(String(16), default="ok")  # ok | warn | err | load
    last_run_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("view_id", "stage_order", name="uq_snap_order"),
    )

    view = relationship("MigrationView", back_populates="stage_snapshots")


# ─────────────────────────────────────────────────────────────
# Reconciliation Results
# ─────────────────────────────────────────────────────────────
class ReconciliationRun(Base):
    __tablename__ = "reconciliation_runs"

    id = Column(Integer, primary_key=True)
    view_id = Column(Integer, ForeignKey("migration_views.id"), nullable=False)
    total_records = Column(Integer, default=0)
    clean_records = Column(Integer, default=0)
    defect_count = Column(Integer, default=0)
    match_pct = Column(Float, default=0.0)
    status = Column(String(16), default="pending")    # pending | done | partial
    sql_generated = Column(Text, default="")
    ai_summary = Column(Text, default="")
    ai_recommendations = Column(Text, default="")    # JSON-encoded list
    run_at = Column(DateTime, default=datetime.utcnow)

    view = relationship("MigrationView", back_populates="recon_runs")
    defects = relationship(
        "Defect",
        back_populates="run",
        cascade="all, delete-orphan",
    )


class Defect(Base):
    __tablename__ = "defects"

    id = Column(Integer, primary_key=True)
    run_id = Column(Integer, ForeignKey("reconciliation_runs.id"), nullable=False)
    record_key = Column(String(128), nullable=False)
    field_name = Column(String(64), nullable=False)
    stage = Column(String(32), default="")
    defect_type = Column(String(64), default="")
    extract_value = Column(String(256), default="")
    loaded_value = Column(String(256), default="")
    severity = Column(String(16), default="Minor")  # Critical | Major | Minor
    created_at = Column(DateTime, default=datetime.utcnow)

    run = relationship("ReconciliationRun", back_populates="defects")
