"""
Seed data for the MigrateIQ platform.

Populates objects, views, stages and baseline snapshots that mirror
the original prototype so the UI is immediately useful after install.
Also drops small sample CSV files under sample_data/ so the user can
try the "File upload" configuration path out of the box.
"""
from __future__ import annotations

import csv
import json
from datetime import datetime
from pathlib import Path

from config.settings import SAMPLE_DATA_DIR
from database.db import session_scope
from database.models import (
    Defect,
    MigrationObject,
    MigrationView,
    ReconciliationRun,
    StageConfig,
    StageSnapshot,
)


# ─────────────────────────────────────────────────────────────
# Specification replicating the prototype
# ─────────────────────────────────────────────────────────────
STAGE_LABELS = ["Extract", "Invalids", "Transformed", "Enriched", "Loaded"]

OBJECTS_SPEC = [
    {
        "code": "mm", "label": "Material Master",
        "sap_tables": "MARA / MARC / MARD / MBEW",
        "color_hex": "#00d4aa", "readiness": 84,
        "views": [
            {"code": "general", "label": "General Data", "sap_table": "MARA/MAKT",
             "key_fields": "MATNR", "color_hex": "#00d4aa",
             "fields": ["MATNR", "MAKTX", "MTART", "MATKL", "MEINS", "MBRSH"],
             "prefix": "MM_GEN",
             "counts": [10000, 200, 9800, 9795, 9795],
             "statuses": ["ok", "err", "ok", "ok", "load"],
             "recon": {"total": 9795, "clean": 9483, "defects": 312, "match_pct": 96.8}},
            {"code": "plant", "label": "Plant Data", "sap_table": "MARC/MRP",
             "key_fields": "MATNR+WERKS", "color_hex": "#3b82f6",
             "fields": ["MATNR", "WERKS", "DISMM", "DISPO", "EKGRP", "MTVFP"],
             "prefix": "MM_PLT",
             "counts": [28400, 420, 27980, 27660, 27650],
             "statuses": ["ok", "err", "ok", "warn", "load"],
             "recon": {"total": 27650, "clean": 27452, "defects": 198, "match_pct": 99.3}},
            {"code": "storage", "label": "Storage Location", "sap_table": "MARD",
             "key_fields": "MATNR+WERKS+LGORT", "color_hex": "#a855f7",
             "fields": ["MATNR", "WERKS", "LGORT", "MINBE", "MABST", "EISBE"],
             "prefix": "MM_SL",
             "counts": [62100, 820, 61280, 61010, 60890],
             "statuses": ["ok", "err", "ok", "ok", "load"],
             "recon": {"total": 60890, "clean": 60766, "defects": 124, "match_pct": 99.8}},
            {"code": "valuation", "label": "Valuation", "sap_table": "MBEW",
             "key_fields": "MATNR+BWKEY", "color_hex": "#f59e0b",
             "fields": ["MATNR", "BWKEY", "VPRSV", "VERPR", "STPRS", "BKLAS"],
             "prefix": "MM_VAL",
             "counts": [18200, 360, 17840, 17440, 17430],
             "statuses": ["ok", "err", "ok", "warn", "err"],
             "recon": {"total": 17430, "clean": 17375, "defects": 55, "match_pct": 99.7}},
        ],
    },
    {
        "code": "vm", "label": "Vendor Master",
        "sap_tables": "LFA1 / LFB1 / LFM1",
        "color_hex": "#3b82f6", "readiness": 92,
        "views": [
            {"code": "general", "label": "General Data", "sap_table": "LFA1",
             "key_fields": "LIFNR", "color_hex": "#3b82f6",
             "fields": ["LIFNR", "NAME1", "LAND1", "SPRAS", "KTOKK", "ADRNR"],
             "prefix": "VM_GEN",
             "counts": [12400, 110, 12290, 12250, 12250],
             "statuses": ["ok", "err", "ok", "ok", "load"],
             "recon": {"total": 12250, "clean": 12180, "defects": 70, "match_pct": 99.4}},
            {"code": "company", "label": "Company Code", "sap_table": "LFB1",
             "key_fields": "LIFNR+BUKRS", "color_hex": "#00d4aa",
             "fields": ["LIFNR", "BUKRS", "AKONT", "ZTERM", "REPRF", "ZWELS"],
             "prefix": "VM_CC",
             "counts": [28000, 140, 27860, 27820, 27800],
             "statuses": ["ok", "err", "ok", "ok", "load"],
             "recon": {"total": 27800, "clean": 27722, "defects": 78, "match_pct": 99.7}},
            {"code": "purchasing", "label": "Purchasing", "sap_table": "LFM1",
             "key_fields": "LIFNR+EKORG", "color_hex": "#a855f7",
             "fields": ["LIFNR", "EKORG", "WAERS", "ZTERM", "INCO1", "INCO2"],
             "prefix": "VM_PUR",
             "counts": [22000, 60, 21940, 21910, 21750],
             "statuses": ["ok", "ok", "ok", "ok", "load"],
             "recon": {"total": 21750, "clean": 21700, "defects": 50, "match_pct": 99.8}},
        ],
    },
    {
        "code": "cm", "label": "Customer Master",
        "sap_tables": "KNA1 / KNB1 / KNVV",
        "color_hex": "#a855f7", "readiness": 72,
        "views": [
            {"code": "general", "label": "General Data", "sap_table": "KNA1",
             "key_fields": "KUNNR", "color_hex": "#a855f7",
             "fields": ["KUNNR", "NAME1", "LAND1", "SPRAS", "KTOKD", "ADRNR"],
             "prefix": "CM_GEN",
             "counts": [18200, 520, 17680, 17500, 17400],
             "statuses": ["ok", "err", "ok", "warn", "warn"],
             "recon": {"total": 17400, "clean": 17052, "defects": 348, "match_pct": 98.0}},
            {"code": "company", "label": "Company Code", "sap_table": "KNB1",
             "key_fields": "KUNNR+BUKRS", "color_hex": "#3b82f6",
             "fields": ["KUNNR", "BUKRS", "AKONT", "ZTERM", "ZWELS", "REPRF"],
             "prefix": "CM_CC",
             "counts": [16000, 380, 15620, 15400, 15300],
             "statuses": ["ok", "err", "ok", "warn", "warn"],
             "recon": None},
            {"code": "sales", "label": "Sales Area", "sap_table": "KNVV",
             "key_fields": "KUNNR+VKORG+VTWEG+SPART", "color_hex": "#ec4899",
             "fields": ["KUNNR", "VKORG", "VTWEG", "SPART", "KALKS", "ZTERM"],
             "prefix": "CM_SA",
             "counts": [14000, 340, 13660, 13400, 13400],
             "statuses": ["ok", "err", "ok", "warn", "warn"],
             "recon": None},
        ],
    },
    {
        "code": "gl", "label": "GL Accounts",
        "sap_tables": "SKA1 / SKB1",
        "color_hex": "#f59e0b", "readiness": 79,
        "views": [
            {"code": "chart", "label": "Chart of Accounts", "sap_table": "SKA1",
             "key_fields": "SAKNR+KTOPL", "color_hex": "#f59e0b",
             "fields": ["SAKNR", "KTOPL", "KTOKS", "BILKT", "XBILK", "GVTYP"],
             "prefix": "GL_COA",
             "counts": [28400, 420, 27980, 27750, 27655],
             "statuses": ["ok", "err", "ok", "ok", "load"],
             "recon": {"total": 27655, "clean": 27521, "defects": 134, "match_pct": 99.5}},
            {"code": "company", "label": "Company Code", "sap_table": "SKB1",
             "key_fields": "SAKNR+BUKRS", "color_hex": "#3b82f6",
             "fields": ["SAKNR", "BUKRS", "WAERS", "XAUTF", "XKRES", "FSTAG"],
             "prefix": "GL_CC",
             "counts": [26800, 400, 26400, 26100, 25500],
             "statuses": ["ok", "err", "ok", "warn", "warn"],
             "recon": None},
        ],
    },
]


SAMPLE_DEFECTS = {
    ("mm", "general"): [
        {"key": "MAT-10046", "field": "MATKL", "stage": "Enriched",
         "type": "Null Enrichment", "ev": "FERT", "lv": "NULL", "sev": "Critical"},
        {"key": "MAT-10047", "field": "MEINS", "stage": "Transformed",
         "type": "Value Mismatch", "ev": "L", "lv": "KG", "sev": "Major"},
        {"key": "MAT-10049", "field": "MATNR", "stage": "Extract",
         "type": "Null Extract", "ev": "NULL", "lv": "NULL", "sev": "Critical"},
    ],
    ("mm", "valuation"): [
        {"key": "MAT-10046/1000", "field": "VPRSV", "stage": "Transformed",
         "type": "Price Ctrl Mismatch", "ev": "V", "lv": "S", "sev": "Critical"},
        {"key": "MAT-10049/1000", "field": "STPRS", "stage": "Enriched",
         "type": "Null Price", "ev": "145.50", "lv": "NULL", "sev": "Major"},
    ],
    ("mm", "plant"): [
        {"key": "MAT-10046/1000", "field": "DISMM", "stage": "Enriched",
         "type": "Null Enrichment", "ev": "ND", "lv": "NULL", "sev": "Major"},
    ],
    ("mm", "storage"): [
        {"key": "MAT-10047/2000/0001", "field": "MINBE", "stage": "Enriched",
         "type": "Null Enrichment", "ev": "0", "lv": "NULL", "sev": "Minor"},
    ],
    ("vm", "general"): [
        {"key": "VEN-003", "field": "ADRNR", "stage": "Enriched",
         "type": "Null Address", "ev": "10003", "lv": "NULL", "sev": "Major"},
    ],
    ("vm", "company"): [
        {"key": "VEN-005/2000", "field": "AKONT", "stage": "Transformed",
         "type": "Invalid GL Account", "ev": "160999", "lv": "NULL", "sev": "Critical"},
    ],
    ("cm", "general"): [
        {"key": "CUS-003", "field": "ADRNR", "stage": "Enriched",
         "type": "Null Enrichment", "ev": "20003", "lv": "NULL", "sev": "Major"},
        {"key": "CUS-001/2000", "field": "AKONT", "stage": "Transformed",
         "type": "Invalid Recon Acct", "ev": "140999", "lv": "NULL", "sev": "Critical"},
    ],
    ("gl", "chart"): [
        {"key": "400000/INT", "field": "KTOKS", "stage": "Transformed",
         "type": "Invalid Acct Group", "ev": "OLD-G", "lv": "NULL", "sev": "Major"},
        {"key": "500000/INT", "field": "BILKT", "stage": "Enriched",
         "type": "Null Alt Account", "ev": "500000", "lv": "NULL", "sev": "Minor"},
    ],
}


SAMPLE_ROWS = {
    ("mm", "general"): [
        ["MAT-10045", "Steel Plate 10mm", "ROH", "ROH", "KG", "M"],
        ["MAT-10046", "Housing Assy", "FERT", "FERT", "EA", "M"],
        ["MAT-10047", "Semi Frame", "HALB", "HALB", "L", "M"],
        ["MAT-10049", "Connector 2m", "ROH", "", "M", "E"],
    ],
    ("mm", "plant"): [
        ["MAT-10045", "1000", "PD", "001", "010", "02"],
        ["MAT-10045", "2000", "VB", "002", "020", "01"],
        ["MAT-10046", "1000", "ND", "", "010", ""],
    ],
    ("mm", "storage"): [
        ["MAT-10045", "1000", "0001", "10", "500", "50"],
        ["MAT-10046", "1000", "0001", "5", "100", "10"],
        ["MAT-10047", "2000", "0001", "0", "150", ""],
    ],
    ("mm", "valuation"): [
        ["MAT-10045", "1000", "S", "", "145.50", "3000"],
        ["MAT-10046", "1000", "V", "98.20", "", "7920"],
        ["MAT-10049", "1000", "S", "", "", "3000"],
    ],
    ("vm", "general"): [
        ["VEN-001", "ABC Supplies", "DE", "EN", "KRED", "10001"],
        ["VEN-002", "XYZ Trading", "US", "EN", "KRED", "10002"],
        ["VEN-003", "Parts Co", "GB", "EN", "KRED", ""],
    ],
    ("vm", "company"): [
        ["VEN-001", "1000", "160000", "Z030", "", "T"],
        ["VEN-002", "1000", "160000", "Z014", "X", "B"],
        ["VEN-003", "2000", "160000", "", "", "T"],
    ],
    ("vm", "purchasing"): [
        ["VEN-001", "1000", "EUR", "Z030", "EXW", "Hamburg"],
        ["VEN-002", "1000", "USD", "Z014", "FOB", "New York"],
        ["VEN-003", "1000", "GBP", "", "CIF", "London"],
    ],
    ("cm", "general"): [
        ["CUS-001", "Acme Corp", "DE", "EN", "DEBI", "20001"],
        ["CUS-002", "Global Ltd", "US", "EN", "DEBI", "20002"],
        ["CUS-003", "Trade GmbH", "DE", "DE", "DEBI", ""],
    ],
    ("cm", "company"): [
        ["CUS-001", "1000", "140000", "Z030", "T", ""],
        ["CUS-002", "1000", "140000", "Z014", "B", "X"],
    ],
    ("cm", "sales"): [
        ["CUS-001", "1000", "10", "00", "A", "Z030"],
        ["CUS-002", "1000", "10", "00", "A", "Z014"],
    ],
    ("gl", "chart"): [
        ["100000", "INT", "B", "", "X", "X"],
        ["200000", "INT", "B", "", "X", "S"],
        ["300000", "INT", "G", "100000", "", ""],
    ],
    ("gl", "company"): [
        ["100000", "1000", "EUR", "X", "", ""],
        ["200000", "1000", "EUR", "X", "X", ""],
        ["300000", "2000", "USD", "", "", ""],
    ],
}


def _create_sample_csv(view_code_pair: tuple, fields: list[str], rows: list[list]) -> str:
    obj_code, view_code = view_code_pair
    path = SAMPLE_DATA_DIR / f"{obj_code}_{view_code}_extract.csv"
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(fields)
        writer.writerows(rows)
    return str(path)


def seed_if_empty() -> None:
    """Populate database only if it has no migration objects yet."""
    SAMPLE_DATA_DIR.mkdir(exist_ok=True)

    with session_scope() as s:
        if s.query(MigrationObject).count() > 0:
            return

        for obj_spec in OBJECTS_SPEC:
            obj = MigrationObject(
                code=obj_spec["code"],
                label=obj_spec["label"],
                sap_tables=obj_spec["sap_tables"],
                color_hex=obj_spec["color_hex"],
                readiness=obj_spec["readiness"],
            )
            s.add(obj)
            s.flush()

            for vidx, v_spec in enumerate(obj_spec["views"]):
                view = MigrationView(
                    object_id=obj.id,
                    code=v_spec["code"],
                    label=v_spec["label"],
                    sap_table=v_spec["sap_table"],
                    key_fields=v_spec["key_fields"],
                    field_list=",".join(v_spec["fields"]),
                    color_hex=v_spec["color_hex"],
                    sort_order=vidx,
                )
                s.add(view)
                s.flush()

                # Build sample CSV for the extract stage
                sample_rows = SAMPLE_ROWS.get((obj_spec["code"], v_spec["code"]), [])
                csv_path = None
                if sample_rows:
                    csv_path = _create_sample_csv(
                        (obj_spec["code"], v_spec["code"]),
                        v_spec["fields"],
                        sample_rows,
                    )

                # Create stage configs & snapshots
                for stage_order, stage_label in enumerate(STAGE_LABELS):
                    suffix = {"Extract": "EXT", "Invalids": "INV",
                              "Transformed": "TRN", "Enriched": "ENR",
                              "Loaded": "LOD"}[stage_label]
                    logical_name = f"{v_spec['prefix']}_{suffix}"
                    cfg = StageConfig(
                        view_id=view.id,
                        stage_order=stage_order,
                        stage_label=stage_label,
                        logical_table_name=logical_name,
                        source_type="file" if (stage_order == 0 and csv_path) else "none",
                        file_path=csv_path if (stage_order == 0 and csv_path) else "",
                        file_format="csv" if (stage_order == 0 and csv_path) else "csv",
                        is_configured=bool(stage_order == 0 and csv_path),
                    )
                    s.add(cfg)

                    snap = StageSnapshot(
                        view_id=view.id,
                        stage_order=stage_order,
                        stage_label=stage_label,
                        logical_table_name=logical_name,
                        record_count=v_spec["counts"][stage_order],
                        status=v_spec["statuses"][stage_order],
                        last_run_at=datetime.utcnow(),
                    )
                    s.add(snap)

                # Seed reconciliation run if the prototype had one
                r = v_spec.get("recon")
                if r:
                    run = ReconciliationRun(
                        view_id=view.id,
                        total_records=r["total"],
                        clean_records=r["clean"],
                        defect_count=r["defects"],
                        match_pct=r["match_pct"],
                        status="done",
                        ai_summary=(
                            f"Initial reconciliation baseline for "
                            f"{v_spec['label']} ({obj_spec['label']})."
                        ),
                        ai_recommendations=json.dumps([]),
                    )
                    s.add(run)
                    s.flush()

                    # Seed sample defects
                    for d in SAMPLE_DEFECTS.get((obj_spec["code"], v_spec["code"]), []):
                        s.add(Defect(
                            run_id=run.id,
                            record_key=d["key"],
                            field_name=d["field"],
                            stage=d["stage"],
                            defect_type=d["type"],
                            extract_value=d["ev"],
                            loaded_value=d["lv"],
                            severity=d["sev"],
                        ))
