"""
LangGraph-powered reconciliation agent.

Graph:
  prepare_context ─▶ call_llm ─▶ parse_output ─▶ END
                         │
                         ▼
                   rule_based_fallback (used when LLM disabled / errored)

The agent receives the same input shape that `reconciliation_service.run_reconciliation`
expects from its `ai_runner` callback: (view_meta, stage_dfs, defect_rows, recon_sql).
It returns {"summary": str, "recommendations": list[dict]}.
"""
from __future__ import annotations

import json
import logging
from typing import Any, TypedDict

import pandas as pd

from ai.groq_client import chat
from ai.agents.prompts import RECON_ANALYSIS_TEMPLATE, RECON_SYSTEM_PROMPT
from config.settings import settings

logger = logging.getLogger(__name__)


class AgentState(TypedDict, total=False):
    view_meta: dict
    stage_dfs: dict
    defect_rows: list
    recon_sql: str
    prompt: str
    raw_response: str
    summary: str
    recommendations: list
    error: str


# ─────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────
def _format_stage_table(view_meta: dict, stage_dfs: dict[int, pd.DataFrame]) -> str:
    """Build a text table of stage counts for the prompt."""
    stage_labels = ["Extract", "Invalids", "Transformed", "Enriched", "Loaded"]
    lines = [f"{'Stage':<14} | {'Records':>10}"]
    lines.append("-" * 32)
    for i, lbl in enumerate(stage_labels):
        df = stage_dfs.get(i)
        n = len(df) if df is not None else 0
        lines.append(f"{lbl:<14} | {n:>10,}")
    return "\n".join(lines)


def _format_defect_table(defect_rows: list[dict], limit: int = 10) -> str:
    if not defect_rows:
        return "(no defects sampled)"
    lines = [f"{'Key':<22}{'Field':<10}{'Stage':<13}{'Type':<24}{'Sev':<10}"]
    for d in defect_rows[:limit]:
        lines.append(
            f"{str(d.get('key',''))[:20]:<22}"
            f"{str(d.get('field',''))[:8]:<10}"
            f"{str(d.get('stage',''))[:11]:<13}"
            f"{str(d.get('defect_type',''))[:22]:<24}"
            f"{str(d.get('severity',''))[:8]:<10}"
        )
    return "\n".join(lines)


def _rule_based_analysis(view_meta: dict, stage_dfs: dict,
                         defect_rows: list[dict]) -> dict:
    """Deterministic fallback when LLM is not available."""
    total = len(stage_dfs.get(0, [])) if stage_dfs.get(0) is not None else 0
    n_def = len(defect_rows)

    by_sev: dict[str, int] = {"Critical": 0, "Major": 0, "Minor": 0}
    by_type: dict[str, int] = {}
    for d in defect_rows:
        sev = d.get("severity", "Minor")
        by_sev[sev] = by_sev.get(sev, 0) + 1
        t = d.get("defect_type", "Unknown")
        by_type[t] = by_type.get(t, 0) + 1

    if n_def == 0:
        summary = (
            f"Reconciliation for {view_meta['view_label']} "
            f"({view_meta['object_label']}) has no defects in the current sample. "
            f"All {total} extract records align across all five stages."
        )
    else:
        summary = (
            f"{view_meta['view_label']} reconciliation has {n_def} "
            f"defects flagged ({by_sev['Critical']} Critical, "
            f"{by_sev['Major']} Major, {by_sev['Minor']} Minor) against "
            f"{total} extract records. Priority action is resolving the "
            f"Critical defects before load sign-off."
        )

    recs: list[dict] = []
    for t, cnt in sorted(by_type.items(), key=lambda x: -x[1])[:3]:
        if "Null" in t:
            sev = "Critical" if cnt > 5 else "Major"
            body = (
                f"{cnt} records have null values of type '{t}'. "
                f"Check the enrichment rules and source extract SQL; "
                f"add a DEFAULT mapping or rerun the enrichment job for "
                f"affected keys."
            )
        elif "Mismatch" in t or "Value" in t:
            sev = "Major"
            body = (
                f"{cnt} records show value mutation flagged as '{t}'. "
                f"Inspect transformation rules and any lookup tables used "
                f"between Extract and Loaded stages."
            )
        elif "Missing" in t:
            sev = "Critical"
            body = (
                f"{cnt} records are missing in a downstream stage ('{t}'). "
                f"Recheck load filters, rejection logs, and staging-table "
                f"write permissions."
            )
        else:
            sev = "Minor"
            body = f"{cnt} records show '{t}'. Review during next validation cycle."
        recs.append({"severity": sev, "title": f"{t} — {cnt} records", "body": body})

    if not recs:
        recs.append({
            "severity": "Minor",
            "title": "No defects detected in sampled data",
            "body": "Run a full load and rerun reconciliation before go-live.",
        })

    return {"summary": summary, "recommendations": recs}


# ─────────────────────────────────────────────────────────────
# Graph nodes
# ─────────────────────────────────────────────────────────────
def prepare_context(state: AgentState) -> AgentState:
    vm = state["view_meta"]
    stage_dfs = state.get("stage_dfs") or {}
    defects = state.get("defect_rows") or []
    prompt = RECON_ANALYSIS_TEMPLATE.format(
        object_label=vm["object_label"],
        view_label=vm["view_label"],
        sap_table=vm["sap_table"],
        key_fields=vm["key_fields"],
        stage_table=_format_stage_table(vm, stage_dfs),
        defect_sample_size=min(10, len(defects)),
        defect_total=len(defects),
        defect_table=_format_defect_table(defects),
        recon_sql=(state.get("recon_sql") or "")[:1500],
    )
    return {**state, "prompt": prompt}


def call_llm(state: AgentState) -> AgentState:
    if not settings.llm_enabled:
        return {**state, "error": "LLM disabled"}
    try:
        response = chat(
            messages=[
                {"role": "system", "content": RECON_SYSTEM_PROMPT},
                {"role": "user", "content": state["prompt"]},
            ],
            temperature=0.2,
            max_tokens=900,
        )
        return {**state, "raw_response": response}
    except Exception as exc:  # noqa: BLE001
        logger.warning("LLM call failed: %s", exc)
        return {**state, "error": str(exc)}


def parse_output(state: AgentState) -> AgentState:
    raw = state.get("raw_response", "") or ""
    text = raw.strip()
    # Strip common code-fences
    for fence in ("```json", "```JSON", "```"):
        if text.startswith(fence):
            text = text[len(fence):].lstrip()
    if text.endswith("```"):
        text = text[:-3].rstrip()
    try:
        data = json.loads(text)
        summary = str(data.get("summary", "")).strip()
        recs = data.get("recommendations") or []
        if not isinstance(recs, list):
            recs = []
        normalised = []
        for r in recs:
            if isinstance(r, dict):
                normalised.append({
                    "severity": str(r.get("severity", "Minor")),
                    "title": str(r.get("title", "")),
                    "body": str(r.get("body", "")),
                })
        return {**state, "summary": summary, "recommendations": normalised}
    except Exception as exc:  # noqa: BLE001
        logger.info("LLM JSON parse failed, falling back: %s", exc)
        return {**state, "error": f"parse failed: {exc}"}


def rule_based_fallback(state: AgentState) -> AgentState:
    out = _rule_based_analysis(
        state["view_meta"],
        state.get("stage_dfs") or {},
        state.get("defect_rows") or [],
    )
    return {**state, "summary": out["summary"],
            "recommendations": out["recommendations"]}


# ─────────────────────────────────────────────────────────────
# Graph assembly
# ─────────────────────────────────────────────────────────────
_graph = None


def _build_graph():
    global _graph
    if _graph is not None:
        return _graph
    try:
        from langgraph.graph import StateGraph, END  # noqa: PLC0415
    except Exception as exc:  # noqa: BLE001
        logger.warning("LangGraph unavailable, using linear flow: %s", exc)
        _graph = None
        return None

    sg = StateGraph(AgentState)
    sg.add_node("prepare", prepare_context)
    sg.add_node("call_llm", call_llm)
    sg.add_node("parse", parse_output)
    sg.add_node("fallback", rule_based_fallback)

    sg.set_entry_point("prepare")
    sg.add_edge("prepare", "call_llm")

    def after_llm(state: AgentState):
        return "fallback" if state.get("error") else "parse"

    def after_parse(state: AgentState):
        return "fallback" if state.get("error") else END

    sg.add_conditional_edges("call_llm", after_llm,
                             {"parse": "parse", "fallback": "fallback"})
    sg.add_conditional_edges("parse", after_parse,
                             {END: END, "fallback": "fallback"})
    sg.add_edge("fallback", END)

    _graph = sg.compile()
    return _graph


# ─────────────────────────────────────────────────────────────
# Public entry point used by reconciliation_service
# ─────────────────────────────────────────────────────────────
def run_recon_agent(view_meta: dict, stage_dfs: dict,
                    defect_rows: list[dict], recon_sql: str) -> dict:
    """
    Top-level agent entry point. Safe against any failure — always
    returns {summary, recommendations}.
    """
    state: AgentState = {
        "view_meta": view_meta,
        "stage_dfs": stage_dfs,
        "defect_rows": defect_rows,
        "recon_sql": recon_sql,
    }

    graph = _build_graph()
    if graph is not None:
        try:
            final_state = graph.invoke(state)
        except Exception as exc:  # noqa: BLE001
            logger.warning("LangGraph invoke failed: %s", exc)
            final_state = rule_based_fallback(state)
    else:
        # Linear path without LangGraph
        s1 = prepare_context(state)
        s2 = call_llm(s1)
        if s2.get("error"):
            final_state = rule_based_fallback(s2)
        else:
            s3 = parse_output(s2)
            final_state = s3 if not s3.get("error") else rule_based_fallback(s3)

    return {
        "summary": final_state.get("summary", "") or "",
        "recommendations": final_state.get("recommendations", []) or [],
    }
