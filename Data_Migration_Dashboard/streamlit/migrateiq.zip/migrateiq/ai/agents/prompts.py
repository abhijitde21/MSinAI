"""
Prompt templates for the LangGraph reconciliation agent.
"""

RECON_SYSTEM_PROMPT = """You are a senior SAP data-migration reconciliation analyst.
Your job is to review reconciliation output across five migration stages
(Extract → Invalids → Transformed → Enriched → Loaded), explain what is
wrong in plain business English, and recommend concrete fixes.

Constraints:
- Be concise. Use short paragraphs or bullet points, no marketing tone.
- Never invent record counts; only cite numbers from the data supplied.
- When suggesting SQL, use ANSI-ish SQL that a developer can adapt.
- Flag critical defects (null propagation, value mutation, missing GL
  accounts, invalid reconciliation accounts) distinctly from minor ones.
"""


RECON_ANALYSIS_TEMPLATE = """Migration Object: {object_label}
View           : {view_label}  ({sap_table})
Key Field(s)   : {key_fields}

Stage snapshot (record counts):
{stage_table}

Defect sample (top {defect_sample_size} of {defect_total}):
{defect_table}

Generated Reconciliation SQL:
{recon_sql}

Provide:
1. A 2-3 sentence executive summary of reconciliation health for this view.
2. A prioritized list of 2-4 recommendations. For each: severity
   (Critical / Major / Minor), root-cause hypothesis, and specific fix
   (add mapping, rerun enrichment, patch SQL, etc).
Respond in the following JSON structure exactly:
{{
  "summary": "...",
  "recommendations": [
    {{"severity": "Critical", "title": "...", "body": "..."}},
    ...
  ]
}}
No extra text outside the JSON.
"""


FIX_SQL_PROMPT = """Generate a SQL UPDATE or MERGE fragment that remediates this
defect class. Be pragmatic: assume target is SAP staging tables.

Object : {object_label}
View   : {view_label}
Defect : {defect_type}
Field  : {field}
Key    : {record_key}
Extract value : {ev}
Loaded value  : {lv}

Return only the SQL in a fenced code block.
"""
