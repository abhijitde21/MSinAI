"""
Thin wrapper around the Groq API, reused by the LangGraph agent and
any direct callers.

If no GROQ_API_KEY is configured we fall back to deterministic rule
based text so every feature remains usable.
"""
from __future__ import annotations

import logging
from typing import Optional

from config.settings import settings

logger = logging.getLogger(__name__)

_client = None


def get_client():
    """Lazy-initialise a groq.Groq client. Returns None if disabled."""
    global _client
    if not settings.llm_enabled:
        return None
    if _client is not None:
        return _client
    try:
        from groq import Groq  # noqa: PLC0415
        _client = Groq(api_key=settings.groq_api_key)
        return _client
    except Exception as exc:  # noqa: BLE001
        logger.warning("Groq client init failed: %s", exc)
        return None


def chat(messages: list[dict], *, model: Optional[str] = None,
         temperature: float = 0.2, max_tokens: int = 900) -> str:
    """
    Send a chat completion and return the assistant text.

    Raises RuntimeError if the LLM is disabled — callers should check
    `settings.llm_enabled` first and provide a rule-based fallback.
    """
    client = get_client()
    if client is None:
        raise RuntimeError("Groq API is not configured")

    resp = client.chat.completions.create(
        model=model or settings.groq_model,
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    try:
        return resp.choices[0].message.content or ""
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"Unexpected response shape: {exc}") from exc
