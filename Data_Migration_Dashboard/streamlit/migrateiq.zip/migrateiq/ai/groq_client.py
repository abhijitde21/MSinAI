"""
Thin wrapper around the Groq API, reused by the LangGraph agent and
any direct callers.

If no GROQ_API_KEY is configured we fall back to deterministic rule
based text so every feature remains usable.

Handles the httpx >=0.28 / groq SDK incompatibility where the SDK
passes the deprecated `proxies` kwarg to httpx.Client.
"""
from __future__ import annotations

import logging
from typing import Optional

from config.settings import settings

logger = logging.getLogger(__name__)

_client = None


def _build_groq_client():
    """
    Build a groq.Groq client, working around the httpx 0.28+
    'proxies' → 'proxy' rename that breaks older groq SDK versions.
    """
    from groq import Groq  # noqa: PLC0415

    # Attempt 1: normal init (works when httpx < 0.28)
    try:
        return Groq(api_key=settings.groq_api_key)
    except TypeError as exc:
        if "proxies" not in str(exc):
            raise
        logger.info("Working around httpx/groq proxies incompatibility")

    # Attempt 2: supply our own httpx client so the SDK skips its
    # internal Client(..., proxies=...) call.
    try:
        import httpx  # noqa: PLC0415
        custom_http = httpx.Client(
            base_url="https://api.groq.com",
            timeout=httpx.Timeout(60.0, connect=10.0),
            follow_redirects=True,
        )
        return Groq(
            api_key=settings.groq_api_key,
            http_client=custom_http,
        )
    except Exception:
        pass

    # Attempt 3: monkey-patch httpx.Client to silently drop `proxies`
    try:
        import httpx  # noqa: PLC0415
        _orig_init = httpx.Client.__init__

        def _patched_init(self, *args, **kwargs):
            kwargs.pop("proxies", None)
            return _orig_init(self, *args, **kwargs)

        httpx.Client.__init__ = _patched_init
        client = Groq(api_key=settings.groq_api_key)
        httpx.Client.__init__ = _orig_init  # restore
        return client
    except Exception as exc:
        logger.warning("All Groq init strategies failed: %s", exc)
        raise


def get_client():
    """Lazy-initialise a groq.Groq client. Returns None if disabled."""
    global _client
    if not settings.llm_enabled:
        return None
    if _client is not None:
        return _client
    try:
        _client = _build_groq_client()
        logger.info("Groq client initialised (model=%s)", settings.groq_model)
        return _client
    except Exception as exc:  # noqa: BLE001
        logger.warning("Groq client init failed: %s", exc)
        return None


def chat(messages: list[dict], *, model: Optional[str] = None,
         temperature: float = 0.2, max_tokens: int = 900) -> str:
    """
    Send a chat completion and return the assistant text.

    Raises RuntimeError if the LLM is disabled — callers should check
    `settings.llm_enabled` first and provide a rule-based fallback.
    """
    client = get_client()
    if client is None:
        raise RuntimeError("Groq API is not configured")

    resp = client.chat.completions.create(
        model=model or settings.groq_model,
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    try:
        return resp.choices[0].message.content or ""
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"Unexpected response shape: {exc}") from exc
