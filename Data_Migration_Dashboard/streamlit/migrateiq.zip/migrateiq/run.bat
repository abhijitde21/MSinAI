@echo off
REM MigrateIQ — quick start script (Windows)
cd /d "%~dp0"

IF NOT EXIST ".venv" (
    echo Creating virtual environment...
    python -m venv .venv
)

call .venv\Scripts\activate

echo Installing dependencies...
pip install -r requirements.txt -q

IF NOT EXIST ".env" (
    copy .env.example .env
    echo Created .env from .env.example
)

echo Starting MigrateIQ on http://localhost:8501
streamlit run app.py
