"""
Application settings.

Centralizes all configuration reading from environment variables with
sensible defaults so the app runs even without a .env file.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
SAMPLE_DATA_DIR = PROJECT_ROOT / "sample_data"
UPLOADS_DIR = DATA_DIR / "uploads"

DATA_DIR.mkdir(exist_ok=True)
UPLOADS_DIR.mkdir(exist_ok=True)


@dataclass(frozen=True)
class Settings:
    groq_api_key: str
    groq_model: str
    app_db_url: str
    log_level: str

    @property
    def llm_enabled(self) -> bool:
        return bool(self.groq_api_key and self.groq_api_key.strip())


def _load_settings() -> Settings:
    return Settings(
        groq_api_key=os.getenv("GROQ_API_KEY", "").strip(),
        groq_model=os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile").strip(),
        app_db_url=os.getenv("APP_DB_URL", "").strip() or f"sqlite:///{DATA_DIR / 'migrateiq.db'}",
        log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
    )


settings = _load_settings()


def configure_logging() -> None:
    logging.basicConfig(
        level=getattr(logging, settings.log_level, logging.INFO),
        format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
    )
