"""Lineage page — cross-object data flow visualization."""
from __future__ import annotations

import streamlit as st

from backend.services.migration_service import lineage_rows
from ui.components import page_title


STAGE_HEADERS = ["EXTRACT", "INVALIDS", "TRANSFORM", "ENRICHED", "LOADED", "RECON"]
STAGE_BORDERS = ["#00d4aa", "#ef4444", "#3b82f6", "#a855f7", "#22c55e", "#f59e0b"]
STAGE_BG = [
    "rgba(0,212,170,0.08)", "rgba(239,68,68,0.06)", "rgba(59,130,246,0.07)",
    "rgba(168,85,247,0.07)", "rgba(34,197,94,0.07)", "rgba(245,158,11,0.08)",
]


def render() -> None:
    page_title(
        "Cross-Object Lineage",
        "Data flow overview across all objects and stages",
    )

    rows = lineage_rows()
    if not rows:
        st.info("No lineage data available.")
        return

    parts: list[str] = ['<div class="miq-card" style="overflow-x:auto">']

    # Column headers
    parts.append(
        '<div style="display:grid;grid-template-columns:repeat(6,1fr);'
        'gap:8px;min-width:900px;margin-bottom:10px">'
    )
    for h in STAGE_HEADERS:
        parts.append(
            f'<div style="text-align:center;font-size:10px;color:var(--muted);'
            f'font-weight:700;letter-spacing:1px">{h}</div>'
        )
    parts.append("</div>")

    for obj in rows:
        parts.append(
            '<div style="display:grid;grid-template-columns:repeat(6,1fr);'
            'gap:8px;min-width:900px;margin-bottom:12px">'
        )

        base = max(obj["stage_counts"][0] or 1, 1)

        for i in range(5):
            cnt = obj["stage_counts"][i]
            border = STAGE_BORDERS[i]
            bg = STAGE_BG[i]
            title_color = obj["color"] if i == 0 else border

            if i == 0:
                title = obj["label"]
                subtitle = f"{obj['view_count']} views"
            else:
                pct = round(cnt / base * 100, 1)
                if i == 1:
                    subtitle = f"{pct}% reject"
                elif i == 4:
                    subtitle = f"{pct}% of extract"
                else:
                    subtitle = f"{pct}% carried"
                title = f"{cnt:,} records"

            parts.append(
                f'<div style="border:1px solid {border};background:{bg};'
                f'border-radius:6px;padding:10px;min-height:74px">'
                f'<div style="font-size:10px;color:{title_color};'
                f'font-weight:700">{title}</div>'
                f'<div style="font-size:16px;font-weight:800;color:var(--text);'
                f'margin-top:4px">{cnt:,}</div>'
                f'<div style="font-size:9px;color:var(--muted);'
                f'margin-top:2px">{subtitle}</div>'
                f'</div>'
            )

        recon_color = (
            "#22c55e" if obj["readiness"] >= 90
            else "#f59e0b" if obj["readiness"] >= 80
            else "#ef4444"
        )
        parts.append(
            f'<div style="border:1px solid {recon_color};'
            f'background:rgba(245,158,11,0.08);border-radius:6px;'
            f'padding:10px;min-height:74px">'
            f'<div style="font-size:10px;color:{recon_color};'
            f'font-weight:700">Recon</div>'
            f'<div style="font-size:16px;font-weight:800;color:var(--text);'
            f'margin-top:4px">{obj["stage_counts"][4]:,}</div>'
            f'<div style="font-size:9px;color:{recon_color};margin-top:2px">'
            f'{obj["readiness"]}% ready · {obj["recon_defects"]} defects'
            f'</div></div>'
        )

        parts.append("</div>")

    parts.append("</div>")
    st.markdown("".join(parts), unsafe_allow_html=True)

    # Flow summary
    st.markdown(" ")
    summary = [
        '<div class="miq-card">'
        '<div class="miq-card-title">Flow Summary</div>'
    ]
    for obj in rows:
        base = max(obj["stage_counts"][0], 1)
        loaded = obj["stage_counts"][4]
        load_pct = round(loaded / base * 100, 1)
        summary.append(
            f'<div style="font-size:12px;margin:6px 0">'
            f'<b style="color:{obj["color"]}">{obj["label"]}</b> — '
            f'{base:,} extracted → {loaded:,} loaded '
            f'(<b>{load_pct}%</b>), {obj["recon_defects"]} defects, '
            f'readiness {obj["readiness"]}%.</div>'
        )
    summary.append("</div>")
    st.markdown("".join(summary), unsafe_allow_html=True)
