"""Overview page — platform-wide KPIs and object summary."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from backend.services.migration_service import (
    overview_kpis,
    overview_object_summary,
)
from ui.components import (
    defect_bars,
    kpi_row,
    load_rate_bars,
    page_title,
    section_card,
)


def render() -> None:
    page_title(
        "Migration Overview",
        "SAP S/4HANA Wave 1 — All Data Objects | Go-Live: Jun 30, 2025",
    )

    k = overview_kpis()
    kpi_row([
        ("Data Objects",    f"{k['object_count']}",           "var(--cyan)"),
        ("Total Extracted", f"{k['total_extracted']:,}",      "var(--cyan)"),
        ("Total Loaded",    f"{k['total_loaded']:,}",         "var(--green)"),
        ("Total Defects",   f"{k['total_defects']:,}",        "var(--red)"),
        ("Avg Readiness",   f"{k['avg_readiness']}%",         "var(--amber)"),
    ])

    st.markdown("### ")
    rows = overview_object_summary()

    # Object summary table (using pandas with custom styling)
    st.markdown('<div class="miq-card-title">Object Summary</div>',
                unsafe_allow_html=True)

    df = pd.DataFrame([
        {
            "Object": r["label"],
            "Views": r["view_count"],
            "SAP Tables": r["sap"],
            "Extracted": f"{r['extracted']:,}",
            "Loaded": f"{r['loaded']:,}",
            "Load %": f"{r['load_pct']}%",
            "Defects": r["defects"],
            "Recon Done": f"{r['recon_done']}/{r['view_count']}",
            "Readiness": f"{r['readiness']}%",
            "Status": _status_for(r["readiness"], r["defects"]),
        }
        for r in rows
    ])
    st.dataframe(df, use_container_width=True, hide_index=True)

    # Explore buttons
    cols = st.columns(len(rows))
    for col, r in zip(cols, rows):
        with col:
            if st.button(f"Explore {r['label']}", key=f"explore_{r['code']}",
                         use_container_width=True):
                st.session_state["selected_object"] = r["code"]
                st.session_state["target_page"] = "object"
                st.rerun()

    st.markdown(" ")

    c1, c2 = st.columns(2)
    with c1:
        st.markdown('<div class="miq-card">'
                    '<div class="miq-card-title">Load Rate by Object</div>',
                    unsafe_allow_html=True)
        load_rate_bars([
            (r["label"].split(" ")[0], r["load_pct"], f"{r['load_pct']}%")
            for r in rows
        ])
        st.markdown("</div>", unsafe_allow_html=True)

    with c2:
        max_def = max((r["defects"] for r in rows), default=1)
        st.markdown('<div class="miq-card">'
                    '<div class="miq-card-title">Defects by Object</div>',
                    unsafe_allow_html=True)
        defect_bars([
            (r["label"].split(" ")[0], r["defects"], max_def) for r in rows
        ])
        st.markdown("</div>", unsafe_allow_html=True)


def _status_for(readiness: int, defects: int) -> str:
    if readiness >= 90:
        return "✅ Ready"
    if readiness >= 80:
        return "⏳ In Progress"
    return "⚠️ At Risk"
