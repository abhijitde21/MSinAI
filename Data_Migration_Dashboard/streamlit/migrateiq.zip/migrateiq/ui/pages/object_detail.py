"""Object Detail page — stage pipeline, funnel, stage details, per view."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from backend.services.config_service import load_stage_data
from backend.services.migration_service import get_object_detail
from ui.components import (
    code_block,
    hbar,
    kpi_row,
    page_title,
    section_card,
    stage_pipeline,
)


def render() -> None:
    obj_code = st.session_state.get("selected_object")
    if not obj_code:
        st.info("Select a migration object from the sidebar or Overview.")
        return

    detail = get_object_detail(obj_code)
    if not detail:
        st.error(f"Object '{obj_code}' not found.")
        return

    view_count = len(detail["views"])
    total_ext = sum(v["stages"][0]["count"] for v in detail["views"] if v["stages"])
    total_lod = sum(v["stages"][4]["count"] if len(v["stages"]) >= 5 else 0
                    for v in detail["views"])
    total_def = sum(
        (v["recon"]["defects"] or 0) if v["recon"] else 0
        for v in detail["views"]
    )

    page_title(
        detail["label"],
        f"{detail['sap']} | {view_count} Views | "
        f"Key Identification varies per view",
    )

    readiness_color = (
        "var(--green)" if detail["readiness"] >= 90
        else "var(--amber)" if detail["readiness"] >= 80
        else "var(--red)"
    )
    kpi_row([
        ("Views",       f"{view_count}",           "var(--cyan)"),
        ("Extracted",   f"{total_ext:,}",          "var(--cyan)"),
        ("Loaded",      f"{total_lod:,}",          "var(--green)"),
        ("Defects",     f"{total_def:,}",          "var(--red)"),
        ("Readiness",   f"{detail['readiness']}%", readiness_color),
    ])

    st.markdown(" ")

    # Action bar
    c1, c2 = st.columns([4, 1])
    with c1:
        st.caption(f"📊 Explore each view below — 5-stage pipeline, funnel, detail.")
    with c2:
        if st.button("Open Reconciliation ↗", key="open_recon",
                     type="primary", use_container_width=True):
            st.session_state["target_page"] = "reconciliation"
            st.rerun()

    # Tabs per view
    if not detail["views"]:
        st.info("No views configured for this object.")
        return

    tab_labels = [v["label"] for v in detail["views"]]
    tabs = st.tabs(tab_labels)
    for tab, view in zip(tabs, detail["views"]):
        with tab:
            _render_view_tab(obj_code, view)


def _render_view_tab(obj_code: str, view: dict) -> None:
    # View header
    st.markdown(
        f"""
        <div style="display:flex;align-items:center;gap:10px;
                    margin:6px 0 10px 0;flex-wrap:wrap">
          <div style="width:10px;height:10px;border-radius:50%;
                      background:{view['color_hex']}"></div>
          <div style="font-weight:700;font-size:13px">{view['label']}</div>
          <div style="font-family:monospace;font-size:11px;color:var(--muted)">
            {view['sap_table']}
          </div>
          <div style="font-family:monospace;font-size:11px;
                      background:rgba(255,255,255,0.05);padding:3px 10px;
                      border-radius:4px">
            Key: {view['key_fields']}
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    stages = view["stages"]
    if not stages:
        st.warning("No stages configured.")
        return

    stage_pipeline(stages, view["key_fields"])

    # 5-stage funnel + stage detail
    col_left, col_right = st.columns(2)

    with col_left:
        st.markdown('<div class="miq-card">'
                    '<div class="miq-card-title">Stage Funnel</div>',
                    unsafe_allow_html=True)
        base = stages[0]["count"] or 1
        for s in stages:
            pct = round((s["count"] / base * 100), 1) if base else 0
            color = {"ok": "#3b82f6", "err": "#ef4444",
                     "warn": "#f59e0b", "load": "#22c55e"}.get(s["status"], "#3b82f6")
            st.markdown(
                hbar(s["label"], pct, color, f"{s['count']:,}"),
                unsafe_allow_html=True,
            )
        st.markdown("</div>", unsafe_allow_html=True)

    with col_right:
        st.markdown('<div class="miq-card">'
                    '<div class="miq-card-title">Stage Preview (live data)</div>',
                    unsafe_allow_html=True)
        options = [f"{i+1}. {s['label']} — {s['logical_name']}"
                   for i, s in enumerate(stages)]
        pick = st.selectbox(
            "Stage", options,
            key=f"stage_pick_{obj_code}_{view['code']}",
            label_visibility="collapsed",
        )
        sidx = options.index(pick)
        df, msg = load_stage_data(obj_code, view["code"], sidx, limit=25)
        st.caption(f"ℹ️ {msg}")
        if df is not None and not df.empty:
            st.dataframe(df, use_container_width=True, hide_index=True,
                         height=220)
        else:
            st.markdown(
                "<div style='color:var(--muted);font-size:11px;padding:8px'>"
                "No data available — configure this stage on the "
                "<b>Configuration</b> page.</div>",
                unsafe_allow_html=True,
            )
        st.markdown("</div>", unsafe_allow_html=True)

    # Recon status strip
    r = view["recon"]
    if r:
        st.markdown(
            f"""
            <div class="miq-card" style="display:flex;align-items:center;
                 gap:16px;flex-wrap:wrap">
              <div class="miq-card-title" style="margin:0">
                Reconciliation Status
              </div>
              <div style="font-size:11px">
                Total: <b>{r['total']:,}</b> · Clean:
                <span style="color:var(--green);font-weight:700">
                  {r['clean']:,}
                </span>
                · Defects:
                <span style="color:var(--red);font-weight:700">
                  {r['defects']}
                </span>
                · Match: <b>{r['match_pct']}%</b>
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
