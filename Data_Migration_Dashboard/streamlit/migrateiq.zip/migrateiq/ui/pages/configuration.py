"""
Configuration page — NEW in this application (not in prototype).

Allows the user to configure the data source for every (object, view, stage)
triple. Sources can be:
  - A table in an external database (SQLite or MySQL), or
  - An uploaded CSV / XLSX file
"""
from __future__ import annotations

from datetime import datetime

import streamlit as st

from backend.services.config_service import (
    get_stage_configs,
    list_objects,
    list_views,
    save_stage_config,
    save_uploaded_file,
    test_stage_config,
)
from ui.components import badge, page_title


STAGE_LABELS = ["Extract", "Invalids", "Transformed", "Enriched", "Loaded"]


def render() -> None:
    page_title(
        "Table / File Configuration",
        "Configure the underlying data source for every stage of every view. "
        "Each view has 5 stages — Extract, Invalids, Transformed, Enriched, Loaded.",
    )

    objects = list_objects()
    if not objects:
        st.warning("No migration objects seeded yet. Restart the app.")
        return

    # Object selector
    obj_labels = {o["code"]: f"{o['label']} ({o['sap_tables']})" for o in objects}
    default_obj = st.session_state.get("config_object_code", objects[0]["code"])
    obj_code = st.selectbox(
        "Migration Object",
        options=list(obj_labels.keys()),
        index=list(obj_labels.keys()).index(default_obj)
        if default_obj in obj_labels else 0,
        format_func=lambda c: obj_labels[c],
        key="cfg_obj_select",
    )
    st.session_state["config_object_code"] = obj_code

    # View selector
    views = list_views(obj_code)
    if not views:
        st.warning("No views for this object.")
        return

    view_labels = {v["code"]: f"{v['label']} — key: {v['key_fields']}"
                   for v in views}
    default_view = st.session_state.get("config_view_code", views[0]["code"])
    view_code = st.selectbox(
        "View",
        options=list(view_labels.keys()),
        index=list(view_labels.keys()).index(default_view)
        if default_view in view_labels else 0,
        format_func=lambda c: view_labels[c],
        key="cfg_view_select",
    )
    st.session_state["config_view_code"] = view_code

    view = next(v for v in views if v["code"] == view_code)

    # Header strip
    st.markdown(
        f"""
        <div class="miq-card">
          <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
            <div style="width:10px;height:10px;border-radius:50%;
                        background:{view['color_hex']}"></div>
            <div style="font-size:13px;font-weight:700">{view['label']}</div>
            <div style="font-family:monospace;font-size:11px;color:var(--muted)">
              {view['sap_table']}
            </div>
            <div style="font-family:monospace;font-size:11px;color:var(--text);
                        background:rgba(255,255,255,0.05);padding:3px 10px;
                        border-radius:4px">
              Key: {view['key_fields']}
            </div>
            <div style="margin-left:auto;color:var(--muted);font-size:11px">
              Fields: {view['field_list']}
            </div>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Stage configuration — one expander per stage
    stage_configs = get_stage_configs(obj_code, view_code)

    summary_cols = st.columns(5)
    for col, cfg in zip(summary_cols, stage_configs):
        status = cfg["test_status"]
        icon = {"ok": "✅", "failed": "❌", "untested": "⚪"}.get(status, "⚪")
        source = cfg["source_type"] if cfg["source_type"] != "none" else "—"
        with col:
            st.markdown(
                f"""
                <div class="miq-kpi">
                  <div class="miq-kpi-v" style="font-size:14px">{icon}</div>
                  <div class="miq-kpi-l">{cfg['stage_label']}</div>
                  <div style="font-size:9px;color:var(--muted);margin-top:4px">
                    {source.upper()}
                  </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

    st.markdown(" ")
    st.markdown('<div class="miq-card-title">Stage Source Configuration</div>',
                unsafe_allow_html=True)

    for cfg in stage_configs:
        _render_stage_form(obj_code, view_code, cfg)


# ─────────────────────────────────────────────────────────────
# Per-stage form
# ─────────────────────────────────────────────────────────────
def _render_stage_form(obj_code: str, view_code: str, cfg: dict) -> None:
    cfg_id = cfg["id"]
    stage_label = cfg["stage_label"]
    logical_name = cfg["logical_table_name"]

    # Header summary
    status = cfg["test_status"]
    status_badge = {
        "ok": badge("Tested OK", "bg"),
        "failed": badge("Test Failed", "br"),
        "untested": badge("Untested", "bb"),
    }.get(status, badge("Untested", "bb"))
    source_badge = {
        "database": badge("Database", "bp"),
        "file": badge("File Upload", "bc"),
        "none": badge("Not Configured", "ba"),
    }.get(cfg["source_type"], badge("Not Configured", "ba"))

    header = (
        f"**Stage {cfg['stage_order']+1} — {stage_label}** · "
        f"`{logical_name}` · {cfg['source_type'] or 'none'}"
    )

    with st.expander(header, expanded=(cfg["stage_order"] == 0)):
        tested_at = cfg.get("last_tested_at")
        tested_str = ""
        if tested_at:
            try:
                tested_str = tested_at.strftime("%Y-%m-%d %H:%M")
            except Exception:
                tested_str = str(tested_at)[:16]
        st.markdown(
            f"<div style='margin-bottom:10px'>{status_badge} {source_badge}"
            + (f"<span style='color:var(--muted);font-size:10px;margin-left:8px'>"
               f"Last test: {tested_str}</span>"
               if tested_str else "")
            + "</div>",
            unsafe_allow_html=True,
        )
        if cfg["test_message"]:
            st.caption(f"ℹ️ {cfg['test_message']}")

        source_type = st.radio(
            "Source Type",
            options=["none", "database", "file"],
            index=["none", "database", "file"].index(cfg["source_type"])
            if cfg["source_type"] in ("none", "database", "file") else 0,
            horizontal=True,
            key=f"st_{cfg_id}",
            format_func=lambda v: {"none": "— Not Configured —",
                                   "database": "🗄 Database",
                                   "file": "📁 File Upload"}[v],
        )

        payload = {"source_type": source_type}

        if source_type == "database":
            payload.update(_render_db_form(cfg))
        elif source_type == "file":
            payload.update(_render_file_form(obj_code, view_code, cfg))

        b1, b2, _ = st.columns([1, 1, 4])
        with b1:
            if st.button("💾 Save", key=f"save_{cfg_id}",
                         use_container_width=True, type="primary"):
                save_stage_config(cfg_id, payload)
                st.success(f"Saved {stage_label} configuration.")
                st.rerun()
        with b2:
            if st.button("🔌 Test", key=f"test_{cfg_id}",
                         use_container_width=True):
                save_stage_config(cfg_id, payload)
                result = test_stage_config(cfg_id)
                if result["ok"]:
                    st.success(f"✅ {result['message']}")
                else:
                    st.error(f"❌ {result['message']}")
                st.rerun()


def _render_db_form(cfg: dict) -> dict:
    c1, c2, c3 = st.columns(3)
    db_type = c1.selectbox(
        "DB Type",
        ["sqlite", "mysql"],
        index=0 if cfg["db_type"] != "mysql" else 1,
        key=f"db_type_{cfg['id']}",
    )
    db_name = c2.text_input(
        "Database / SQLite path",
        value=cfg["db_name"] or "",
        placeholder=("data/migrateiq.db" if db_type == "sqlite"
                     else "my_migration_db"),
        key=f"db_name_{cfg['id']}",
    )
    db_table = c3.text_input(
        "Table name",
        value=cfg["db_table"] or cfg["logical_table_name"],
        placeholder="schema.table_name",
        key=f"db_tbl_{cfg['id']}",
    )

    if db_type == "mysql":
        c4, c5, c6, c7 = st.columns(4)
        db_host = c4.text_input("Host", value=cfg["db_host"] or "localhost",
                                key=f"db_host_{cfg['id']}")
        db_port = c5.number_input("Port", min_value=1, max_value=65535,
                                  value=cfg["db_port"] or 3306,
                                  key=f"db_port_{cfg['id']}")
        db_user = c6.text_input("User", value=cfg["db_user"] or "",
                                key=f"db_user_{cfg['id']}")
        db_password = c7.text_input("Password", value=cfg["db_password"] or "",
                                    type="password",
                                    key=f"db_pass_{cfg['id']}")
    else:
        db_host, db_port = "", 0
        db_user, db_password = "", ""

    return {
        "db_type": db_type, "db_host": db_host, "db_port": db_port,
        "db_name": db_name, "db_user": db_user, "db_password": db_password,
        "db_table": db_table,
    }


def _render_file_form(obj_code: str, view_code: str, cfg: dict) -> dict:
    st.markdown(
        "<div style='font-size:11px;color:var(--muted);margin-bottom:6px'>"
        "Upload a CSV or XLSX file. The file is stored under "
        "<code>data/uploads/</code>.</div>",
        unsafe_allow_html=True,
    )

    uploaded = st.file_uploader(
        "Choose a file",
        type=["csv", "xlsx", "xls"],
        key=f"upload_{cfg['id']}",
        label_visibility="collapsed",
    )

    # If user just uploaded, persist it
    file_path = cfg["file_path"] or ""
    file_format = cfg["file_format"] or "csv"
    file_sheet = cfg["file_sheet"] or ""

    if uploaded is not None:
        saved_path = save_uploaded_file(
            uploaded.getvalue(),
            uploaded.name,
            obj_code, view_code,
            cfg["stage_order"],
        )
        file_path = saved_path
        if uploaded.name.lower().endswith(".csv"):
            file_format = "csv"
        else:
            file_format = "xlsx"
        st.success(f"Uploaded to `{saved_path}`")

    c1, c2 = st.columns([3, 1])
    file_path = c1.text_input(
        "File path",
        value=file_path,
        placeholder="data/uploads/...",
        key=f"fp_{cfg['id']}",
    )
    file_format = c2.selectbox(
        "Format",
        ["csv", "xlsx"],
        index=0 if file_format == "csv" else 1,
        key=f"ff_{cfg['id']}",
    )
    if file_format == "xlsx":
        file_sheet = st.text_input(
            "Sheet name (optional)",
            value=file_sheet or "",
            placeholder="Sheet1",
            key=f"fs_{cfg['id']}",
        )

    return {
        "file_path": file_path, "file_format": file_format,
        "file_sheet": file_sheet,
    }
