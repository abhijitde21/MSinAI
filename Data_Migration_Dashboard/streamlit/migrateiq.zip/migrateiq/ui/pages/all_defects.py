"""All Defects page — cross-object defect register with filters."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from backend.services.defect_service import all_defects, defect_counts
from ui.components import kpi_row, page_title


def render() -> None:
    page_title(
        "All Defects — Platform Wide",
        "Reconciliation defects across all objects and views",
    )

    counts = defect_counts()
    kpi_row([
        ("Total Defects", f"{counts['total']}", "var(--red)"),
        ("Critical", f"{counts['Critical']}", "var(--red)"),
        ("Major", f"{counts['Major']}", "var(--amber)"),
        ("Minor", f"{counts['Minor']}", "var(--blue)"),
    ])

    st.markdown(" ")

    c1, c2, c3 = st.columns([2, 2, 1])
    obj_filter = c1.selectbox(
        "Filter: Object",
        ["All Objects", "Material Master", "Vendor Master",
         "Customer Master", "GL Accounts"],
        key="def_obj_filter",
    )
    sev_filter = c2.selectbox(
        "Filter: Severity",
        ["All Severity", "Critical", "Major", "Minor"],
        key="def_sev_filter",
    )

    obj_arg = "" if obj_filter == "All Objects" else obj_filter
    sev_arg = "" if sev_filter == "All Severity" else sev_filter

    rows = all_defects(obj_arg, sev_arg)

    if not rows:
        st.info("No defects match the current filters.")
        return

    df = pd.DataFrame([
        {
            "Object": r["object"],
            "View": r["view"],
            "Key": r["key"],
            "Field": r["field"],
            "Stage": r["stage"],
            "Defect Type": r["defect_type"],
            "Extract": r["ev"],
            "Loaded": r["lv"],
            "Severity": r["severity"],
        }
        for r in rows
    ])

    with c3:
        st.download_button(
            "📥 Export CSV",
            data=df.to_csv(index=False),
            file_name="all_defects.csv",
            mime="text/csv",
            use_container_width=True,
        )

    st.dataframe(df, use_container_width=True, hide_index=True, height=560)
