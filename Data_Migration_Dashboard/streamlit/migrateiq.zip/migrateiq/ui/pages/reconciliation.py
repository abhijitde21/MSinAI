"""Reconciliation page — AI engine panel, SQL, defect table, per view."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from ai.agents.recon_agent import run_recon_agent
from backend.services.migration_service import get_object_detail
from backend.services.reconciliation_service import (
    get_latest_run,
    run_reconciliation,
)
from config.settings import settings
from ui.components import (
    ai_panel_close,
    ai_panel_open,
    ai_recommendation,
    code_block,
    hbar,
    kpi_row,
    page_title,
    severity_badge,
)


def render() -> None:
    obj_code = st.session_state.get("selected_object")
    if not obj_code:
        st.info("Select a migration object from the sidebar first.")
        return

    detail = get_object_detail(obj_code)
    if not detail:
        st.error(f"Object '{obj_code}' not found.")
        return

    view_count = len(detail["views"])
    total = sum((v["recon"]["total"] if v["recon"] else 0)
                for v in detail["views"])
    clean = sum((v["recon"]["clean"] if v["recon"] else 0)
                for v in detail["views"])
    defects = sum((v["recon"]["defects"] if v["recon"] else 0)
                  for v in detail["views"])
    done = sum(1 for v in detail["views"]
               if v["recon"] and v["recon"].get("status") == "done")

    page_title(
        f"Reconciliation — {detail['label']}",
        "AI-generated cross-stage comparison per view · "
        "Key fields joined per view definition",
    )

    readiness_color = (
        "var(--green)" if detail["readiness"] >= 90
        else "var(--amber)" if detail["readiness"] >= 80
        else "var(--red)"
    )
    kpi_row([
        ("Total Records",    f"{total:,}",   "var(--cyan)"),
        ("Clean Records",    f"{clean:,}",   "var(--green)"),
        ("Total Defects",    f"{defects}",   "var(--red)"),
        ("Views Reconciled", f"{done}/{view_count}", "var(--green)"),
        ("Readiness",        f"{detail['readiness']}%", readiness_color),
    ])

    st.markdown(" ")

    # AI Engine panel
    ai_panel_open(
        f"AI Reconciliation Engine — {detail['label']}",
        buttons_html=(
            '<span style="font-size:10px;color:var(--muted)">'
            f"{'LLM: Groq · ' + settings.groq_model if settings.llm_enabled else 'LLM: disabled (rule-based fallback)'}"
            "</span>"
        ),
    )
    st.markdown(
        "<div style='font-size:11px;color:var(--muted);line-height:1.6'>"
        "AI compares all stage tables per view using a <b>FULL OUTER JOIN</b> on "
        "the view's key field. Detects: null propagation, value mutations, "
        "missing records, type mismatches, and enrichment failures."
        "</div>",
        unsafe_allow_html=True,
    )
    ai_panel_close()

    st.markdown(" ")

    tab_labels = [
        f"{v['label']}"
        + (f" — {v['recon']['defects']}" if v["recon"] and v["recon"].get("defects") else "")
        for v in detail["views"]
    ]
    tabs = st.tabs(tab_labels)
    for tab, view in zip(tabs, detail["views"]):
        with tab:
            _render_view_recon(obj_code, view)


def _render_view_recon(obj_code: str, view: dict) -> None:
    view_code = view["code"]
    run = get_latest_run(obj_code, view_code)

    st.markdown(
        f"""
        <div style="display:flex;align-items:center;gap:10px;
                    margin:6px 0 10px 0;flex-wrap:wrap">
          <div style="width:10px;height:10px;border-radius:50%;
                      background:{view['color_hex']}"></div>
          <div style="font-weight:700;font-size:13px">{view['label']}</div>
          <div style="font-family:monospace;font-size:11px;
                      background:rgba(255,255,255,0.05);padding:3px 10px;
                      border-radius:4px">
            Key: {view['key_fields']}
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    c1, c2, c3 = st.columns([1, 1, 3])
    with c1:
        if st.button("🤖 Run AI Recon",
                     key=f"runrecon_{obj_code}_{view_code}",
                     type="primary", use_container_width=True):
            with st.spinner(f"Reconciling {view['label']} across 5 stages..."):
                try:
                    run_reconciliation(
                        obj_code, view_code,
                        ai_runner=run_recon_agent,
                    )
                    st.success(f"Reconciliation complete for {view['label']}.")
                    st.rerun()
                except Exception as exc:  # noqa: BLE001
                    st.error(f"Recon failed: {exc}")
    with c2:
        if run and st.button("📥 Export CSV",
                             key=f"export_{obj_code}_{view_code}",
                             use_container_width=True):
            _export_run(run, view)

    if not run:
        st.info(
            f"No reconciliation run yet for **{view['label']}**. "
            f"Click *Run AI Recon* above to generate one."
        )
        return

    # Summary row
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Total Records", f"{run['total'] or 0:,}")
    k2.metric("Clean", f"{run['clean'] or 0:,}")
    k3.metric("Defects", f"{run['defects'] or 0:,}")
    k4.metric("Match %", f"{run['match_pct'] or 0}%")

    # AI summary & recommendations
    if run["ai_summary"] or run["ai_recs"]:
        ai_panel_open(f"AI Analysis — {view['label']}")
        if run["ai_summary"]:
            st.markdown(
                f"<div style='font-size:12px;line-height:1.7;"
                f"color:var(--text);padding:4px 0'>"
                f"{run['ai_summary']}</div>",
                unsafe_allow_html=True,
            )
        for rec in run["ai_recs"]:
            ai_recommendation(
                title=rec.get("title", ""),
                body=rec.get("body", ""),
                severity=rec.get("severity", "Minor"),
            )
        ai_panel_close()

    # Generated SQL
    if run["sql"]:
        st.markdown('<div class="miq-card">'
                    '<div class="miq-card-title">AI-Generated Reconciliation SQL</div>',
                    unsafe_allow_html=True)
        code_block(run["sql"])
        st.markdown("</div>", unsafe_allow_html=True)

    # Defect table
    if run["defect_rows"]:
        st.markdown('<div class="miq-card-title">Defect Sample</div>',
                    unsafe_allow_html=True)
        df = pd.DataFrame([
            {
                "Key": d["key"], "Field": d["field"], "Stage": d["stage"],
                "Defect Type": d["type"],
                "Extract": d["ev"], "Loaded": d["lv"],
                "Severity": d["sev"],
            }
            for d in run["defect_rows"]
        ])
        st.dataframe(df, use_container_width=True, hide_index=True, height=280)


def _export_run(run: dict, view: dict) -> None:
    import io
    df = pd.DataFrame(run["defect_rows"])
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    st.download_button(
        "⬇ Download defects.csv",
        data=buf.getvalue(),
        file_name=f"recon_{view['code']}_defects.csv",
        mime="text/csv",
        use_container_width=True,
    )
