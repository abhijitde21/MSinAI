"""
Dark theme CSS matching the original prototype.

Injected once per app run by app.py.
"""

THEME_CSS = """
<style>
/* ─────── Global palette ─────── */
:root {
  --bg: #0d1520; --bg2: #111c2b; --panel: #162233; --card: #1a2840;
  --border: rgba(255,255,255,0.07);
  --cyan: #00d4aa; --amber: #f59e0b; --red: #ef4444; --green: #22c55e;
  --blue: #3b82f6; --purple: #a855f7; --pink: #ec4899;
  --text: #dde4f0; --muted: #7a8fa8;
}

/* Base */
.stApp { background: var(--bg); color: var(--text); }
[data-testid="stHeader"] { background: transparent; }
.main .block-container { padding-top: 1rem; padding-bottom: 2rem; max-width: 1280px; }

/* Sidebar */
[data-testid="stSidebar"] {
  background: var(--bg2) !important;
  border-right: 1px solid var(--border);
}
[data-testid="stSidebar"] * { color: var(--text); }

/* Typography */
h1, h2, h3, h4, h5 { color: var(--text) !important; }
h1 { font-size: 22px !important; font-weight: 800 !important; }
h2 { font-size: 17px !important; font-weight: 700 !important; }
h3 { font-size: 14px !important; font-weight: 700 !important; }
p, li, span, label, div { font-size: 13px; }

/* Buttons */
.stButton > button {
  background: var(--panel); color: var(--text);
  border: 1px solid var(--border); border-radius: 6px;
  padding: 5px 14px; font-size: 11px; font-weight: 600;
  transition: all 0.15s;
}
.stButton > button:hover {
  border-color: var(--cyan) !important; color: var(--cyan) !important;
}
.stButton > button[kind="primary"] {
  background: var(--cyan) !important; color: #071a12 !important;
  border-color: var(--cyan) !important;
}
.stButton > button[kind="primary"]:hover {
  background: #00b894 !important; color: #071a12 !important;
}
.stDownloadButton > button {
  background: var(--panel); color: var(--text);
  border: 1px solid var(--border); border-radius: 6px;
  padding: 5px 14px; font-size: 11px;
}
.stDownloadButton > button:hover { border-color: var(--cyan); color: var(--cyan); }

/* Inputs */
.stTextInput > div > div > input,
.stTextArea > div > div > textarea,
.stNumberInput > div > div > input,
.stSelectbox > div > div,
.stMultiSelect > div > div {
  background: var(--panel) !important;
  border: 1px solid var(--border) !important;
  color: var(--text) !important;
  font-size: 12px !important;
}
.stSelectbox label, .stTextInput label, .stNumberInput label,
.stRadio label, .stCheckbox label, .stFileUploader label {
  color: var(--muted) !important; font-size: 10px !important;
  font-weight: 600 !important; text-transform: uppercase;
  letter-spacing: 0.5px;
}

/* Metric */
[data-testid="stMetric"] {
  background: var(--panel); border: 1px solid var(--border);
  border-radius: 7px; padding: 10px 12px;
}
[data-testid="stMetricLabel"] {
  color: var(--muted) !important; font-size: 10px !important;
  text-transform: uppercase; letter-spacing: 0.5px;
}
[data-testid="stMetricValue"] {
  color: var(--text) !important; font-size: 22px !important;
  font-weight: 800 !important;
}

/* Tabs */
.stTabs [data-baseweb="tab-list"] {
  gap: 0; background: transparent; border-bottom: 1px solid var(--border);
}
.stTabs [data-baseweb="tab"] {
  background: transparent; color: var(--muted); font-size: 11px;
  padding: 7px 14px; border-radius: 0;
  border-bottom: 2px solid transparent;
}
.stTabs [aria-selected="true"] {
  color: var(--cyan) !important; border-bottom-color: var(--cyan) !important;
  background: transparent !important;
}

/* Tables / DataFrame */
.stDataFrame, [data-testid="stDataFrame"] {
  background: var(--card); border: 1px solid var(--border);
  border-radius: 8px;
}
.stDataFrame [data-testid="stTable"] { background: var(--card); }

/* Expander */
.streamlit-expanderHeader {
  background: var(--card) !important; color: var(--text) !important;
  border: 1px solid var(--border) !important; font-size: 12px !important;
}

/* Custom component cards */
.miq-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: 9px; padding: 14px; margin-bottom: 12px;
}
.miq-card-title {
  font-size: 10px; font-weight: 700; color: var(--muted);
  text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 10px;
}

/* Badges */
.miq-badge {
  display: inline-block; padding: 2px 8px; border-radius: 10px;
  font-size: 10px; font-weight: 700; margin-right: 4px;
}
.miq-bg  { background: rgba(34,197,94,.15);  color: #4ade80; }
.miq-ba  { background: rgba(245,158,11,.15); color: #fbbf24; }
.miq-br  { background: rgba(239,68,68,.15);  color: #f87171; }
.miq-bb  { background: rgba(59,130,246,.15); color: #60a5fa; }
.miq-bc  { background: rgba(0,212,170,.15);  color: var(--cyan); }
.miq-bp  { background: rgba(168,85,247,.15); color: #c084fc; }

/* KPI mini-cards (custom) */
.miq-kpi {
  background: var(--panel); border: 1px solid var(--border);
  border-radius: 7px; padding: 12px; text-align: center;
}
.miq-kpi-v { font-size: 22px; font-weight: 800; line-height: 1.1; }
.miq-kpi-l { font-size: 10px; color: var(--muted); margin-top: 4px;
             text-transform: uppercase; letter-spacing: 0.4px; }

/* Pipeline stages */
.miq-pipe { display: flex; align-items: stretch; gap: 0;
            overflow-x: auto; padding-bottom: 4px; margin-bottom: 12px; }
.miq-stage {
  background: var(--panel); border: 1px solid var(--border);
  border-radius: 7px; padding: 10px 12px; min-width: 140px; flex-shrink: 0;
}
.miq-stage.ok   { border-color: rgba(0,212,170,0.4); }
.miq-stage.err  { border-color: var(--red); }
.miq-stage.warn { border-color: var(--amber); }
.miq-stage.load { border-color: var(--green); }
.miq-stage-lbl  { font-size: 9px; font-weight: 700; color: var(--muted);
                  text-transform: uppercase; letter-spacing: 0.6px; }
.miq-stage-tbl  { font-family: monospace; font-size: 11px;
                  color: var(--text); margin: 4px 0; font-weight: 700; }
.miq-stage-cnt  { font-size: 18px; font-weight: 800; }
.miq-stage-key  { font-size: 9px; color: var(--muted); margin-top: 2px; }
.miq-arr        { display: flex; flex-direction: column;
                  align-items: center; justify-content: center;
                  padding: 0 6px; color: var(--muted); }
.miq-arr-d      { font-size: 9px; font-weight: 700; }

/* AI panel */
.miq-aipanel {
  background: linear-gradient(135deg, rgba(0,212,170,0.08), rgba(59,130,246,0.06));
  border: 1px solid rgba(0,212,170,0.3); border-radius: 9px;
  padding: 14px; margin-bottom: 12px;
}
.miq-aihead { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
.miq-aiicon {
  width: 24px; height: 24px; background: var(--cyan); color: #071a12;
  border-radius: 6px; display: flex; align-items: center;
  justify-content: center; font-weight: 800; font-size: 11px;
}
.miq-airec {
  background: rgba(0,0,0,0.2); border-left: 3px solid var(--cyan);
  padding: 8px 12px; margin-top: 8px; border-radius: 4px;
}
.miq-airec-t { font-size: 11px; font-weight: 700; margin-bottom: 3px; }
.miq-airec-b { font-size: 11px; color: var(--muted); line-height: 1.5; }

/* SQL code block */
.miq-code {
  background: #0a1220; border: 1px solid var(--border);
  border-radius: 6px; padding: 12px;
  font-family: "Menlo", "Consolas", monospace; font-size: 11px;
  color: #c5d1e6; white-space: pre-wrap; overflow-x: auto;
  line-height: 1.6;
}

/* Progress bar substitute */
.miq-pbar { background: rgba(255,255,255,0.06);
            border-radius: 3px; height: 6px; overflow: hidden; }
.miq-pfil { height: 100%; border-radius: 3px; }

/* Section header */
.miq-hrow { display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 10px; }

/* Horizontal rule override */
hr { border-color: var(--border) !important; opacity: 0.5; }

/* Alerts */
.stAlert { border-radius: 8px; }

/* Hide streamlit chrome */
footer { visibility: hidden; }
#MainMenu { visibility: hidden; }
</style>
"""
