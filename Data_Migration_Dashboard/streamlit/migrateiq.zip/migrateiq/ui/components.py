"""
Shared Streamlit components styled to match the prototype.
"""
from __future__ import annotations

from typing import Iterable

import streamlit as st

STAGE_COLORS = {
    "ok":   "#00d4aa",
    "err":  "#ef4444",
    "warn": "#f59e0b",
    "load": "#22c55e",
}
STAGE_BADGE_LABELS = {
    "ok": "OK", "err": "Issues", "warn": "Warning", "load": "Loaded",
}
BADGE_CLASS = {
    "ok": "miq-bc", "err": "miq-br", "warn": "miq-ba", "load": "miq-bg",
}


def kpi_row(items: list[tuple[str, str, str]]) -> None:
    """Render a row of KPI mini-cards. `items` is [(label, value, color_hex)]."""
    cols = st.columns(len(items))
    for col, (label, value, color) in zip(cols, items):
        with col:
            st.markdown(
                f"""
                <div class="miq-kpi">
                  <div class="miq-kpi-v" style="color:{color}">{value}</div>
                  <div class="miq-kpi-l">{label}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )


def badge(text: str, kind: str = "bc") -> str:
    """Return HTML for an inline colored badge. `kind` in bg/ba/br/bb/bc/bp."""
    return f'<span class="miq-badge miq-{kind}">{text}</span>'


def severity_badge(sev: str) -> str:
    mp = {"Critical": "br", "Major": "ba", "Minor": "bb"}
    return badge(sev, mp.get(sev, "bb"))


def page_title(title: str, subtitle: str = "") -> None:
    st.markdown(
        f"<h1 style='margin-bottom:2px'>{title}</h1>"
        + (f"<div style='color:var(--muted);font-size:12px;margin-bottom:14px'>{subtitle}</div>"
           if subtitle else ""),
        unsafe_allow_html=True,
    )


def section_card(title: str, body_html: str) -> None:
    st.markdown(
        f"""
        <div class="miq-card">
          <div class="miq-card-title">{title}</div>
          {body_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


def hbar(label: str, pct: float, color: str, value_text: str) -> str:
    pw = max(0, min(100, float(pct)))
    return (
        f"<div style='display:flex;align-items:center;gap:8px;margin-bottom:6px'>"
        f"<div style='width:72px;font-size:10px;color:var(--muted);text-align:right'>{label}</div>"
        f"<div style='flex:1;background:rgba(255,255,255,0.05);border-radius:3px;"
        f"height:16px;overflow:hidden;'>"
        f"<div style='height:100%;width:{pw}%;background:{color};"
        f"display:flex;align-items:center;padding:0 6px;border-radius:3px;'>"
        f"<span style='font-size:9px;font-weight:700;color:rgba(0,0,0,0.7)'>"
        f"{value_text}</span></div></div></div>"
    )


def stage_pipeline(stages: list[dict], key_fields: str) -> None:
    """Render a 5-stage pipeline as HTML."""
    html = '<div class="miq-pipe">'
    for i, s in enumerate(stages):
        status = s.get("status", "ok")
        color = STAGE_COLORS.get(status, "#00d4aa")
        b_class = BADGE_CLASS.get(status, "miq-bc")
        badge_text = STAGE_BADGE_LABELS.get(status, "OK")
        html += (
            f'<div class="miq-stage {status}">'
            f'<div class="miq-stage-lbl">{str(i+1).zfill(2)} — {s["label"]}</div>'
            f'<div class="miq-stage-tbl">{s["logical_name"]}</div>'
            f'<div class="miq-stage-cnt" style="color:{color}">'
            f'{int(s["count"]):,}</div>'
            f'<div class="miq-stage-key">Key: {key_fields}</div>'
            f'<div style="margin-top:6px"><span class="miq-badge {b_class}">'
            f'{badge_text}</span></div>'
            f'</div>'
        )
        if i < len(stages) - 1:
            d = stages[i + 1]["count"] - s["count"]
            dc = "#ef4444" if d < 0 else "#22c55e"
            sign = "+" if d > 0 else ""
            html += (
                '<div class="miq-arr"><div style="font-size:15px">→</div>'
                f'<div class="miq-arr-d" style="color:{dc}">{sign}{d:,}</div>'
                '</div>'
            )
    html += "</div>"
    st.markdown(html, unsafe_allow_html=True)


def ai_panel_open(title: str, buttons_html: str = "") -> None:
    st.markdown(
        f"""
        <div class="miq-aipanel">
          <div class="miq-aihead">
            <div class="miq-aiicon">AI</div>
            <div style="font-size:12px;font-weight:700">{title}</div>
            <div style="margin-left:auto">{buttons_html}</div>
          </div>
        """,
        unsafe_allow_html=True,
    )


def ai_panel_close() -> None:
    st.markdown("</div>", unsafe_allow_html=True)


def ai_recommendation(title: str, body: str, severity: str = "Minor") -> None:
    color = {"Critical": "#ef4444", "Major": "#f59e0b",
             "Minor": "#3b82f6"}.get(severity, "#00d4aa")
    st.markdown(
        f"""
        <div class="miq-airec" style="border-left-color:{color}">
          <div class="miq-airec-t" style="color:{color}">
            {severity} — {title}
          </div>
          <div class="miq-airec-b">{body}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def code_block(text: str) -> None:
    safe = (text or "").replace("<", "&lt;").replace(">", "&gt;")
    st.markdown(f'<div class="miq-code">{safe}</div>', unsafe_allow_html=True)


def load_rate_bars(items: Iterable[tuple[str, float, str]]) -> None:
    html = ""
    for label, pct, value in items:
        color = "#00d4aa" if pct >= 97 else ("#f59e0b" if pct >= 90 else "#ef4444")
        html += hbar(label, pct, color, value)
    st.markdown(html, unsafe_allow_html=True)


def defect_bars(items: Iterable[tuple[str, int, int]]) -> None:
    """items: (label, count, max_for_scale)."""
    html = ""
    for label, count, max_for_scale in items:
        pct = (count / max_for_scale * 100) if max_for_scale else 0
        color = "#ef4444" if pct >= 60 else ("#f59e0b" if pct >= 25 else "#3b82f6")
        html += hbar(label, pct, color, str(count))
    st.markdown(html, unsafe_allow_html=True)
