# MigrateIQ — Data Migration Reconciliation Platform

Enterprise-grade SAP data migration reconciliation dashboard built with
**Streamlit**, **SQLAlchemy**, **LangGraph** and **Groq** (open-source LLMs).

---

## Pages

| # | Page | Description |
|---|------|-------------|
| 1 | **Overview** | Platform-wide KPIs, object summary table, load-rate & defect charts |
| 2 | **Configuration** *(NEW)* | Per-object → per-view → per-stage source setup — database (SQLite/MySQL) or CSV/XLSX upload |
| 3 | **Object Detail** | 5-stage pipeline, stage funnel, live data preview per view |
| 4 | **Reconciliation** | AI-powered cross-stage comparison, generated SQL, defect table, recommendations |
| 5 | **All Defects** | Cross-object defect register with object & severity filters |
| 6 | **Lineage** | Visual data-flow grid: Extract → Invalids → Transform → Enriched → Loaded → Recon |

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Streamlit (dark themed, custom CSS) |
| Backend | Python 3.10+ |
| Database | SQLite (default) — swap to MySQL via `.env` |
| ORM | SQLAlchemy 2.x |
| AI / LLM | Groq API → Llama 3.3 / Qwen (configurable) |
| Agentic flow | LangGraph state-graph with rule-based fallback |
| Data loading | Pandas (CSV, XLSX, SQL) |

---

## Quick Start (local deployment)

### 1. Clone / unzip

```bash
cd migrateiq
```

### 2. Create a virtual environment

```bash
python -m venv .venv
source .venv/bin/activate        # Linux / macOS
# .venv\Scripts\activate          # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure environment

```bash
cp .env.example .env
# Edit .env — at minimum set GROQ_API_KEY for AI features
```

> **No Groq key?** The app still runs perfectly — all pages work.
> AI analysis falls back to deterministic rule-based recommendations.

### 5. Run

```bash
streamlit run app.py
```

The app opens at `http://localhost:8501`. On first launch it automatically:
- Creates the SQLite database at `data/migrateiq.db`
- Seeds 4 migration objects, 12 views, 60 stage configs, sample defects
- Writes sample CSV files under `sample_data/`

---

## Configuration Page (NEW)

The **Configuration** page lets you connect real data sources:

### Database connectivity
1. Select an object → view → expand a stage
2. Choose **Database** as source type
3. Pick **SQLite** or **MySQL** and fill in connection details + table name
4. Click **Test** to validate, then **Save**

### File upload
1. Expand a stage → choose **File Upload**
2. Drag-and-drop a CSV or XLSX file
3. The file is saved under `data/uploads/<object>/<view>/`
4. Click **Test** then **Save**

Each view has 5 independently configurable stages:
`Extract → Invalids → Transformed → Enriched → Loaded`

---

## Using MySQL instead of SQLite

Edit `.env`:

```dotenv
APP_DB_URL=mysql+pymysql://root:mypassword@localhost:3306/migrateiq
```

Make sure the database exists:

```sql
CREATE DATABASE migrateiq CHARACTER SET utf8mb4;
```

The app creates all tables on first launch.

---

## AI / LLM Configuration

The reconciliation agent uses **Groq** for fast inference on open-source models.

1. Sign up at https://console.groq.com
2. Create an API key
3. Add to `.env`:

```dotenv
GROQ_API_KEY=gsk_...
GROQ_MODEL=llama-3.3-70b-versatile
```

Supported models (any Groq-hosted model works):
- `llama-3.3-70b-versatile` — best quality
- `llama-3.1-8b-instant` — fastest
- `qwen/qwen3-32b` — Qwen family

### LangGraph Agent Flow

```
prepare_context ──▶ call_llm ──▶ parse_output ──▶ END
                        │
                        ▼  (on error / disabled)
                  rule_based_fallback ──▶ END
```

The agent always returns results — it gracefully degrades to deterministic
analysis when the LLM is unavailable or returns unparseable output.

---

## Project Structure

```
migrateiq/
├── app.py                          # Streamlit entry point
├── requirements.txt
├── .env.example
│
├── config/
│   └── settings.py                 # Centralized env-based settings
│
├── database/
│   ├── models.py                   # SQLAlchemy ORM (6 tables)
│   ├── db.py                       # Engine & session management
│   └── seed.py                     # Prototype-matching seed data
│
├── backend/
│   ├── data_loaders/
│   │   ├── file_loader.py          # CSV / XLSX reader
│   │   └── db_loader.py            # SQLite / MySQL connector
│   └── services/
│       ├── config_service.py       # Stage config CRUD
│       ├── migration_service.py    # Aggregations for overview/lineage
│       ├── reconciliation_service.py  # Recon engine
│       └── defect_service.py       # Cross-object defect queries
│
├── ai/
│   ├── groq_client.py              # Groq API wrapper
│   └── agents/
│       ├── prompts.py              # Prompt templates
│       └── recon_agent.py          # LangGraph state-graph agent
│
├── ui/
│   ├── theme.py                    # Dark CSS (matches prototype)
│   ├── components.py               # KPIs, badges, pipeline, cards
│   └── pages/
│       ├── overview.py             # Page 1 — Overview
│       ├── configuration.py        # Page 2 — Configuration (NEW)
│       ├── object_detail.py        # Page 3 — Object Detail
│       ├── reconciliation.py       # Page 4 — Reconciliation
│       ├── all_defects.py          # Page 5 — All Defects
│       └── lineage.py              # Page 6 — Lineage
│
├── data/                           # Auto-created at runtime
│   ├── migrateiq.db                # SQLite database
│   └── uploads/                    # Uploaded data files
│
└── sample_data/                    # Sample CSVs (auto-generated)
```

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `ModuleNotFoundError` | Re-run `pip install -r requirements.txt` in your venv |
| MySQL connection fails | Check host/port/user/password in `.env`; ensure DB exists |
| AI analysis shows "rule-based" | Set `GROQ_API_KEY` in `.env` |
| Port 8501 in use | Run `streamlit run app.py --server.port 8502` |
| Database reset | Delete `data/migrateiq.db` and restart the app |

---

## License

Internal tool — proprietary.
